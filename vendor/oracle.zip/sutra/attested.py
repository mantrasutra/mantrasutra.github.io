# SPDX-License-Identifier: AGPL-3.0-only
"""attested(word_iast) -> [(source, page_col), ...]: is the headword in Monier-Williams 1899 / Apte 1890, and where.
Loaded lazily from data/lexicon-attested.tsv.gz (CC BY-SA 4.0, see data/LICENSE-lexicon-attested.txt)."""
import gzip, os
_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'lexicon-attested.tsv.gz')
_IDX = None
def _load():
    global _IDX
    if _IDX is None:
        idx = {}
        with gzip.open(_PATH, 'rt', encoding='utf-8') as f:
            next(f)
            for ln in f:
                h, _slp, src, pc, _lid = ln.rstrip('\n').split('\t')
                idx.setdefault(h, []).append((src, pc))
        _IDX = idx
    return _IDX
def attested(word_iast): return list(_load().get(word_iast, ()))

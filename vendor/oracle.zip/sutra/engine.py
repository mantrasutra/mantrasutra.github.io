# SPDX-License-Identifier: AGPL-3.0-only
"""The ONE engine interface (DESIGN §9c condition 1). The CLI, the grid builder and the browser (Pyodide) all call
request(); phase 3 swaps the implementation for .t1 on yantra-wasm behind the same JSON shapes.

request({'op': 'parse', 'text': sūtra-document})            -> {'ok', 'canonical': text, 'sections': n}
request({'op': 'value', 'text': term, 'env': {...}, 'vals': {stem: number}, 'digits': d, 'complex': bool})
                                                             -> {'ok', 're', 'im', 'digits'}
    a term with round/iter/let/piece adds 'path' (exact | interval | uncertified), 'ties', 'decisions' and, when it has a
    round, 'twin': the unrounded twin's value (or its refusal), reported and never scored (DESIGN-loops §2.1)
request({'op': 'nearly', 'text': term, 'env', 'vals', 'printed': 'p/q', 'unit': 'p/q'})
                                                             -> {'ok', 'nearly': bool, 'decided': exact|interval}
request({'op': 'sample', 'text': term, 'env': {...}, 'axes': [...], 'fixed': {...}, 'complex': bool})
                                                             -> {'ok', 'shape', 're': bytes, 'im': bytes|None, 'mask': bytes}
Every refusal comes back as {'ok': False, 'code': 0x3A?/0x3B?, 'name': ..., 'why': ...}; nothing is guessed.
Sampling: each point is value() at DIGITS_GRID digits (two-precision agreement), then rounded to the nearest IEEE-754
double by mpmath's own rounding (deterministic, pure Python), so a grid is byte-identical on every venue (T-V).
A point that refuses (a pole, a branch, precision) is NaN with mask byte 1, never a guess."""
import struct
import mpmath
from fractions import Fraction
from .surface import parse, emit, SutraRefusal
from .statements import parse_doc, emit_doc
from .canon import canon, CanonRefusal
from .evaluate import value, certified, has_decision, unrounded, nearly

DIGITS_GRID = 17

def _env(e): return {k: tuple(v) for k, v in (e or {}).items()}

def _f64(x):
    with mpmath.workdps(40): return float(mpmath.mpf(x))   # mpmath rounds to nearest; Python float is IEEE-754 binary64

def _fail(e):
    if isinstance(e, SutraRefusal): return {'ok': False, 'code': e.code, 'name': e.name, 'why': str(e)}
    if isinstance(e, CanonRefusal): return {'ok': False, 'code': e.code, 'name': e.name, 'why': str(e)}
    return {'ok': False, 'code': 0x3A7, 'name': 'Unsupported', 'why': f'{type(e).__name__}: {e}'}

def axis_points(a):
    """{'name': stem, 'lo': 'p/q', 'hi': 'p/q', 'n': int} -> n exact rationals, lo..hi inclusive."""
    lo, hi, n = Fraction(a['lo']), Fraction(a['hi']), int(a['n'])
    return [lo + (hi - lo) * i / (n - 1) for i in range(n)]

def request(req):
    try:
        op = req['op']
        if op == 'parse':
            doc = parse_doc(req['text'])
            return {'ok': True, 'canonical': emit_doc(doc), 'sections': len(doc)}
        if op in ('from_input', 'from_sutra'): return _editor(req)
        if op == 'text':   # L1 (DESIGN v2): padaccheda + morphology + agreement/samāsa links, from the shipped lexicon
            global _L1
            if '_L1' not in globals() or _L1 is None:
                from .text import from_data
                _L1 = from_data(str(_pl.Path(__file__).parent / 'data/lexicon-product.tsv.gz'), role='product')
            text = req['text']
            if req.get('script', 'dev') == 'dev':
                from .ped.dev2iast import dev2iast
                text = dev2iast(text)
            return {'ok': True, **_L1.analyse(text)}
        if op == 'structure':   # L6: figures, each labelled verified or experimental (amendment 19)
            from .structure import analyse as _l6, VERIFIED, EXPERIMENTAL, RECORD
            text = req['text']
            if req.get('script') == 'iast':
                from .iast import to_devanagari
                text = to_devanagari(text)
            found = _l6(text)
            def label(k):
                f, n = RECORD.get(k, (0, 0))
                return (f'verified on {n} held-out example' + ('s' if n != 1 else '')) if k in VERIFIED else f'experimental (scored held-out: {f}/{n})'
            return {'ok': True, 'figures': [{'figure': k, 'evidence': v, 'status': 'verified' if k in VERIFIED else 'experimental',
                                             'record': list(RECORD.get(k, (0, 0))), 'label': label(k)} for k, v in found.items() if v],
                    'note': 'verified = every scored held-out item found, 0 false positives; the number of held-out examples is shown, and n = 1 is not robust'}
        if op == 'verse':   # L2 prosody (DESIGN v2); Devanagari, or IAST with 'script': 'iast'
            from .prosody import analyse as _l2
            text = req['text']
            if req.get('script') == 'iast':
                from .iast import to_devanagari
                text = to_devanagari(text)
            r = _l2(text, req.get('cite', ''))
            return {'ok': True, **r}
        if op == 'words':
            from .surface import W as _W
            from .endings import form as _form
            heads = {r: _form(v[0], v[1], 'nom') if v[1] in 'mn' else v[0] for r, v in _W.items() if v[2] != 'TBD'}   # placeholders are never offered as words
            return {'ok': True, 'words': heads, 'table': default_table()}
        env = _env(req.get('env'))
        t = parse(req['text'], env)
        if canon(t) != t: raise SutraRefusal(0x3A4, 'NonCanonical', 'the term is not in प्रकृतिः form')
        cx = bool(req.get('complex'))
        if op == 'value':
            with mpmath.workdps(int(req.get('digits', 30)) + 60):   # exact rationals kept beyond value()'s digits+40 (was: the ambient 15 digits)
                vals = {k: mpmath.mpf(Fraction(v).numerator) / Fraction(v).denominator for k, v in (req.get('vals') or {}).items()}
            digits = int(req.get('digits', 30))
            if not has_decision(t):
                v, d = value(t, vals, digits, cx)
                return {'ok': True, 're': mpmath.nstr(mpmath.re(v), d), 'im': mpmath.nstr(mpmath.im(v), d), 'digits': d}
            exact = {k: Fraction(v) for k, v in (req.get('vals') or {}).items()}
            r = certified(t, vals, digits, cx, exact)
            v, d = r['value'], r['digits']
            out = {'ok': True, 're': mpmath.nstr(mpmath.re(v), d), 'im': mpmath.nstr(mpmath.im(v), d), 'digits': d,
                   'path': r['path'], 'ties': r['ties'], 'decisions': r['decisions'],
                   'decided_on_intervals': r['decided_on_intervals'], 'arb_check': r['arb_check']}
            if 'exact' in r: out['exact'] = str(r['exact'])
            tw = unrounded(t)
            if tw != t:
                try:
                    rt = certified(tw, vals, digits, cx, exact)
                    out['twin'] = {'ok': True, 're': mpmath.nstr(mpmath.re(rt['value']), d), 'im': mpmath.nstr(mpmath.im(rt['value']), d), 'path': rt['path']}
                except SutraRefusal as e: out['twin'] = _fail(e)
            return out
        if op == 'nearly':
            exact = {k: Fraction(v) for k, v in (req.get('vals') or {}).items()}
            with mpmath.workdps(60): vals = {k: mpmath.mpf(q.numerator) / q.denominator for k, q in exact.items()}
            ok, how = nearly(t, Fraction(req['printed']), Fraction(req['unit']), vals, exact, cx)
            return {'ok': True, 'nearly': ok, 'decided': how}
        if op == 'sample':
            axes = req['axes']; fixed = {k: Fraction(v) for k, v in (req.get('fixed') or {}).items()}
            pts = [axis_points(a) for a in axes]
            shape = [len(p) for p in pts]
            re_, im_, mask = bytearray(), bytearray(), bytearray()
            def at(idx):   # inputs at the ambient binary64 precision: a grid is an f64 grid of f64 inputs (T-V grids depend on it)
                vals = {k: mpmath.mpf(v.numerator) / v.denominator for k, v in fixed.items()}
                z = None
                for a, p, i in zip(axes, pts, idx):
                    x = mpmath.mpf(p[i].numerator) / p[i].denominator
                    if a.get('complex_part') == 'im': z = (z or 0) + mpmath.mpc(0, x)
                    elif a.get('complex_part') == 're': z = (z or 0) + x
                    else: vals[a['name']] = x
                if z is not None: vals[axes[0]['name']] = z
                if req.get('sphere'):   # axes are (latitude, longitude) in degrees; inverse stereographic from the north pole
                    lat, lon = (mpmath.mpf(pts[j][idx[j]].numerator) / pts[j][idx[j]].denominator for j in (0, 1))
                    th = mpmath.radians(90 - lat)
                    if th == 0: raise SutraRefusal(0x3AB, 'NumericalCheckFailed', 'the north pole is ∞')
                    vals = {k: v for k, v in vals.items() if k not in (axes[0]['name'], axes[1]['name'])}
                    vals[req['sphere']] = mpmath.cot(th / 2) * mpmath.expjpi(lon / 180)
                return vals
            import itertools
            for idx in itertools.product(*[range(n) for n in reversed(shape)]):
                idx = tuple(reversed(idx))
                try:
                    v, _ = value(t, at(idx), DIGITS_GRID, cx)
                    if not mpmath.isfinite(v): raise ValueError('not finite')
                    re_ += struct.pack('<d', _f64(mpmath.re(v))); im_ += struct.pack('<d', _f64(mpmath.im(v))); mask.append(0)
                except (SutraRefusal, ZeroDivisionError, ValueError):
                    re_ += struct.pack('<d', float('nan')); im_ += struct.pack('<d', float('nan')); mask.append(1)
            return {'ok': True, 'shape': shape, 're': bytes(re_), 'im': bytes(im_) if cx else None, 'mask': bytes(mask)}
        raise SutraRefusal(0x3A7, 'Unsupported', f'op {op}')
    except Exception as e:
        return _fail(e)


# ---- the formula editor (DESIGN §9c) ----
import pathlib as _pl
_L1 = None
def default_table():
    """identifier -> [stem, kind, gender] from sutra/letters.tsv (d8-accepted); every name a variable by default."""
    rows = [l.split('\t') for l in (_pl.Path(__file__).parent / 'letters.tsv').read_text(encoding='utf8').splitlines() if l and not l.startswith('#')]
    return {i: [s, 'var', g] for i, s, g in rows}

def _editor(req):
    from .latex import parse_input, to_latex
    from .gloss import english, sanskrit
    from .statements import emit_decl, KIND_WORD
    from .surface import W as _W, BUILTIN
    table = {**default_table(), **(req.get('table') or {})}
    names = {i: (v[0], v[1]) for i, v in table.items()}
    env = {v[0]: (v[1], 0, v[2]) for v in table.values()}
    ident_of = {v[0]: i for i, v in table.items()}
    if req['op'] == 'from_input':
        t = canon(parse_input(req['input'], names, req.get('kind') == 'plain'))
    else:
        t = parse(req['text'], env)
        if canon(t) != t: raise SutraRefusal(0x3A4, 'NonCanonical', 'the sūtra is not in प्रकृतिः form')
    from .statements import names_used
    used = [s for s in names_used(t, {}) if s in env]
    decl = ' '.join([_W['SECTION'][0]] + [emit_decl((s, env[s][0], 0, None, env[s][2])) for s in used] + [_W['END'][0]])
    resolved = [{'identifier': ident_of[s], 'stem': s, 'reading': 'variable'} for s in used]
    resolved += [{'identifier': k, 'stem': v[0], 'reading': 'function'} for k, v in _W.items() if v[0] in _fns(t)]
    label = lambda st: ident_of.get(st, st)
    return {'ok': True, 'sutra': emit(t, env), 'declarations': decl, 'latex': to_latex(t, {s: ident_of[s] for s in ident_of}),
            'gloss_en': english(t, label), 'gloss_sa': sanskrit(t, env), 'resolved': resolved,
            'env': {s: list(env[s]) for s in used}, 'free': [ident_of[s] for s in used if env[s][0] == 'var']}

def _fns(t, out=None):
    from .terms import children
    out = set() if out is None else out
    if t[0] == 'app': out.add(t[1])
    for c in children(t): _fns(c, out)
    return out

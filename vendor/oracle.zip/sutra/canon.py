# SPDX-License-Identifier: AGPL-3.0-only
"""प्रकृतिः, the canonical form (DESIGN §2). Bottom-up, one pass per node; idempotent (tested).

1. sub/div/neg/sqrt -> sum with (-1)·, pow(·, -1), pow(·, 1/2)
2. sum and prod flattened
3. numeric subterms folded exactly; one leading rational coefficient per product, one constant per sum
4. like bases in a product merged syntactically: x^a · x^b -> x^(a+b). No expansion, factoring or trig rewriting.
5. operands of sum and prod sorted by ORDER: rank, then size, then a structural key with names in varṇa order.
A power folds only number^integer (exact), and only when the result has at most FOLD_DIGITS decimal digits. 0^negative is the refusal ZeroToNegativePower.

Recurrences and rounding (DESIGN-loops §1.3): ranks are appended (round 11, iter 12, let 13), so no earlier canonical
text changes. quot/rem are input-only sugar for round. round's children are canonicalised and it folds exactly when x and
unit are both numerals; a numeric unit ≤ 0 is the refusal BadRoundingUnit (0x3B4). round is not simplified further.
iter is NEVER folded (folding would run the loop inside canon and erase the procedure); let is never inlined. Uniqueness
stays syntactic: a permuted state, an unused component, another budget, or a let against its inlined body are different
canonical terms that compute the same function."""
import math
from fractions import Fraction
from .terms import children, size, MODES, ITER_MAX, RELS
from . import varna

FOLD_DIGITS = 1000   # number^integer folds only when the exact result has at most this many decimal digits

RANK = {'num': 0, 'const': 1, 'var': 2, 'rate': 2, 'bvar': 2, 'app': 3, 'pow': 4, 'prod': 5, 'sum': 6,
        'deriv': 7, 'bind': 8, 'lim': 9, 'piece': 10, 'round': 11, 'iter': 12, 'let': 13}

class CanonRefusal(Exception):
    def __init__(self, name, why, code=0x3AB): super().__init__(f'{name}: {why}'); self.name, self.code = name, code

def _rank(t):
    k = t[0]
    return RANK[t[2]] if k == 'name' else RANK[k]

def skey(t):
    """A total structural key; names compare in varṇa order."""
    k = t[0]
    if k == 'num': return (0, t[1].numerator, t[1].denominator)
    if k == 'name': return (1, varna.key(t[1]), t[2])
    if k == 'bvar': return (2, t[1])
    if k == 'app': return (3, varna.key(t[1]), tuple(skey(c) for c in t[2]))
    if k == 'bind': return (4, t[1], t[5] or '', tuple(skey(c) for c in children(t)))
    if k == 'lim': return (5, t[2], tuple(skey(c) for c in children(t)))
    if k == 'piece': return (6, tuple((c[1], skey(c[2]), skey(c[3]), skey(v)) for c, v in t[1]), skey(t[2]))
    if k == 'round': return (8, t[3], tuple(skey(c) for c in children(t)))
    if k == 'iter': return (9, len(t[1]), t[5], t[3][1], tuple(skey(c) for c in children(t)))
    if k == 'let': return (10, tuple(skey(c) for c in children(t)))
    return (7, k, tuple(skey(c) for c in children(t)))

def order(t): return (_rank(t), size(t), skey(t))

def _num(t): return t[0] == 'num'
def N(v): return ('num', Fraction(v))

def _sum(ops):
    flat = []
    for o in ops: flat.extend(o[1] if o[0] == 'sum' else (o,))
    c = sum((o[1] for o in flat if _num(o)), Fraction(0))
    rest = [o for o in flat if not _num(o)]
    if c != 0 or not rest: rest.append(N(c))
    if len(rest) == 1: return rest[0]
    return ('sum', tuple(sorted(rest, key=order)))

def _split_pow(f): return (f[1], f[2]) if f[0] == 'pow' else (f, N(1))

def _prod(ops):
    flat = []
    for o in ops: flat.extend(o[1] if o[0] == 'prod' else (o,))
    c = Fraction(1)
    for o in flat:
        if _num(o): c *= o[1]
    if c == 0: return N(0)
    bases, seen = {}, []
    for o in flat:
        if _num(o): continue
        b, e = _split_pow(o)
        if b in bases: bases[b].append(e)
        else: bases[b] = [e]; seen.append(b)
    rest = []
    for b in seen:
        es = bases[b]
        p = _pow(b, es[0] if len(es) == 1 else _sum(es))
        if _num(p): c *= p[1]
        elif p[0] == 'prod':   # a folded power can expose a coefficient (never here for non-numeric bases, kept total)
            for q in p[1]:
                if _num(q): c *= q[1]
                else: rest.append(q)
        else: rest.append(p)
    if c == 0: return N(0)
    if c != 1 or not rest: rest.append(N(c))
    if len(rest) == 1: return rest[0]
    return ('prod', tuple(sorted(rest, key=order)))

def _pow(b, e):
    if _num(e) and e[1] == 1: return b
    if _num(e) and e[1] == 0: return N(1)
    if _num(b) and _num(e) and e[1].denominator == 1:
        if b[1] == 0 and e[1] < 0: raise CanonRefusal('ZeroToNegativePower', '0 raised to a negative power')
        big = max(abs(b[1].numerator), b[1].denominator)
        if big <= 1 or abs(int(e[1])) * math.log10(big) <= FOLD_DIGITS + 1:   # cheap bound, then the exact digit count
            r = b[1] ** int(e[1])
            if max(len(str(abs(r.numerator))), len(str(r.denominator))) <= FOLD_DIGITS: return N(r)
        return ('pow', b, e)   # the exact result would exceed FOLD_DIGITS digits: kept as a power (still canonical)
    if _num(b) and b[1] == 1: return N(1)
    return ('pow', b, e)

def round_exact(x, u, mode):
    """x, u Fractions, u > 0 -> (the multiple of u, tie?). down: u·⌊x/u⌋; near: nearest multiple, a tie away from zero."""
    q = x / u
    if mode == 'down': return u * (q.numerator // q.denominator), False
    a = abs(q); k = (a + Fraction(1, 2)).__floor__()
    return u * (k if q >= 0 else -k), (a - int(a)) == Fraction(1, 2)

def _round(x, u, mode):
    if mode not in MODES: raise CanonRefusal('MalformedSutra', f'rounding mode {mode!r}', 0x3A1)
    if _num(u) and u[1] <= 0: raise CanonRefusal('BadRoundingUnit', f'a rounding unit or divisor {u[1]} ≤ 0', 0x3B4)
    if _num(x) and _num(u): return N(round_exact(x[1], u[1], mode)[0])
    return ('round', x, u, mode)

def canon(t):
    k = t[0]
    if k in ('num', 'name', 'bvar'): return t
    if k == 'sub': return _sum([canon(t[1]), _prod([N(-1), canon(t[2])])])
    if k == 'neg': return _prod([N(-1), canon(t[1])])
    if k == 'div': return _prod([canon(t[1]), _pow(canon(t[2]), N(-1))])
    if k == 'sqrt': return _pow(canon(t[1]), N(Fraction(1, 2)))
    if k == 'sum': return _sum([canon(c) for c in t[1]])
    if k == 'prod': return _prod([canon(c) for c in t[1]])
    if k == 'pow': return _pow(canon(t[1]), canon(t[2]))
    if k == 'app': return ('app', t[1], tuple(canon(c) for c in t[2]))
    if k == 'deriv': return ('deriv', canon(t[1]), t[2])
    if k == 'bind': return ('bind', t[1], canon(t[2]), canon(t[3]), canon(t[4]), t[5])
    if k == 'lim': return ('lim', canon(t[1]), t[2], canon(t[3]))
    if k == 'piece': return ('piece', tuple((('rel', c[1], canon(c[2]), canon(c[3])), canon(v)) for c, v in t[1]), canon(t[2]))
    if k == 'round': return _round(canon(t[1]), canon(t[2]), t[3])
    if k == 'quot': return _round(_prod([canon(t[1]), _pow(canon(t[2]), N(-1))]), N(1), 'down')
    if k == 'rem':
        a, b = canon(t[1]), canon(t[2])
        return _sum([a, _prod([N(-1), _round(a, b, 'down')])])
    if k == 'iter':
        inits, steps, stop, out, budget = t[1:]
        if not inits or len(inits) != len(steps): raise CanonRefusal('MalformedSutra', 'an iter needs k ≥ 1 inits and k steps', 0x3A1)
        if type(budget) is not int or not 1 <= budget <= ITER_MAX: raise CanonRefusal('MalformedSutra', f'a budget is an integer 1..{ITER_MAX}', 0x3A1)
        if stop[0] != 'rel' or stop[1] not in RELS: raise CanonRefusal('MalformedSutra', 'the stop is a relation', 0x3A1)
        return ('iter', tuple(canon(c) for c in inits), tuple(canon(c) for c in steps),
                ('rel', stop[1], canon(stop[2]), canon(stop[3])), canon(out), budget)
    if k == 'let': return ('let', canon(t[1]), canon(t[2]))
    raise ValueError(f'unknown node {k}')

# SPDX-License-Identifier: AGPL-3.0-only
"""Varṇa order (GRAMMAR-proposal §2): a word's sort key is its phoneme sequence, each phoneme ranked by its place in
the varṇamālā: vowels, then anusvāra/visarga/candrabindu, then consonants. Not Unicode code-point order (which puts
ं and ः before the vowels). Characters outside the table rank after all of them, by code point."""

VOWELS = 'अ आ इ ई उ ऊ ऋ ॠ ऌ ॡ ए ऐ ओ औ'.split()
MARKS = ['ं', 'ः', 'ँ']
CONSONANTS = 'क ख ग घ ङ च छ ज झ ञ ट ठ ड ढ ण त थ द ध न प फ ब भ म य र ल व श ष स ह ळ'.split()
SIGNS = {'ा': 'आ', 'ि': 'इ', 'ी': 'ई', 'ु': 'उ', 'ू': 'ऊ', 'ृ': 'ऋ', 'ॄ': 'ॠ', 'ॢ': 'ऌ', 'ॣ': 'ॡ',
         'े': 'ए', 'ै': 'ऐ', 'ो': 'ओ', 'ौ': 'औ'}
VIRAMA = '्'
RANK = {p: i for i, p in enumerate(VOWELS + MARKS + CONSONANTS)}

def key(word):
    out, i, n = [], 0, len(word)
    while i < n:
        c = word[i]
        if c in CONSONANTS:
            out.append(RANK[c]); nxt = word[i + 1] if i + 1 < n else ''
            if nxt == VIRAMA: i += 2; continue
            if nxt in SIGNS: out.append(RANK[SIGNS[nxt]]); i += 2; continue
            out.append(RANK['अ']); i += 1; continue
        out.append(RANK[c] if c in RANK else 1000 + ord(c)); i += 1
    return (tuple(out), word.encode('utf8'))

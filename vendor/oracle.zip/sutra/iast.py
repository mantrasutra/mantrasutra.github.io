# SPDX-License-Identifier: AGPL-3.0-only
"""IAST -> Devanagari (deterministic, greedy longest match), for sources published in IAST (DCS). Spaces, daṇḍas and
digits pass through; an apostrophe is the avagraha. A consonant before a vowel takes its mātrā (inherent a: none); a
consonant before anything else takes a virāma."""
V = {'a': 'अ', 'ā': 'आ', 'i': 'इ', 'ī': 'ई', 'u': 'उ', 'ū': 'ऊ', 'ṛ': 'ऋ', 'ṝ': 'ॠ', 'ḷ': 'ऌ', 'ḹ': 'ॡ', 'e': 'ए', 'ai': 'ऐ', 'o': 'ओ', 'au': 'औ'}
M = {'a': '', 'ā': 'ा', 'i': 'ि', 'ī': 'ी', 'u': 'ु', 'ū': 'ू', 'ṛ': 'ृ', 'ṝ': 'ॄ', 'ḷ': 'ॢ', 'ḹ': 'ॣ', 'e': 'े', 'ai': 'ै', 'o': 'ो', 'au': 'ौ'}
C = {'kh': 'ख', 'gh': 'घ', 'ch': 'छ', 'jh': 'झ', 'ṭh': 'ठ', 'ḍh': 'ढ', 'th': 'थ', 'dh': 'ध', 'ph': 'फ', 'bh': 'भ',
     'k': 'क', 'g': 'ग', 'ṅ': 'ङ', 'c': 'च', 'j': 'ज', 'ñ': 'ञ', 'ṭ': 'ट', 'ḍ': 'ड', 'ṇ': 'ण', 't': 'त', 'd': 'द', 'n': 'न',
     'p': 'प', 'b': 'ब', 'm': 'म', 'y': 'य', 'r': 'र', 'l': 'ल', 'v': 'व', 'ś': 'श', 'ṣ': 'ष', 's': 'स', 'h': 'ह'}
X = {'ṃ': 'ं', 'ṁ': 'ं', 'ḥ': 'ः', "'": 'ऽ', '’': 'ऽ', 'm̐': 'ँ'}
TOKENS = sorted(list(V) + list(C) + list(X), key=len, reverse=True)

def to_devanagari(s):
    import unicodedata
    s = unicodedata.normalize('NFC', s.lower())
    toks, i = [], 0
    while i < len(s):
        for t in TOKENS:
            if s.startswith(t, i): toks.append(t); i += len(t); break
        else: toks.append(s[i]); i += 1
    out = []
    for k, t in enumerate(toks):
        nxt = toks[k + 1] if k + 1 < len(toks) else ''
        if t in C: out.append(C[t] + ('' if nxt in V else '्'))
        elif t in V: out.append(M[t] if k and toks[k - 1] in C else V[t])
        elif t in X: out.append(X[t])
        else: out.append(t)
    return ''.join(out)

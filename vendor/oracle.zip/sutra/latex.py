# SPDX-License-Identifier: AGPL-3.0-only
"""Formula editor input (DESIGN §9c): a stated SUBSET of LaTeX (what MathLive emits) and plain text (x^2/(1+e^x)),
both into terms; and canonical terms back to LaTeX for KaTeX. Anything outside the subset is refused by code, never
guessed: 0x3A0 unknown token/command, 0x3A1 malformed, 0x3A2 an identifier with no mapped name, 0x3A7 unsupported.

Subset: integers and decimals (exact: 0.25 = 1/4); identifiers (one letter, or \\alpha … \\omega, optionally with a
subscript of letters/digits) mapped by `names` {identifier: stem}; + − · × / ^ _ ( ) [ ] { }; implicit
multiplication by juxtaposition; \\frac{a}{b}, \\dfrac, \\tfrac; \\sqrt{a}, \\sqrt[n]{a}; \\left/\\right; functions
\\exp \\log \\ln \\sin \\cos \\tan \\arcsin \\arccos \\arctan \\sinh \\cosh \\tanh \\Gamma \\zeta \\operatorname{Li}_s
\\Re \\Im |…|; constants \\pi, e, i, \\infty; \\sum_{k=a}^{b}, \\prod_{k=a}^{b}, \\int_{a}^{b} … \\,dx, \\lim_{x\\to a};
\\frac{d}{dx}. Plain text adds ** for ^, sqrt(…), and f(x) call syntax for the named functions."""
import re
from fractions import Fraction
from .surface import W, SutraRefusal

OPNAME = {'Z': 'HARDY_Z', 'conj': 'CONJ', 'arg': 'ARG'}
FN_CMD = {'exp': 'EXP', 'log': 'LOG', 'ln': 'LOG', 'sin': 'SIN', 'cos': 'COS', 'tan': 'TAN', 'arcsin': 'ASIN', 'arccos': 'ACOS',
          'arctan': 'ATAN', 'sinh': 'SINH', 'cosh': 'COSH', 'tanh': 'TANH', 'Gamma': 'GAMMA', 'zeta': 'ZETA', 'Re': 'RE', 'Im': 'IM'}
GREEK = set('alpha beta gamma delta epsilon varepsilon zeta eta theta vartheta iota kappa lambda mu nu xi omicron rho sigma tau upsilon phi varphi chi psi omega Delta Theta Lambda Xi Pi Sigma Phi Psi Omega'.split())
CONST = {'pi': 'PI', 'infty': 'INF'}
IGNORE = {'left', 'right', ',', ';', '!', 'quad', 'qquad', 'displaystyle', ' '}

def refuse(code, name, why): raise SutraRefusal(code, name, why)

def tokenize(s, plain=False):
    toks, i, n = [], 0, len(s)
    while i < n:
        c = s[i]
        if c.isspace(): i += 1; continue
        if c == '\\':
            m = re.match(r'\\([A-Za-z]+|.)', s[i:])
            cmd = m.group(1); i += len(m.group(0))
            if cmd in IGNORE: continue
            if cmd in ('cdot', 'times'): toks.append(('op', '·')); continue
            toks.append(('cmd', cmd)); continue
        if c.isdigit() or (c == '.' and i + 1 < n and s[i + 1].isdigit()):
            m = re.match(r'\d*\.?\d+', s[i:]); toks.append(('num', m.group(0))); i += len(m.group(0)); continue
        if c.isalpha():
            if plain:
                m = re.match(r'[A-Za-z]+', s[i:]); w = m.group(0)
                if w in FN_CMD or w in ('sqrt', 'pi', 'inf'): toks.append(('cmd', {'inf': 'infty'}.get(w, w))); i += len(w); continue
            toks.append(('id', c)); i += 1; continue
        if plain and s.startswith('**', i): toks.append(('op', '^')); i += 2; continue
        if c in '+-*/^_()[]{}|=,': toks.append(('op', {'*': '·'}.get(c, c))); i += 1; continue
        if c in '·×−': toks.append(('op', {'×': '·', '−': '-'}.get(c, c))); i += 1; continue
        refuse(0x3A0, 'UnknownWord', f'character {c!r} at {i}')
    return toks

class P:
    def __init__(self, toks, names): self.t, self.i, self.names, self.bound = toks, 0, names, []
    def peek(self, k=0): return self.t[self.i + k] if self.i + k < len(self.t) else None
    def take(self, want=None):
        tk = self.peek()
        if tk is None or (want and tk != want): refuse(0x3A1, 'MalformedSutra', f'expected {want and want[1]!r}, found {tk and tk[1]!r}')
        self.i += 1; return tk
    def group(self):
        if self.peek() == ('op', '{'): self.take(); e = self.expr(); self.take(('op', '}')); return e
        return self.atom()
    def ident(self, base):
        nm = base
        if self.peek() == ('op', '_'):
            self.take(); sub = ''
            if self.peek() == ('op', '{'):
                self.take()
                while self.peek() != ('op', '}'): sub += self.take()[1]
                self.take()
            else: sub = self.take()[1]
            nm += '_' + sub
        return nm
    def args(self, n):
        self.take(('op', '(')); a = [self.expr()]
        while self.peek() == ('op', ','): self.take(); a.append(self.expr())
        self.take(('op', ')'))
        if n is not None and len(a) != n: refuse(0x3A1, 'MalformedSutra', f'{n} argument(s) expected, {len(a)} given')
        return tuple(a)
    def _applied_after_sub(self):
        j = self.i + 1
        if j < len(self.t) and self.t[j] == ('op', '{'):
            depth = 0
            while j < len(self.t):
                depth += self.t[j] == ('op', '{'); depth -= self.t[j] == ('op', '}')
                j += 1
                if depth == 0: break
        else: j += 1
        return j < len(self.t) and self.t[j] == ('op', '(')
    def name_term(self, nm):
        if nm in self.bound: return ('bvar', self.bound[::-1].index(nm))   # de Bruijn: 0 = the innermost binder
        if nm == 'e': return ('name', W['E_CONST'][0], 'const')
        if nm == 'i': return ('name', W['IMAG_UNIT'][0], 'const')
        if nm not in self.names: refuse(0x3A2, 'UndeclaredName', f'{nm} has no mapped name (map it in the table, it is never invented)')
        stem, kind = self.names[nm]; return ('name', stem, kind)
    # expr := term (('+'|'-') term)*
    def expr(self):
        ts = [self.term()]
        while self.peek() in (('op', '+'), ('op', '-')):
            op = self.take()[1]; t = self.term(); ts.append(t if op == '+' else ('neg', t))
        return ts[0] if len(ts) == 1 else ('sum', tuple(ts))
    # term := unary ((·|/|juxtaposition) unary)*
    def term(self):
        f = self.unary()
        while True:
            tk = self.peek()
            if tk in (('op', '·'),): self.take(); f = ('prod', (f, self.unary())); continue
            if tk == ('op', '/'): self.take(); f = ('div', f, self.unary()); continue
            if tk and (tk[0] in ('num', 'id') or tk in (('op', '('), ('op', '{'), ('op', '|')) or (tk[0] == 'cmd' and tk[1] not in ('to',))):
                if tk == ('op', '|') and self._closing_bar(): return f
                if tk[0] == 'id' and tk[1] == 'd' and self._is_dx(): return f
                f = ('prod', (f, self.unary())); continue
            return f
    def _closing_bar(self): return getattr(self, 'in_bar', 0) > 0
    def _is_dx(self): return getattr(self, 'in_int', 0) > 0 and self.peek(1) is not None and self.peek(1)[0] == 'id'
    def unary(self):
        if self.peek() == ('op', '-'): self.take(); return ('neg', self.unary())
        if self.peek() == ('op', '+'): self.take(); return self.unary()
        return self.power()
    def power(self):
        b = self.atom()
        if self.peek() == ('op', '^'): self.take(); return ('pow', b, self.exponent())
        return b
    def exponent(self):
        if self.peek() == ('op', '{'): return self.group()
        if self.peek() == ('op', '-'): self.take(); return ('neg', self.exponent())
        return self.atom()
    def atom(self):
        tk = self.take()
        k, v = tk
        if k == 'num':
            return ('num', Fraction(v))
        if k == 'id':
            if v == 'W' and self.peek() == ('op', '('): return ('app', W['LAMBERT_W0'][0], self.args(1))
            if v == 'W' and self.t[self.i:self.i + 5] == [('op', '_'), ('op', '{'), ('op', '-'), ('num', '1'), ('op', '}')] and self.peek(5) == ('op', '('):
                self.i += 5; return ('app', W['LAMBERT_WM1'][0], self.args(1))
            if v in 'JYIK' and self.peek() == ('op', '_') and self._applied_after_sub():
                self.take(); order = self.group(); (x,) = self.args(1)
                return ('app', W['BESSEL_' + v][0], (order, x))
            return self.name_term(self.ident(v))
        if tk in (('op', '('), ('op', '['), ('op', '{')):
            close = {'(': ')', '[': ']', '{': '}'}[v]; e = self.expr(); self.take(('op', close)); return e
        if tk == ('op', '|'):
            self.in_bar = getattr(self, 'in_bar', 0) + 1; e = self.expr(); self.take(('op', '|')); self.in_bar -= 1
            return ('app', W['ABS'][0], (e,))
        if k == 'cmd':
            if v in ('frac', 'dfrac', 'tfrac'):
                if self.peek() == ('op', '{') and self.peek(1) == ('id', 'd') and self.peek(2) == ('op', '}'):
                    self.i += 3; self.take(('op', '{')); self.take(('id', 'd')); var = self.ident(self.take()[1]); self.take(('op', '}'))
                    body = self.power() if self.peek() != ('op', '(') else self.atom()
                    vt = self.name_term(var)
                    if vt[0] != 'name' or vt[2] not in ('var', 'rate'): refuse(0x3A7, 'Unsupported', 'd/dx needs a declared variable')
                    return ('deriv', body, vt)
                a = self.group(); b = self.group(); return ('div', a, b)
            if v == 'sqrt':
                if self.peek() == ('op', '['):
                    self.take(); n = self.expr(); self.take(('op', ']')); a = self.group(); return ('pow', a, ('div', ('num', Fraction(1)), n))
                return ('sqrt', self.group())
            if v in ('Gamma', 'zeta') and self.peek() != ('op', '('):   # not applied: the table variable (d8 rule)
                return self.name_term(self.ident('\\' + v))
            if v == 'zeta':
                a = self.args(None)
                if len(a) not in (1, 2): refuse(0x3A1, 'MalformedSutra', 'ζ takes s, or s and a (Hurwitz)')
                return ('app', W['ZETA' if len(a) == 1 else 'HURWITZ_ZETA'][0], a)
            if v in ('eta', 'Lambda') and self.peek() == ('op', '('):
                return ('app', W['DIRICHLET_ETA' if v == 'eta' else 'VON_MANGOLDT'][0], self.args(1))
            if v == 'lambda' and self.peek() == ('op', '('):
                refuse(0x3AF, 'AmbiguousBranch', 'λ(·) is Dirichlet λ(s) or Carmichael λ(n): write \\lambda_{D} or \\lambda_{C}')
            if v == 'lambda' and self.t[self.i:self.i + 4] in ([('op', '_'), ('op', '{'), ('id', 'D'), ('op', '}')], [('op', '_'), ('op', '{'), ('id', 'C'), ('op', '}')]) and self.peek(4) == ('op', '('):
                which = self.t[self.i + 2][1]; self.i += 4
                return ('app', W['DIRICHLET_LAMBDA' if which == 'D' else 'CARMICHAEL_LAMBDA'][0], self.args(1))
            if v in FN_CMD:
                arg = self.atom() if self.peek() in (('op', '('), ('op', '['), ('op', '{')) else self.power()
                return ('app', W[FN_CMD[v]][0], (arg,))
            if v == 'operatorname':
                self.take(('op', '{')); nm = ''
                while self.peek() != ('op', '}'): nm += self.take()[1]
                self.take()
                if nm in OPNAME and self.peek() == ('op', '('): return ('app', W[OPNAME[nm]][0], self.args(1))
                if nm == 'Li' and self.peek() == ('op', '_'):
                    self.take(); s = self.group(); z = self.atom(); return ('app', W['POLYLOG'][0], (s, z))
                refuse(0x3A7, 'Unsupported', f'operator {nm}')
            if v in CONST: return ('name', W[CONST[v]][0], 'const') if v != 'infty' else ('name', W['INF'][0], 'const')
            if v in GREEK: return self.name_term(self.ident('\\' + v))
            if v in ('sum', 'prod', 'int'):
                lo = hi = None; var = None
                for _ in range(2):
                    if self.peek() == ('op', '_'):
                        self.take()
                        if v == 'int': lo = self.group()
                        else:
                            self.take(('op', '{')); var = self.ident(self.take()[1]); self.take(('op', '=')); lo = self.expr(); self.take(('op', '}'))
                    elif self.peek() == ('op', '^'): self.take(); hi = self.group()
                if lo is None or hi is None: refuse(0x3A7, 'Unsupported', f'\\{v} needs both bounds')
                if v == 'int':
                    j = self.i; depth = 0; inner = 0   # each nested \int owns the next d<var> at its level
                    while j < len(self.t):
                        if self.t[j] in (('op', '('), ('op', '{')): depth += 1
                        if self.t[j] in (('op', ')'), ('op', '}')): depth -= 1
                        if depth == 0 and self.t[j] == ('cmd', 'int'): inner += 1
                        if depth == 0 and self.t[j] == ('id', 'd') and j + 1 < len(self.t) and self.t[j + 1][0] == 'id':
                            if inner == 0: var = self.t[j + 1][1]; break
                            inner -= 1
                        j += 1
                    if var is None: refuse(0x3A1, 'MalformedSutra', 'an integral needs its d<variable>')
                self.bound.append(var); self.in_int = getattr(self, 'in_int', 0) + (v == 'int')
                body = self.term(); self.bound.pop()
                if v == 'int': self.in_int -= 1; self.take(('id', 'd')); self.take(('id', var))
                return ('bind', {'sum': 'Σ', 'prod': 'Π', 'int': '∫'}[v], lo, hi, body, None)
            if v == 'lim':
                self.take(('op', '_')); self.take(('op', '{')); var = self.ident(self.take()[1]); self.take(('cmd', 'to'))
                j, depth = self.i, 0   # find the subscript's closing brace; a trailing ^{+} or ^{-} gives the side
                while j < len(self.t) and not (depth == 0 and self.t[j] == ('op', '}')):
                    depth += self.t[j] == ('op', '{'); depth -= self.t[j] == ('op', '}') and depth > 0; j += 1
                side = 'both'
                if j >= 4 and self.t[j - 4:j] in ([('op', '^'), ('op', '{'), ('op', '+'), ('op', '}')], [('op', '^'), ('op', '{'), ('op', '-'), ('op', '}')]):
                    side = 'right' if self.t[j - 2] == ('op', '+') else 'left'; del self.t[j - 4:j]
                pt = self.expr(); self.take(('op', '}'))
                self.bound.append(var); body = self.term(); self.bound.pop()
                return ('lim', pt, side, body)
            refuse(0x3A0, 'UnknownWord', f'\\{v} is outside the LaTeX subset')
        refuse(0x3A1, 'MalformedSutra', f'{v!r} cannot start a term')

def parse_input(s, names, plain=False):
    """LaTeX subset (plain=False) or plain text -> a raw term (प्रकृतिः not yet applied)."""
    p = P(tokenize(s, plain), names)
    if plain:   # f(x) call syntax: a function command followed by ( … ) is already handled by atom(); nothing more to do
        pass
    e = p.expr()
    if p.peek() is not None: refuse(0x3A1, 'MalformedSutra', f'unexpected {p.peek()[1]!r}')
    return e

# ---- canonical term -> LaTeX (for KaTeX) ----
def _body(t, latex_of, bound):   # a binder body is one product-level term when parsed back, so a sum is parenthesised
    s_ = to_latex(t, latex_of, bound)
    return f'\\left({s_}\\right)' if t[0] == 'sum' or s_.startswith('-') else s_
def _fresh(cands, latex_of, bound):
    used = set(latex_of.values()) | set(bound) | {'d', 'e', 'i'}
    for c in cands:
        if c not in used: return c
    refuse(0x3A7, 'Unsupported', 'no free letter for a bound variable')
def to_latex(t, latex_of, bound=()):
    """latex_of: stem -> LaTeX for a name (the editor's table, inverted)."""
    k = t[0]
    def L(x):   # a nested binder (Σ Π ∫ lim d/dx) is parenthesised: its body would otherwise absorb what follows it
        s_ = to_latex(x, latex_of, bound)
        return f'\\left({s_}\\right)' if x[0] in ('bind', 'lim', 'deriv') else s_
    if k == 'num':
        q = t[1]; s = str(abs(q.numerator)) if q.denominator == 1 else f'\\frac{{{abs(q.numerator)}}}{{{q.denominator}}}'
        return ('-' if q < 0 else '') + s
    if k == 'name':
        for r, tex in (('PI', '\\pi'), ('E_CONST', 'e'), ('IMAG_UNIT', 'i'), ('INF', '\\infty')):
            if t[1] == W[r][0]: return tex
        return latex_of.get(t[1], f'\\text{{{t[1]}}}')
    if k == 'bvar': return bound[len(bound) - 1 - t[1]]
    if k == 'sum':
        out = L(t[1][0])
        for c in t[1][1:]:
            s = L(c); out += (' ' + s) if s.startswith('-') else (' + ' + s)
        return out
    if k == 'prod':
        num, den = [], []
        for c in t[1]:
            if c[0] == 'pow' and c[2] == ('num', Fraction(-1)): den.append(c[1])   # only ^(−1) becomes a denominator: (x^4)^(−1) ≠ x^(−4) in प्रकृतिः
            else: num.append(c)
        par = lambda c: f'\\left({L(c)}\\right)' if c[0] == 'sum' else L(c)
        sign = ''
        if num and num[0][0] == 'num' and num[0][1] == -1: sign, num = '-', num[1:]
        ns = ' \\cdot '.join(par(c) for c in num) or '1'
        if not den: return sign + ns
        # one factor per \frac: (x·y)^(−1) is not x^(−1)·y^(−1) in प्रकृतिः, so two denominators never share a bar
        return sign + f'\\frac{{{ns}}}{{{L(den[0])}}}' + ''.join(f' \\cdot \\frac{{1}}{{{L(d)}}}' for d in den[1:])
    if k == 'pow' and t[2] == ('num', Fraction(-1)):   # a lone ^(−1) reads as a fraction
        return to_latex(('prod', (t,)), latex_of, bound)
    if k == 'pow':
        b = t[1]; bs = f'\\left({L(b)}\\right)' if b[0] in ('sum', 'prod', 'pow') or (b[0] == 'num' and (b[1] < 0 or b[1].denominator != 1)) else L(b)
        if t[2] == ('num', Fraction(1, 2)): return f'\\sqrt{{{L(b)}}}'
        return f'{bs}^{{{L(t[2])}}}'
    if k == 'app':
        inv = {W[v][0]: v for v in FN_CMD.values()}
        r = inv.get(t[1]) or next((r for r in W if W[r][0] == t[1]), t[1])
        if r == 'ABS': return f'\\left|{L(t[2][0])}\\right|'
        A = lambda: ', '.join(L(a) for a in t[2])
        special = {'GAMMA': '\\Gamma', 'ZETA': '\\zeta', 'HURWITZ_ZETA': '\\zeta', 'DIRICHLET_ETA': '\\eta', 'VON_MANGOLDT': '\\Lambda',
                   'LAMBERT_W0': 'W', 'LAMBERT_WM1': 'W_{-1}', 'DIRICHLET_LAMBDA': '\\lambda_{D}', 'CARMICHAEL_LAMBDA': '\\lambda_{C}',
                   'HARDY_Z': '\\operatorname{Z}', 'CONJ': '\\operatorname{conj}', 'ARG': '\\operatorname{arg}'}
        if r in special: return f'{special[r]}\\left({A()}\\right)'
        if r in ('BESSEL_J', 'BESSEL_Y', 'BESSEL_I', 'BESSEL_K'): return f'{r[-1]}_{{{L(t[2][0])}}}\\left({L(t[2][1])}\\right)'
        if r == 'POLYLOG': return f'\\operatorname{{Li}}_{{{L(t[2][0])}}}\\left({L(t[2][1])}\\right)'
        cmd = next((c for c, rr in FN_CMD.items() if rr == r and c != 'ln'), None)
        head = f'\\{cmd}' if cmd else f'\\operatorname{{{r.replace("_", " ").lower()}}}'
        return f'{head}\\left({", ".join(L(a) for a in t[2])}\\right)'
    if k == 'deriv': return f'\\frac{{d}}{{d{L(t[2])}}}\\left({L(t[1])}\\right)'
    if k == 'bind':
        v = _fresh('xkjmnpqtu' if t[1] == '∫' else 'kjmnpqtu', latex_of, bound); inner = _body(t[4], latex_of, bound + (v,))
        if t[1] == '∫': return f'\\int_{{{L(t[2])}}}^{{{L(t[3])}}} {inner} \\, d{v}'
        return f'\\{"sum" if t[1] == "Σ" else "prod"}_{{{v}={L(t[2])}}}^{{{L(t[3])}}} {inner}'
    if k == 'lim':
        v = _fresh('xyzuvw', latex_of, bound); side = {'both': '', 'right': '^{+}', 'left': '^{-}'}[t[2]]
        pt = L(t[1]); pt = f'\\left({pt}\\right)' if side and t[1][0] not in ('num', 'name', 'bvar') else pt
        return f'\\lim_{{{v} \\to {pt}{side}}} {_body(t[3], latex_of, bound + (v,))}'
    if k == 'round':   # display only (DESIGN-loops §1.2); the editor's input subset does not read these back
        x, u = to_latex(t[1], latex_of, bound), t[2]
        if t[3] == 'down' and u == ('num', Fraction(1)): return f'\\left\\lfloor {x} \\right\\rfloor'
        us = L(u)
        if t[3] == 'down': return f'{us} \\left\\lfloor \\frac{{{x}}}{{{us}}} \\right\\rfloor'
        return f'\\operatorname{{round}}_{{{us}}}\\left({x}\\right)'
    if k == 'let':
        v = _fresh('vwhpq', latex_of, bound)
        return f'\\left({to_latex(t[2], latex_of, bound + (v,))}\\right)_{{{v} = {L(t[1])}}}'
    if k == 'iter':
        n = len(t[1]); names = []
        for _ in range(n + 1): names.append(_fresh('iabcghrsuvwyz', latex_of, bound + tuple(names)))
        inner = bound + tuple(names)
        I = lambda x: to_latex(x, latex_of, inner)
        rel = {'lt': '<', 'le': '\\le', 'eq': '=', 'ne': '\\ne'}[t[3][1]]
        init = ',\\ '.join(f'{names[j + 1]} := {L(t[1][j])}' for j in range(n))
        step = ',\\ '.join(f'{names[j + 1]} \\gets {I(t[2][j])}' for j in range(n))
        return (f'\\operatorname{{iter}}_{{\\le {t[5]}}}\\left({names[0]} := 0,\\ {init};\\ {step};\\ '
                f'\\text{{until }} {I(t[3][2])} {rel} {I(t[3][3])};\\ {I(t[4])}\\right)')
    refuse(0x3A7, 'Unsupported', f'LaTeX for {k}')

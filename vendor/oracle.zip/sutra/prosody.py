# SPDX-License-Identifier: AGPL-3.0-only
"""L2 prosody (DESIGN v2 A1): a verse in Devanagari -> pādas -> syllables -> laghu/guru -> metre, prastāra index,
trace and a cited explanation. Rule-based and zero-data, so it applies to any verse, including verses not yet written.

Weight (Piṅgala, Chandaḥśāstra, as DESIGN A1 cites it, 1.4.10–12): a syllable is GURU when its vowel is long (dīrgha:
ā ī ū ṝ ḹ e ai o au), when anusvāra or visarga follows the vowel, or when a conjunct (saṃyoga: two or more consonants)
follows it, across word boundaries within the pāda; otherwise LAGHU. The last syllable of a pāda is ANCEPS (pādānta:
either weight is admitted); it is reported with its phonological weight and flagged.
Mātrā: laghu 1, guru 2. Gaṇas: the trika names of the mnemonic यमाताराजभानसलगाः.
Prastāra (uddiṣṭa): G = 0, L = 1, the first syllable the least significant bit, index = 1 + Σ 2^i over the laghu
positions i; naṣṭa is the inverse."""

VOWELS = {'अ': ('a', 0), 'आ': ('ā', 1), 'इ': ('i', 0), 'ई': ('ī', 1), 'उ': ('u', 0), 'ऊ': ('ū', 1), 'ऋ': ('ṛ', 0), 'ॠ': ('ṝ', 1),
          'ऌ': ('ḷ', 0), 'ॡ': ('ḹ', 1), 'ए': ('e', 1), 'ऐ': ('ai', 1), 'ओ': ('o', 1), 'औ': ('au', 1)}
SIGNS = {'ा': 'आ', 'ि': 'इ', 'ी': 'ई', 'ु': 'उ', 'ू': 'ऊ', 'ृ': 'ऋ', 'ॄ': 'ॠ', 'ॢ': 'ऌ', 'ॣ': 'ॡ', 'े': 'ए', 'ै': 'ऐ', 'ो': 'ओ', 'ौ': 'औ'}
VIRAMA, ANUSVARA, VISARGA, CANDRA, AVAGRAHA, NUKTA = '्', 'ं', 'ः', 'ँ', 'ऽ', '़'
CONS = set('कखगघङचछजझञटठडढणतथदधनपफबभमयरलवशषसहळ')
PADA_MARKS = '।॥'

GANA = {'LGG': 'य', 'GGG': 'म', 'GGL': 'त', 'GLG': 'र', 'LGL': 'ज', 'GLL': 'भ', 'LLL': 'न', 'LLG': 'स'}
GANA_NAME = {v: k for k, v in GANA.items()}

def segments(text):
    """Devanagari -> a list of segments ('C', akṣara) | ('V', vowel, long) | ('M', ं|ः) | ('B',) word boundary.
    Digits, daṇḍas, avagraha and other marks are not phonemes here (avagraha marks an elided अ, which has no syllable)."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c in CONS:
            j = i + 1
            if j < n and text[j] == NUKTA: j += 1
            out.append(('C', text[i:j]))
            if j < n and text[j] == VIRAMA: i = j + 1; continue
            if j < n and text[j] in SIGNS: v = SIGNS[text[j]]; out.append(('V', v, VOWELS[v][1])); i = j + 1; continue
            out.append(('V', 'अ', 0)); i = j; continue
        if c in VOWELS: out.append(('V', c, VOWELS[c][1])); i += 1; continue
        if c in (ANUSVARA, VISARGA, CANDRA): out.append(('M', c)); i += 1; continue
        if c.isspace() or c in '-‐': out.append(('B',)); i += 1; continue
        i += 1   # avagraha, digits, punctuation: no phonological content for weight
    return out

def syllables(pada):
    """One pāda -> [{'aksara': text, 'weight': 'G'|'L', 'why': rule, 'anceps': bool}]. For display, the first consonant
    of a cluster closes the preceding syllable (कर्-म), as the traditional division counts it."""
    seg = segments(pada)
    vidx = [k for k, s in enumerate(seg) if s[0] == 'V']
    parts = []
    for n_, k in enumerate(vidx):
        nxt = vidx[n_ + 1] if n_ + 1 < len(vidx) else len(seg)
        after = seg[k + 1:nxt]
        cons_after = sum(1 for s in after if s[0] == 'C')
        mark = any(s[0] == 'M' and s[1] in (ANUSVARA, VISARGA) for s in after)
        start = (vidx[n_ - 1] + 1) if n_ else 0
        onset = [s[1] for s in seg[start:k] if s[0] == 'C']
        last = n_ == len(vidx) - 1
        if seg[k][2]: w, why = 'G', 'dīrgha (long vowel)'
        elif mark: w, why = 'G', 'anusvāra/visarga follows'
        elif cons_after >= 2 and not last: w, why = 'G', 'saṃyoga (a conjunct follows)'
        elif cons_after >= 2 and last: w, why = 'G', 'saṃyoga at the pāda end'
        else: w, why = 'L', 'hrasva, no conjunct follows'
        marks = ''.join(s[1] for s in after if s[0] == 'M')
        coda = [s[1] for s in after if s[0] == 'C'] if last else []
        word_start = any(s[0] == 'B' for s in seg[start:k])   # the onset begins a new word
        parts.append([onset, seg[k][1], marks, coda, w, why, last, word_start])
    for n_ in range(1, len(parts)):   # display only: a cluster's first consonant closes the previous syllable, within a word
        if len(parts[n_][0]) >= 2 and not parts[n_][7]: parts[n_ - 1][3] = [parts[n_][0][0]] + parts[n_ - 1][3]; parts[n_][0] = parts[n_][0][1:]
    return [{'aksara': _aksara(o, v, m, c), 'weight': w, 'why': why, 'anceps': last} for o, v, m, c, w, why, last, _ in parts]

SIGN_OF = {v: m for m, v in SIGNS.items()}

def _aksara(onset, vowel, marks, coda):
    """Display text of one syllable: a conjunct onset (virāma between consonants), the vowel as a mātrā after a consonant
    (inherent अ: none) or as an independent letter, then anusvāra/visarga, then a pāda-final coda with its virāma."""
    body = VIRAMA.join(onset)
    v = (SIGN_OF.get(vowel, '') if vowel != 'अ' else '') if onset else vowel
    return body + v + marks + ''.join(c + VIRAMA for c in coda)

def split_padas(verse):
    """Lines: the text between line breaks or daṇḍas, verse numbers dropped. analyse() splits half-verses."""
    import re
    parts = [p.strip() for p in re.split(r'[।॥\n]+', verse) if p.strip()]
    parts = [re.sub(r'[\d०-९]+', '', p).strip() for p in parts]
    return [p for p in parts if p]

def uddishta(pattern):
    """Piṅgala's uddiṣṭa: 1 + Σ 2^i over the laghu positions (first syllable = bit 0)."""
    return 1 + sum(1 << i for i, w in enumerate(pattern) if w == 'L')

def nashta(index, length):
    """The inverse of uddiṣṭa: the pattern with this index among all patterns of `length` syllables."""
    if not 1 <= index <= 1 << length: raise ValueError('index out of range')
    k = index - 1
    return ''.join('L' if (k >> i) & 1 else 'G' for i in range(length))

def ganas(pattern):
    full = len(pattern) // 3 * 3
    return [GANA[pattern[i:i + 3]] for i in range(0, full, 3)] + ['ग' if w == 'G' else 'ल' for w in pattern[full:]]

# ---- metres (classical definitions; the gaṇa formulas as l6b_meters.py, from the standard treatises) ----
SAMA = {'इन्द्रवज्रा': 'त त ज ग ग', 'उपेन्द्रवज्रा': 'ज त ज ग ग', 'रथोद्धता': 'र न र ल ग', 'स्वागता': 'र न भ ग ग',
        'शालिनी': 'म त त ग ग', 'वंशस्थ': 'ज त ज र', 'इन्द्रवंशा': 'त त ज र', 'द्रुतविलम्बित': 'न भ भ र',
        'वसन्ततिलका': 'त भ ज ज ग ग', 'मालिनी': 'न न म य य', 'मन्दाक्रान्ता': 'म भ न त त ग ग', 'शिखरिणी': 'य म न स भ ल ग',
        'पृथ्वी': 'ज स ज स य ल ग', 'हरिणी': 'न स म र स ल ग', 'शार्दूलविक्रीडित': 'म स ज स त त ग', 'स्रग्धरा': 'म र भ न य य य'}
def sama_pattern(formula):
    return ''.join(GANA_NAME.get(g, 'G' if g == 'ग' else 'L') for g in formula.split())
SAMA_PAT = {name: sama_pattern(f) for name, f in SAMA.items()}

def match(pattern, want):
    """True if the pattern fits `want` with the final syllable anceps."""
    return len(pattern) == len(want) and pattern[:-1] == want[:-1]

ANUSTUBH_ODD = {'LGG': 'पथ्या', 'LLL': 'न-विपुला', 'GLL': 'भ-विपुला', 'GGG': 'म-विपुला', 'GLG': 'र-विपुला'}

def anustubh(pats):
    """Śloka (anuṣṭubh): 4 pādas of 8; even pādas have syllables 5–7 = L G L (ja); odd pādas 5–7 = L G G (pathyā) or a
    vipulā (na, bha, ma, ra). Returns per-pāda labels, or None if it is not a śloka. The vipulās' further conditions
    (the caesura, the preceding syllables) are not enforced, and the result says so."""
    if len(pats) != 4 or any(len(p) != 8 for p in pats): return None
    out = []
    for i, p in enumerate(pats):
        five = p[4:7]
        if i % 2: out.append('पथ्या (सम)' if five == 'LGL' else None)
        else: out.append(ANUSTUBH_ODD.get(five))
    return out if all(out) else None

def arya(pats):
    """Āryā (mātrā): the pādas count 12, 18, 12, 15 mātrās (the last syllable of a pāda anceps, so ±1 is admitted)."""
    if len(pats) != 4: return None
    m = [sum(2 if w == 'G' else 1 for w in p) for p in pats]
    want = (12, 18, 12, 15)
    return m if all(abs(a - b) <= 1 for a, b in zip(m, want)) else None

MAX_DEVIATIONS = 1   # syllables per verse that may differ from the metre (an editorial variant or licence), each reported

def _deviations(pats, want):
    """(pāda, position) where a pāda differs from `want` (the final syllable anceps), or None if a length differs."""
    if any(len(p) != len(want) for p in pats): return None
    return [(i + 1, j + 1) for i, p in enumerate(pats) for j in range(len(want) - 1) if p[j] != want[j]]

def identify(pats):
    """-> {'metre', 'kind', 'per_pada', 'note', 'deviations', 'strict', 'tolerant'}: exact first; then a samavṛtta or śloka with at most
    MAX_DEVIATIONS differing syllables in the whole verse, each named (pāda, syllable)."""
    r = _identify(pats)
    r['strict'] = r['metre'] if not r['deviations'] else None   # d8 ruling: STRICT (0 deviations) is the primary bar metric
    r['tolerant'] = r['metre']                                   # TOLERANT (≤ 1 listed deviation) is secondary
    return r

def _identify(pats):
    exact = _identify_exact(pats)
    if exact['metre'] or len(pats) != 4: return {**exact, 'deviations': []}
    best = None
    for name, want in SAMA_PAT.items():
        d = _deviations(pats, want)
        if d is not None and len(d) <= MAX_DEVIATIONS and (best is None or len(d) < len(best[1])): best = (name, d)
    if best:
        (pi, si), = best[1]
        return {'metre': best[0], 'kind': 'samavṛtta', 'per_pada': [best[0]] * 4, 'deviations': best[1],
                'note': f'fits {SAMA[best[0]]} except pāda {pi}, syllable {si} (an editorial variant or licence; reported, not hidden)'}
    if all(len(p) == 8 for p in pats):
        for k in range(4):   # one syllable of one pāda flipped into the śloka's checked positions
            for j in (4, 5, 6):
                q = list(pats); q[k] = q[k][:j] + ('L' if q[k][j] == 'G' else 'G') + q[k][j + 1:]
                a = anustubh(q)
                if a: return {'metre': 'अनुष्टुभ् (श्लोक)', 'kind': 'anuṣṭubh', 'per_pada': a, 'deviations': [(k + 1, j + 1)],
                              'note': f'a śloka except pāda {k + 1}, syllable {j + 1} (an editorial variant or licence; reported, not hidden)'}
    return {**exact, 'deviations': []}

def _identify_exact(pats):
    names = []
    for p in pats:
        hit = [n for n, w in SAMA_PAT.items() if match(p, w)]
        names.append(hit[0] if hit else None)
    if len(pats) == 4 and all(names) and len(set(names)) == 1:
        return {'metre': names[0], 'kind': 'samavṛtta', 'per_pada': names, 'note': f'all four pādas fit {SAMA[names[0]]} (the last syllable anceps)'}
    if len(pats) == 4 and all(names) and set(names) <= {'इन्द्रवज्रा', 'उपेन्द्रवज्रा'}:
        return {'metre': 'उपजाति', 'kind': 'upajāti', 'per_pada': names, 'note': 'indravajrā and upendravajrā pādas mixed'}
    a = anustubh(pats)
    if a: return {'metre': 'अनुष्टुभ् (श्लोक)', 'kind': 'anuṣṭubh', 'per_pada': a,
                  'note': 'syllables 5–7 checked per pāda; the vipulās\' caesura conditions are not checked'}
    m = arya(pats)
    if m: return {'metre': 'आर्या', 'kind': 'mātrā', 'per_pada': [f'{x} मात्राः' for x in m], 'note': 'mātrā counts 12/18/12/15, each ±1 for the anceps final'}
    return {'metre': None, 'kind': None, 'per_pada': names, 'note': 'no listed metre fits; the pattern and the prastāra index are still exact'}

def _cut(sy, k):
    """Split a half-verse's syllables after k; the last syllable of each part is the pāda end (anceps)."""
    a, b = [dict(x) for x in sy[:k]], [dict(x) for x in sy[k:]]
    for part in (a, b):
        for x in part: x['anceps'] = False
        if part: part[-1]['anceps'] = True
    return a, b

def _matra_cut(sy, want):
    acc = 0
    for k, x in enumerate(sy):
        acc += 2 if x['weight'] == 'G' else 1
        if acc >= want: return k + 1
    return len(sy) // 2

def analyse(verse, cite='', reweigh=None):
    """-> the L2 analytic object: pādas with syllables and weights, gaṇas, mātrā, uddiṣṭa index, metre, explanation.
    A verse written as two lines is two half-verses: each is split into two pādas BY SYLLABLES (the pāda boundary often
    falls inside a sandhi compound, so not at a space): at the syllable midpoint, or for āryā after 12 mātrās; the
    split that identifies a metre is kept (midpoint first). `reweigh(syllables) -> weights` replaces the weight function
    (benchmark arms only)."""
    lines = split_padas(verse)
    line_sy = [syllables(l) for l in lines]
    if reweigh is not None:   # benchmark arms (BENCHMARK-FREEZE L2): replace ONLY the weight function, everything else unchanged
        for sy in line_sy:
            for x, w in zip(sy, reweigh(sy)): x['weight'] = w; x['why'] = 'arm'
    configs = [[[x for x in sy] for sy in line_sy]]
    if len(lines) == 2:
        configs = [[q for sy in line_sy for q in _cut(sy, len(sy) // 2)],
                   [q for sy in line_sy for q in _cut(sy, _matra_cut(sy, 12))]]
    chosen = None
    for cfg in configs:
        met = identify([''.join(x['weight'] for x in sy) for sy in cfg])
        if met['metre']: chosen = (cfg, met); break
    if chosen is None: chosen = (configs[0], identify([''.join(x['weight'] for x in sy) for sy in configs[0]]))
    cfg, met = chosen
    padas = []
    for i, sy in enumerate(cfg):
        pat = ''.join(x['weight'] for x in sy)
        padas.append({'n': i + 1, 'text': ''.join(x['aksara'] for x in sy), 'syllables': sy, 'pattern': pat, 'ganas': ganas(pat),
                      'matra': sum(2 if w == 'G' else 1 for w in pat), 'uddishta': uddishta(pat), 'length': len(pat)})
    expl = [f"{cite + ' ' if cite else ''}pāda {p['n']}: {p['length']} syllables, {p['pattern']} "
            f"({' '.join(p['ganas'])}), {p['matra']} mātrās, prastāra index {p['uddishta']} of {1 << p['length']}"
            for p in padas]
    expl.append('Weights by Piṅgala (Chandaḥśāstra, DESIGN A1: 1.4.10–12): dīrgha, anusvāra/visarga, or a following saṃyoga '
                'makes a syllable guru; the pāda-final syllable is anceps.')
    expl.append(f"Metre: {met['metre'] or 'not identified'}. {met['note']}.")
    return {'padas': padas, 'metre': met, 'explanation': expl}

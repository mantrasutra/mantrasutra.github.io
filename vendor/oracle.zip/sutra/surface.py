# SPDX-License-Identifier: AGPL-3.0-only
"""Terms <-> sūtra text (GRAMMAR-proposal §1, review step0 fixes A–E).

सङ्ग्रहः (print) and व्याख्या (parse) for canonical terms. Pada style: words separated by one space, no external
sandhi (fix E). Prefix with head words; each head and name carries the case of its role (fix A: by gender);
numerals are indeclinable (fix C): digits, `p⁄q` for a rational, a leading NEG word for a negative.
Roles: sum/prod operands nom; pow base gen, exponent ins; application arguments loc; deriv term nom, variable abl;
binder: bound name acc, lower bound abl, upper bound acc, body nom; lim: bound name acc, point acc, body nom;
piece: per branch REL head nom, its two sides nom, value nom; then OTHERWISE and the value nom.
round (DESIGN-loops §1.2): ROUND head [ROUND_DOWN in the head's case, for mode down], x gen, unit ins.
iter: ITER head, count k ≥ 1, the counter's bound name acc, then per state component its bound name acc, its init abl
  (outer scope) and its step nom (k+1 bound names deeper); UNTIL (loc), the stop relation (REL head nom, two sides nom),
  out nom, BUDGET and the budget numeral (1..ITER_MAX).
let: LET head, the bound name acc, the value nom, the body nom (one bound name deeper).
`env` maps a declared stem to (kind, arity); every declared name is a masculine a-stem in v1."""
import pathlib
from fractions import Fraction
from .endings import form, analyse
from .terms import ITER_MAX, NBOUND

DIG = '०१२३४५६७८९'
MAX_NUMERAL = 4000   # digits; a longer numeral is refused (Python's int/str limit is 4300)
def _words():
    rows = {}
    for line in (pathlib.Path(__file__).parent / 'words.tsv').read_text(encoding='utf8').splitlines():
        if not line or line.startswith('#'): continue
        role, stem, gender, status = line.split('\t')
        rows[role] = (stem, gender, status)
    return rows
W = _words()
HEADS = {r: W[r] for r in ('SUM', 'PROD', 'POW', 'DERIV', 'INT', 'LIM', 'SERIES', 'PRODUCT_SERIES', 'PIECE',
                          'REL_LT', 'REL_LE', 'REL_EQ', 'REL_NE', 'ROUND', 'ITER', 'LET')}
BINDER_ROLE = {'Σ': 'SERIES', 'Π': 'PRODUCT_SERIES', '∫': 'INT'}
REL_ROLE = {'lt': 'REL_LT', 'le': 'REL_LE', 'eq': 'REL_EQ', 'ne': 'REL_NE'}
BOUND = [W[f'BOUND{i}'][0] for i in range(NBOUND)]
INF = W['INF'][0]   # ∞: a neuter a-stem constant, always in force
ARITY = {'EXP': 1, 'LOG': 1, 'SIN': 1, 'COS': 1, 'TAN': 1, 'ASIN': 1, 'ACOS': 1, 'ATAN': 1, 'SINH': 1, 'COSH': 1, 'TANH': 1,
         'RE': 1, 'IM': 1, 'CONJ': 1, 'ABS': 1, 'ARG': 1, 'GAMMA': 1, 'ZETA': 1, 'HURWITZ_ZETA': 2, 'DIRICHLET_ETA': 1,
         'POLYLOG': 2, 'LAMBERT_W0': 1, 'LAMBERT_WM1': 1, 'BESSEL_J': 2, 'BESSEL_Y': 2, 'BESSEL_I': 2, 'BESSEL_K': 2,
         'VON_MANGOLDT': 1, 'DIRICHLET_LAMBDA': 1, 'CARMICHAEL_LAMBDA': 1, 'HARDY_Z': 1}
BUILTIN = {**{W[k][0]: ('fn', a) for k, a in ARITY.items()}, **{W[k][0]: ('const', 0) for k in ('PI', 'E_CONST', 'IMAG_UNIT')},
           INF: ('const', 0)}   # always in force; never declared

class SutraRefusal(Exception):
    def __init__(self, code, name, why): super().__init__(f'{hex(code)} {name}: {why}'); self.code, self.name = code, name

def gender(stem, env):
    if stem == INF: return 'n'
    e = env.get(stem)
    return e[2] if e is not None and len(e) > 2 else 'm'

def deva(n): return ''.join(DIG[int(d)] for d in str(n))
def _head(role, case): s, g, _ = HEADS[role]; return form(s, g, case)

# ---- सङ्ग्रहः ----
def emit(t, env, case='nom', depth=0):
    out = []
    def go(t, case, d):
        k = t[0]
        if k == 'num':
            q = t[1]
            if q < 0: out.append(W['NEG'][0])
            out.append(deva(abs(q.numerator)) + ('' if q.denominator == 1 else '⁄' + deva(q.denominator)))
        elif k == 'name': out.append(form(t[1], gender(t[1], env), case))
        elif k == 'bvar': out.append(form(BOUND[d - 1 - t[1]], 'm', case))
        elif k in ('sum', 'prod'):
            out.extend([_head('SUM' if k == 'sum' else 'PROD', case), deva(len(t[1]))])
            for c in t[1]: go(c, 'nom', d)
        elif k == 'pow': out.append(_head('POW', case)); go(t[1], 'gen', d); go(t[2], 'ins', d)
        elif k == 'app':
            out.append(form(t[1], gender(t[1], env), case))
            for c in t[2]: go(c, 'loc', d)
        elif k == 'deriv': out.append(_head('DERIV', case)); go(t[1], 'nom', d); go(t[2], 'abl', d)
        elif k == 'bind':
            _room(d + 1); out.append(_head(BINDER_ROLE[t[1]], case))
            if t[5]: out.append(t[5])
            out.append(form(BOUND[d], 'm', 'acc')); go(t[2], 'abl', d); go(t[3], 'acc', d); go(t[4], 'nom', d + 1)
        elif k == 'lim':
            _room(d + 1); out.append(_head('LIM', case))
            if t[2] != 'both': out.append(W['SIDE_LEFT' if t[2] == 'left' else 'SIDE_RIGHT'][0])
            out.append(form(BOUND[d], 'm', 'acc')); go(t[1], 'acc', d); go(t[3], 'nom', d + 1)
        elif k == 'piece':
            out.extend([_head('PIECE', case), deva(len(t[1]))])
            for c, v in t[1]: out.append(_head(REL_ROLE[c[1]], 'nom')); go(c[2], 'nom', d); go(c[3], 'nom', d); go(v, 'nom', d)
            out.append(W['OTHERWISE'][0]); go(t[2], 'nom', d)
        elif k == 'round':
            out.append(_head('ROUND', case))
            if t[3] == 'down': out.append(form(W['ROUND_DOWN'][0], W['ROUND_DOWN'][1], case))
            go(t[1], 'gen', d); go(t[2], 'ins', d)
        elif k == 'iter':
            n = len(t[1]); _room(d + n + 1)
            out.extend([_head('ITER', case), deva(n), form(BOUND[d], 'm', 'acc')])
            for j in range(n):
                out.append(form(BOUND[d + 1 + j], 'm', 'acc')); go(t[1][j], 'abl', d); go(t[2][j], 'nom', d + n + 1)
            s, g, _ = W['UNTIL']; out.extend([form(s, g, 'loc'), _head(REL_ROLE[t[3][1]], 'nom')])
            go(t[3][2], 'nom', d + n + 1); go(t[3][3], 'nom', d + n + 1); go(t[4], 'nom', d + n + 1)
            out.extend([W['BUDGET'][0], deva(t[5])])
        elif k == 'let':
            _room(d + 1)
            out.extend([_head('LET', case), form(BOUND[d], 'm', 'acc')]); go(t[1], 'nom', d); go(t[2], 'nom', d + 1)
        else: raise SutraRefusal(0x3A4, 'NonCanonical', f'node {k} is not canonical')
    go(t, case, depth)
    return ' '.join(out)

def _room(need):
    if need > len(BOUND): raise SutraRefusal(0x3A1, 'MalformedSutra', f'more than {len(BOUND)} bound names in scope')

# ---- व्याख्या ----
METHODS = set()   # summation-method words, to be ruled (DESIGN §0); none yet

def parse(text, env, case='nom'):
    toks = text.split(' ')
    if any(not w for w in toks): raise SutraRefusal(0x3A1, 'MalformedSutra', 'words are separated by exactly one space')
    pos = [0]
    def peek(): return toks[pos[0]] if pos[0] < len(toks) else None
    def take():
        w = peek()
        if w is None: raise SutraRefusal(0x3A1, 'MalformedSutra', 'the sūtra ends inside a term')
        pos[0] += 1; return w
    def numeral(w):
        if w and all(c in DIG or c == '⁄' for c in w) and w.count('⁄') <= 1 and not w.startswith('⁄') and not w.endswith('⁄'):
            p, _, q = w.partition('⁄')
            if len(p) > MAX_NUMERAL or len(q) > MAX_NUMERAL: raise SutraRefusal(0x3B0, 'NumeralTooLong', f'a numeral over {MAX_NUMERAL} digits')
            v = lambda s: int(''.join(str(DIG.index(c)) for c in s))
            if (len(p) > 1 and p[0] == '०') or (q and (q[0] == '०' or v(q) <= 1)): raise SutraRefusal(0x3A4, 'NonCanonical', f'numeral {w}')
            return Fraction(v(p), v(q) if q else 1)
        if w and any(c.isdigit() for c in w): raise SutraRefusal(0x3A5, 'MixedDigits', w)
        return None
    def count(least=2):
        n = numeral(take())
        if n is None or n.denominator != 1 or n < least: raise SutraRefusal(0x3A1, 'MalformedSutra', f'a count ≥ {least} must follow the head')
        return int(n)
    def word(w, want):
        """-> ('head', role) | ('name', stem) | ('bound', i), checking the case."""
        for role, (s, g, _) in HEADS.items():
            if form(s, g, want) == w: return ('head', role)
        if form(INF, 'n', want) == w: return ('name', INF)
        seen = None
        for g in ('m', 'n'):
            a = analyse(w, g)
            if not a or not (a[1] == want or (g == 'n' and {a[1], want} == {'nom', 'acc'})): continue
            seen = seen or a[0]
            if g == 'm' and a[0] in BOUND: return ('bound', BOUND.index(a[0]))
            if (a[0] in env or a[0] in BUILTIN) and gender(a[0], env) == g: return ('name', a[0])
        if seen: raise SutraRefusal(0x3A2, 'UndeclaredName', seen)
        raise SutraRefusal(0x3A0, 'UnknownWord', f'{w} (wanted the {want} case)')
    def go(case, d):
        w = take()
        if w == W['NEG'][0]:
            q = numeral(take())
            if q is None or q == 0: raise SutraRefusal(0x3A1, 'MalformedSutra', 'NEG must be followed by a numeral other than 0')
            return ('num', -q)
        q = numeral(w)
        if q is not None: return ('num', q)
        kind, x = word(w, case)
        if kind == 'bound':
            if x >= d: raise SutraRefusal(0x3A2, 'UndeclaredName', 'a bound name outside its binder')
            return ('bvar', d - 1 - x)
        if kind == 'name':
            k, arity = (BUILTIN[x] if x in BUILTIN else env[x])[:2]
            if k == 'fn': return ('app', x, tuple(go('loc', d) for _ in range(arity)))
            return ('name', x, k)
        if x in ('SUM', 'PROD'):
            n = count(); return ('sum' if x == 'SUM' else 'prod', tuple(go('nom', d) for _ in range(n)))
        if x == 'POW': b = go('gen', d); return ('pow', b, go('ins', d))
        if x == 'DERIV': t = go('nom', d); return ('deriv', t, go('abl', d))
        if x in ('SERIES', 'PRODUCT_SERIES', 'INT'):
            op = {'SERIES': 'Σ', 'PRODUCT_SERIES': 'Π', 'INT': '∫'}[x]
            _room(d + 1); m = take() if peek() in METHODS else None
            if word(take(), 'acc') != ('bound', d): raise SutraRefusal(0x3A1, 'MalformedSutra', f'the binder must bind {BOUND[d]}')
            lo = go('abl', d); hi = go('acc', d)
            return ('bind', op, lo, hi, go('nom', d + 1), m)
        if x == 'LIM':
            _room(d + 1); side = 'both'
            if peek() == W['SIDE_LEFT'][0]: take(); side = 'left'
            elif peek() == W['SIDE_RIGHT'][0]: take(); side = 'right'
            if word(take(), 'acc') != ('bound', d): raise SutraRefusal(0x3A1, 'MalformedSutra', f'lim must bind {BOUND[d]}')
            pt = go('acc', d); return ('lim', pt, side, go('nom', d + 1))
        if x == 'PIECE':
            n = count(1); br = []
            for _ in range(n):
                kind2, r = word(take(), 'nom')
                rel = {v: k for k, v in REL_ROLE.items()}.get(r) if kind2 == 'head' else None
                if rel is None: raise SutraRefusal(0x3A1, 'MalformedSutra', 'a piecewise branch starts with a relation')
                a = go('nom', d); b = go('nom', d); br.append((('rel', rel, a, b), go('nom', d)))
            if take() != W['OTHERWISE'][0]: raise SutraRefusal(0x3A1, 'MalformedSutra', 'piecewise needs its OTHERWISE value')
            return ('piece', tuple(br), go('nom', d))
        if x == 'ROUND':
            dn = W['ROUND_DOWN']
            mode = 'near'
            if peek() == form(dn[0], dn[1], case):
                take(); mode = 'down'
            xx = go('gen', d); return ('round', xx, go('ins', d), mode)
        if x == 'ITER':
            n = count(1); _room(d + n + 1)
            if word(take(), 'acc') != ('bound', d): raise SutraRefusal(0x3A1, 'MalformedSutra', f'the counter must be {BOUND[d]}')
            inits, steps = [], []
            for j in range(n):
                if word(take(), 'acc') != ('bound', d + 1 + j): raise SutraRefusal(0x3A1, 'MalformedSutra', f'state {j + 1} must be {BOUND[d + 1 + j]}')
                inits.append(go('abl', d)); steps.append(go('nom', d + n + 1))
            s_, g_, _ = W['UNTIL']
            if take() != form(s_, g_, 'loc'): raise SutraRefusal(0x3A1, 'MalformedSutra', 'an iter states its stop after UNTIL')
            kind2, r = word(take(), 'nom')
            rel = {v: k for k, v in REL_ROLE.items()}.get(r) if kind2 == 'head' else None
            if rel is None: raise SutraRefusal(0x3A1, 'MalformedSutra', 'the stop is a relation')
            a = go('nom', d + n + 1); b = go('nom', d + n + 1); o = go('nom', d + n + 1)
            if take() != W['BUDGET'][0]: raise SutraRefusal(0x3A1, 'MalformedSutra', 'an iter ends with its BUDGET')
            bq = numeral(take())
            if bq is None or bq.denominator != 1 or not 1 <= bq <= ITER_MAX: raise SutraRefusal(0x3A1, 'MalformedSutra', f'a budget is an integer 1..{ITER_MAX}')
            return ('iter', tuple(inits), tuple(steps), ('rel', rel, a, b), o, int(bq))
        if x == 'LET':
            _room(d + 1)
            if word(take(), 'acc') != ('bound', d): raise SutraRefusal(0x3A1, 'MalformedSutra', f'let must bind {BOUND[d]}')
            v_ = go('nom', d); return ('let', v_, go('nom', d + 1))
        raise SutraRefusal(0x3A1, 'MalformedSutra', f'{w} cannot start a term here')
    t = go(case, 0)
    if pos[0] != len(toks): raise SutraRefusal(0x3A1, 'MalformedSutra', f'words left over after the term: {" ".join(toks[pos[0]:])}')
    return t

# SPDX-License-Identifier: AGPL-3.0-only
"""L6 structure (DESIGN v2 A1), exactly as registered in docs/L6-registration.md (ca91f11, before the run).
Akṣara sequences from L2's syllabification; citrakāvya equivalences (ṃ/ḥ ignored, b = v, ḍ = l, r = l)."""
import re
from .prosody import segments, CONS, SIGNS, VIRAMA

EQUIV = {'ब': 'व', 'ड': 'ल', 'र': 'ल'}
MATRA_OF = {v: m for m, v in SIGNS.items()}

def aksaras(line):
    """Devanagari line -> akṣaras after the equivalences, each as (onset consonants tuple, vowel); ṃ/ḥ dropped,
    a final consonant with no vowel joins the last akṣara's onset tail (it has no vowel of its own)."""
    seg = segments(line); out, onset = [], []
    for s in seg:
        if s[0] == 'C': onset.append(EQUIV.get(s[1], s[1]))
        elif s[0] == 'V': out.append((tuple(onset), s[1])); onset = []
    if onset and out: out[-1] = (out[-1][0] + ('|',) + tuple(onset), out[-1][1])
    return out

def split_verse(text):
    """-> lines (half-verses or pādas as written), each a list of akṣaras; and pādas (each line halved if it is a
    half-verse of ≥ 16 akṣaras with an even count)."""
    lines = [l.strip() for l in re.split(r'[।॥\n]+', re.sub(r'[\d०-९]+', '', text)) if l.strip()]
    L = [aksaras(l) for l in lines]
    padas = []
    for a in L:
        if len(a) >= 16 and len(a) % 2 == 0: padas += [a[:len(a) // 2], a[len(a) // 2:]]
        else: padas.append(a)
    return L, padas

def palindrome(a): return len(a) >= 8 and a == a[::-1]

def anuloma_viloma(L, padas):
    for i, p in enumerate(padas):
        if palindrome(p): return f'pāda {i + 1} reads the same backward'
    for i, l in enumerate(L):
        if palindrome(l): return f'line {i + 1} reads the same backward'
    for i, p in enumerate(padas):
        for j, q in enumerate(padas):
            if i < j and len(p) >= 8 and p == q[::-1]: return f'pāda {j + 1} is pāda {i + 1} reversed (gatapratyāgata)'
    return None

def sarvatobhadra(L, padas):
    if len(padas) != 4 or len({len(p) for p in padas}) != 1 or len(padas[0]) < 8: return None
    if not all(palindrome(p) for p in padas): return None
    if all(padas[i][j] == padas[j][i] for i in range(4) for j in range(4)): return 'four palindromic pādas, symmetric 4×4 block'
    return None

def yamaka(L, padas, k=4):
    seq, starts, ends = [], set(), set()
    for p in padas:
        starts.add(len(seq)); seq += p; ends.add(len(seq))
    n = len(seq)
    for i in range(n - k + 1):
        w = seq[i:i + k]
        for j in range(i + k, n - k + 1):
            if seq[j:j + k] == w and (i in starts or j in starts or i + k in ends or j + k in ends):
                return f'akṣaras {i + 1}–{i + k} recur at {j + 1}–{j + k}, at a pāda boundary'
    return None

def anuprasa(L, padas):
    for i, p in enumerate(padas):
        onsets = [a[0][-1] for a in p if a[0] and a[0][-1] != '|']
        if not p: continue
        from collections import Counter
        if onsets:
            c, n = Counter(onsets).most_common(1)[0]
            if n >= 4 and n * 2 >= len(p): return f'pāda {i + 1}: {c} begins {n} of {len(p)} akṣaras'
    return None

def refrain(verses_padas, k=6):
    seen = {}
    for vi, padas in enumerate(verses_padas):
        for p in padas:
            if len(p) < k: continue
            t = tuple(p)
            if t in seen and seen[t] != vi: return f'a pāda of verse {seen[t] + 1} recurs in verse {vi + 1}'
            seen.setdefault(t, vi)
    return None

# ---- amendment 17: classical definitions (registered before the L6 v2 run) ----
def ardhabhramaka(L, padas):
    """the leading 4×4 akṣara block of the 4 pādas is symmetric (grid[i][j] = grid[j][i])"""
    if len(padas) != 4 or min(len(p) for p in padas) < 4: return None
    if all(padas[i][j] == padas[j][i] for i in range(4) for j in range(4)): return 'the leading 4×4 block of the 4 pādas is symmetric'
    return None

def gomutrika(L, padas):
    """the two half-verses agree at every alternate akṣara (all even, or all odd, positions)"""
    halves = L if len(L) == 2 else ([padas[0] + padas[1], padas[2] + padas[3]] if len(padas) == 4 else None)
    if not halves or len(halves[0]) != len(halves[1]) or len(halves[0]) < 8: return None
    a, b = halves
    for start in (0, 1):
        if all(a[i] == b[i] for i in range(start, len(a), 2)): return f'the half-verses agree at every alternate akṣara (from {start + 1})'
    return None

def _consonants(L, ignore_one_final):
    """distinct consonants (after the equivalences); a word-final consonant (after '|') may be ignored once"""
    inv, finals = set(), []
    for line in L:
        for onset, _ in line:
            if '|' in onset:
                i = onset.index('|'); inv |= set(onset[:i]); finals += list(onset[i + 1:])
            else: inv |= set(onset)
    if ignore_one_final and len(finals) == 1 and finals[0] not in inv: finals = []
    return inv | set(finals)

def ekavyanjana(L, padas):
    inv = _consonants(L, True)
    return f'one consonant: {"".join(sorted(inv))}' if len(inv) == 1 else None

def dvyaksara(L, padas):
    inv = _consonants(L, False)
    return f'two consonants: {"".join(sorted(inv))}' if len(inv) == 2 else None

DETECTORS = {'anuloma-viloma': anuloma_viloma, 'sarvatobhadra': sarvatobhadra, 'yamaka': yamaka, 'anuprāsa': anuprasa,
             'ardhabhramaka': ardhabhramaka, 'gomūtrikā': gomutrika, 'ekavyañjana': ekavyanjana, 'dvyakṣara': dvyaksara}

# reviewer ruling (amendment 19 + correction): VERIFIED only where every SCORED held-out item was found (v1 + v2), with
# 0 structural false positives; a detector seen firing only post hoc earns no credit. The scored record is shown with it.
RECORD = {   # figure: (found in scored runs, scored n)
    'anuloma-viloma': (8, 8), 'ardhabhramaka': (1, 1), 'gomūtrikā': (1, 1), 'ekavyañjana': (1, 1),
    'sarvatobhadra': (0, 2), 'dvyakṣara': (0, 1), 'yamaka': (8, 9), 'refrain': (0, 6), 'anuprāsa': (3, 4)}
VERIFIED = ('anuloma-viloma', 'ardhabhramaka', 'gomūtrikā', 'ekavyañjana')
EXPERIMENTAL = ('sarvatobhadra', 'dvyakṣara', 'yamaka', 'refrain', 'anuprāsa')   # anuprāsa also never FP-scored

def analyse(text, verses=None):
    """text: one verse (Devanagari). verses: optional list of verse texts for the refrain detector."""
    L, padas = split_verse(text)
    out = {name: f(L, padas) for name, f in DETECTORS.items()}
    if verses: out['refrain'] = refrain([split_verse(v)[1] for v in verses])
    return out

# SPDX-License-Identifier: AGPL-3.0-only
"""Statements and documents (DESIGN §1; review step1 Q1).

A document is a tuple of sections; a section = (decls, stmts).
  decl = (stem, kind, arity, dim, gender)    gender m|n; kind in const/var/fn/rate; arity for fn; dim = 7 Fractions or None
  stmt = ('def', stem, term) | ('law', lhs, rhs) | ('rate', stem, term)     (rate: d stem / dt = term)
Text: SECTION decl … ।  then each statement ending in ।  (pada style, one space between words, one line per sūtra).
  decl  = NAME-nom (gender from the ending: -ः masculine, -म् neuter) KIND-tag [arity] [DIM p₁ … p₇]
  def   = DEF NAME-nom = TERM ।     law = LAW TERM = TERM ।     rate = RATE NAME-nom = TERM ।
Anuvṛtti (FULL): a section declares each name once, at the section head, and its statements use them; a new section
starts empty (no inheritance across sections in v1). FLAT: every statement is its own section declaring all it uses."""
from fractions import Fraction
from .endings import form
from .surface import W, emit, parse, deva, SutraRefusal, BUILTIN, gender
from .terms import children

KIND_WORD = {'const': W['KIND_CONST'][0], 'var': W['KIND_VAR'][0], 'fn': W['KIND_FN'][0], 'rate': W['KIND_RATE'][0]}
WORD_KIND = {v: k for k, v in KIND_WORD.items()}
END, EQ = W['END'][0], W['EQUALS'][0]

def _num_word(q):
    q = Fraction(q)
    s = deva(abs(q.numerator)) + ('' if q.denominator == 1 else '⁄' + deva(q.denominator))
    return (W['NEG'][0] + ' ' + s) if q < 0 else s

def emit_decl(d):
    stem, kind, arity, dim, g = d
    out = [form(stem, g, 'nom'), KIND_WORD[kind]]
    if kind == 'fn': out.append(deva(arity))
    if dim is not None: out += [W['DIM'][0]] + [_num_word(x) for x in dim]
    return ' '.join(out)

def emit_stmt(st, env):
    k = st[0]
    if k == 'def': return f"{W['DEF'][0]} {form(st[1], gender(st[1], env), 'nom')} {EQ} {emit(st[2], env)} {END}"
    if k == 'law': return f"{W['LAW'][0]} {emit(st[1], env)} {EQ} {emit(st[2], env)} {END}"
    if k == 'rate': return f"{W['RATE'][0]} {form(st[1], gender(st[1], env), 'nom')} {EQ} {emit(st[2], env)} {END}"
    raise ValueError(k)

def emit_doc(doc):
    lines = []
    for decls, stmts in doc:
        env = {d[0]: (d[1], d[2], d[4]) for d in decls}
        lines.append(' '.join([W['SECTION'][0]] + [emit_decl(d) for d in decls] + [END]))
        lines += [emit_stmt(s, env) for s in stmts]
    return '\n'.join(lines) + '\n'

def names_used(t, out):
    if t[0] == 'name' and t[1] not in BUILTIN: out.setdefault(t[1], None)
    if t[0] == 'app' and t[1] not in BUILTIN: out.setdefault(t[1], None)
    if t[0] == 'deriv': names_used(t[2], out)
    for c in children(t): names_used(c, out)
    return out

def flat(doc):
    """FLAT: one section per statement, declaring exactly the names that statement uses, in order of first use."""
    out = []
    for decls, stmts in doc:
        by = {d[0]: d for d in decls}
        for s in stmts:
            used = {}
            if s[0] in ('def', 'rate'): used[s[1]] = None
            for t in s[2:] if s[0] != 'law' else s[1:]: names_used(t, used)
            out.append((tuple(by[n] for n in used), (s,)))
    return tuple(out)

def parse_doc(text):
    if not text.endswith('\n'): raise SutraRefusal(0x3A1, 'MalformedSutra', 'a document ends with a newline')
    doc, cur = [], None
    for ln, line in enumerate(text[:-1].split('\n'), 1):
        w = line.split(' ')
        if w[-1] != END: raise SutraRefusal(0x3A1, 'MalformedSutra', f'line {ln} must end with {END}')
        body = w[:-1]
        if body[0] == W['SECTION'][0]:
            decls, i = [], 1
            while i < len(body):
                from .endings import analyse
                a, g = analyse(body[i], 'm'), 'm'
                if not a or a[1] != 'nom': a, g = analyse(body[i], 'n'), 'n'
                if not a or a[1] != 'nom': raise SutraRefusal(0x3A1, 'MalformedSutra', f'line {ln}: a declaration starts with a name in the nominative')
                if i + 1 >= len(body) or body[i + 1] not in WORD_KIND: raise SutraRefusal(0x3A1, 'MalformedSutra', f'line {ln}: a kind tag must follow {body[i]}')
                stem, kind = a[0], WORD_KIND[body[i + 1]]; i += 2; arity = 0
                if kind == 'fn': arity = parse(body[i], {}).__getitem__(1).numerator; i += 1
                dim = None
                if i < len(body) and body[i] == W['DIM'][0]:
                    i += 1; dim = []
                    for _ in range(7):
                        if body[i] == W['NEG'][0]: q = parse(body[i] + ' ' + body[i + 1], {})[1]; i += 2
                        else: q = parse(body[i], {})[1]; i += 1
                        dim.append(q)
                    dim = tuple(dim)
                if stem in {d[0] for d in decls}: raise SutraRefusal(0x3A1, 'MalformedSutra', f'line {ln}: {stem} declared twice')
                decls.append((stem, kind, arity, dim, g))
            cur = (tuple(decls), []); doc.append(cur); continue
        if cur is None: raise SutraRefusal(0x3A8, 'AnuvrttiNothingInForce', f'line {ln}: a statement before any section')
        env = {d[0]: (d[1], d[2], d[4]) for d in cur[0]}
        if EQ not in body: raise SutraRefusal(0x3A1, 'MalformedSutra', f'line {ln}: no {EQ}')
        k = body.index(EQ); lhs, rhs = body[1:k], ' '.join(body[k + 1:])
        kw = body[0]
        def one_name():
            from .endings import analyse
            a = None
            for g in ('m', 'n'):
                b = analyse(lhs[0], g) if len(lhs) == 1 else None
                if b and b[1] == 'nom' and b[0] in env and gender(b[0], env) == g: a = b
            if not a: raise SutraRefusal(0x3A2, 'UndeclaredName', f'line {ln}: {" ".join(lhs)}')
            return a[0]
        if kw == W['DEF'][0]: cur[1].append(('def', one_name(), parse(rhs, env)))
        elif kw == W['RATE'][0]: cur[1].append(('rate', one_name(), parse(rhs, env)))
        elif kw == W['LAW'][0]: cur[1].append(('law', parse(' '.join(lhs), env), parse(rhs, env)))
        else: raise SutraRefusal(0x3A0, 'UnknownWord', f'line {ln}: {kw} does not start a sūtra')
    return tuple((d, tuple(s)) for d, s in doc)

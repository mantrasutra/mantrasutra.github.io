# SPDX-License-Identifier: AGPL-3.0-only
"""Evaluation of canonical terms with mpmath (DESIGN §0, §10a, §10d; owner: Γ/ζ/η/polylog/W/Bessel and the four
Lambdas first).

value(t, values, digits) -> (v, achieved_digits). HOW "certified" is meant here, stated exactly:
  - the term is evaluated at two working precisions (digits+15 and digits+40 decimal places);
  - achieved_digits = the number of leading decimal digits on which the two agree (relative), capped at digits;
  - infinite Σ/Π, ∫ and lim also pass through mpmath's own error estimates (nsum/quad), at both precisions;
  - if achieved_digits < digits the result is the refusal 0x3AE PrecisionNotReached, never a silent value.
This is agreement-based, NOT interval arithmetic (mpmath has no intervals for these special functions).
Refusals: 0x3AD divergent series with no named method; 0x3AE precision not reached; 0x3AF ambiguous branch
(a negative real base to a non-integer power, or log of a negative real, outside a declared complex domain)."""
import mpmath
from fractions import Fraction
from .surface import W, SutraRefusal, INF as INF_WORD

FN = {W[k][0]: k for k in W if W[k][2] in ('proposed', 'TBD') and k.isupper()}

def _von_mangoldt(n):
    n = int(n)
    if n < 1: raise SutraRefusal(0x3A7, 'Unsupported', 'von Mangoldt Λ(n) needs an integer n ≥ 1')
    for p in range(2, n + 1):
        if n % p == 0:
            while n % p == 0: n //= p
            return mpmath.log(p) if n == 1 else mpmath.mpf(0)
    return mpmath.mpf(0)

def _carmichael(n):
    n = int(n)
    if n < 1: raise SutraRefusal(0x3A7, 'Unsupported', 'Carmichael λ(n) needs an integer n ≥ 1')
    from math import gcd
    def lam_pp(p, k):
        if p == 2 and k >= 3: return 2 ** (k - 2)
        return (p - 1) * p ** (k - 1)
    out, m, p = 1, n, 2
    while p * p <= m:
        if m % p == 0:
            k = 0
            while m % p == 0: m //= p; k += 1
            l = lam_pp(p, k); out = out * l // gcd(out, l)
        p += 1
    if m > 1: l = m - 1; out = out * l // gcd(out, l)
    return mpmath.mpf(out)

def _int_arg(x, what):
    # ±∞ is not an integer: nint(∞) == ∞ passes the equality, then int() raises a bare ValueError (R2 sweep #4958)
    if not mpmath.isfinite(x) or mpmath.im(x) != 0 or mpmath.re(x) != mpmath.nint(mpmath.re(x)): raise SutraRefusal(0x3A7, 'Unsupported', f'{what} needs an integer')
    return int(mpmath.nint(mpmath.re(x)))

def _real_guard(x, what, complex_domain):
    if not complex_domain and mpmath.im(x) == 0 and mpmath.re(x) < 0:
        raise SutraRefusal(0x3AF, 'AmbiguousBranch', f'{what} of a negative real outside a declared complex domain')

def _apply(fid, a, cd):
    m = mpmath
    if fid == 'LOG': _real_guard(a[0], 'log', cd); return m.log(a[0])
    if fid == 'LAMBERT_W0':
        if not cd and m.im(a[0]) == 0 and m.re(a[0]) < -1 / m.e: raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'W₀ below −1/e is complex')
        return m.lambertw(a[0], 0)
    if fid == 'LAMBERT_WM1':
        if not cd and not (-1 / m.e <= m.re(a[0]) < 0 and m.im(a[0]) == 0): raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'W₋₁ is real only on [−1/e, 0)')
        return m.lambertw(a[0], -1)
    if fid == 'VON_MANGOLDT': return _von_mangoldt(_int_arg(a[0], 'Λ(n)'))
    if fid == 'CARMICHAEL_LAMBDA': return _carmichael(_int_arg(a[0], 'λ(n)'))
    if fid == 'DIRICHLET_LAMBDA': return (1 - m.power(2, -a[0])) * m.zeta(a[0])
    table = {'EXP': m.exp, 'SIN': m.sin, 'COS': m.cos, 'TAN': m.tan, 'ASIN': m.asin, 'ACOS': m.acos, 'ATAN': m.atan,
             'SINH': m.sinh, 'COSH': m.cosh, 'TANH': m.tanh, 'RE': m.re, 'IM': m.im, 'CONJ': m.conj, 'ABS': m.fabs,
             'ARG': m.arg, 'GAMMA': m.gamma, 'ZETA': m.zeta, 'HURWITZ_ZETA': m.zeta, 'DIRICHLET_ETA': m.altzeta,
             'POLYLOG': m.polylog, 'HARDY_Z': m.siegelz, 'BESSEL_J': m.besselj, 'BESSEL_Y': m.bessely, 'BESSEL_I': m.besseli, 'BESSEL_K': m.besselk}
    return table[fid](*a)

LIM_PROBES = (4, 6, 8)   # the lim screen samples f at 10^k from the point (10^-k for a finite point)

def _limit(f, pt, side):
    """lim has no certified rule. mpmath.limit extrapolates from samples and returns a finite number whatever f does:
    x → ∞ gives 451 at 45 digits and 601 at 60, sin x → ∞ gives 0, and a two-sided limit was taken from the right only.
    Its value is used only after a stated screen (heuristic, like the Σ divergence screen), on every side asked for
    (both = left AND right, which must agree):
      - the extrapolation at two precisions must agree;
      - f at the probes 10⁴, 10⁶, 10⁸ (pt ± 10⁻⁴, 10⁻⁶, 10⁻⁸ at a finite point) must close on that value monotonically,
        to within 10⁻³ at the last probe.
    Failing either refuses 0x3AE: no value was reached. (R2 sweep #3892: the unscreened value differed per precision,
    so the certified path doubled the precision until the extrapolation exhausted memory.)"""
    m = mpmath; dps = m.mp.dps
    if isinstance(pt, m.mpc):
        if m.im(pt) != 0: raise SutraRefusal(0x3A7, 'Unsupported', 'lim at a complex point')
        pt = m.re(pt)
    def ext(d):   # a nan from the extrapolation is no value reached (0x3AE), not an indeterminate form of the term
        v = m.limit(f, pt, direction=d)
        if m.isnan(v): raise SutraRefusal(0x3AE, 'PrecisionNotReached', 'lim: the extrapolation gives no number')
        return v
    tol = m.mpf(10) ** -max(dps - 15, dps // 2)
    inf = m.isinf(pt)
    dirs = [1 if pt > 0 else -1] if inf else {'both': [1, -1], 'left': [-1], 'right': [1]}[side]
    got = []
    for d in dirs:
        a = ext(d)
        # the probes first: they are cheap, and refuse most non-limits before the second extrapolation
        gap = [abs(_defined(f(d * m.mpf(10) ** k if inf else pt + d * m.mpf(10) ** -k), 'lim') - a) for k in LIM_PROBES]
        if not (m.isfinite(a) and gap[0] >= gap[1] >= gap[2] and gap[2] <= max(1, abs(a)) / 1000):
            raise SutraRefusal(0x3AE, 'PrecisionNotReached', 'lim: f does not close on the extrapolated value (no limit, or an infinite one)')
        with m.workdps(dps + 15): b = ext(d)
        if abs(a - b) > tol * max(1, abs(a), abs(b)):
            raise SutraRefusal(0x3AE, 'PrecisionNotReached', 'lim: the extrapolation does not settle')
        got.append(a)
    if len(got) == 2 and abs(got[0] - got[1]) > tol * max(1, abs(got[0]), abs(got[1])):
        raise SutraRefusal(0x3AE, 'PrecisionNotReached', 'lim: the left and right limits differ')
    return got[0]

CONSTS = {'PI': lambda: mpmath.pi, 'E_CONST': lambda: mpmath.e, 'IMAG_UNIT': lambda: mpmath.mpc(0, 1)}

def _defined(x, where):
    """0x3B5: an indeterminate form (∞ − ∞, 0·∞, ∞/∞, 1^∞, ∞⁰, …) has no value. mpmath carries it as a nan, which
    would compare false in every decision and print as a value; it is refused at the node that makes it."""
    if isinstance(x, (mpmath.mpf, mpmath.mpc)) and mpmath.isnan(x):
        raise SutraRefusal(0x3B5, 'IndeterminateForm', f'{where}: an indeterminate form has no value')
    return x

def _ev(t, vals, cd, stack):
    return _defined(_ev_node(t, vals, cd, stack), t[0])

def _ev_node(t, vals, cd, stack):
    m = mpmath; k = t[0]
    if k == 'num': return m.mpf(t[1].numerator) / t[1].denominator
    if k == 'name':
        if t[1] == INF_WORD: return m.inf
        fid = FN.get(t[1])
        if fid in CONSTS: return CONSTS[fid]()
        if t[1] not in vals: raise SutraRefusal(0x3A2, 'UndeclaredName', f'{t[1]} has no value')
        return vals[t[1]]
    if k == 'bvar': return stack[-1 - t[1]]
    if k == 'sum': return m.fsum(_ev(c, vals, cd, stack) for c in t[1])
    if k == 'prod': return m.fprod(_ev(c, vals, cd, stack) for c in t[1])
    if k == 'pow':
        b, e = _ev(t[1], vals, cd, stack), _ev(t[2], vals, cd, stack)
        if not cd and m.im(b) == 0 and m.re(b) < 0 and m.im(e) == 0 and m.re(e) != m.nint(m.re(e)):
            raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'a negative real base to a non-integer power')
        if b == 0 and m.re(e) < 0: raise SutraRefusal(0x3AB, 'NumericalCheckFailed', '0 to a negative power (a pole)')
        return m.power(b, e)
    if k == 'app':
        fid = FN.get(t[1])
        if fid is None: raise SutraRefusal(0x3A7, 'Unsupported', f'no evaluation rule for {t[1]}')
        return _apply(fid, [_ev(c, vals, cd, stack) for c in t[2]], cd)
    if k == 'deriv':
        v = t[2][1]; x0 = vals[v]
        return m.diff(lambda x: _ev(t[1], {**vals, v: x}, cd, stack), x0)
    if k == 'bind':
        op, lo, hi, body, method = t[1], _ev(t[2], vals, cd, stack), _ev(t[3], vals, cd, stack), t[4], t[5]
        f = lambda x: _ev(body, vals, cd, stack + [x])
        if op == '∫':
            v, err = m.quad(f, [lo, hi], error=True)
            if err > m.mpf(10) ** (-m.mp.dps + 5): raise SutraRefusal(0x3AE, 'PrecisionNotReached', f'quadrature error estimate {m.nstr(err, 3)}')
            return v
        if hi == m.inf:
            if method is not None: raise SutraRefusal(0x3A7, 'Unsupported', f'summation method {method} not implemented yet')
            # divergence screen (heuristic, stated): terms at n = 10³, 10⁴, 10⁵ must shrink toward 0 (Σ) or 1 (Π)
            tgt = 0 if op == 'Σ' else 1
            probe = [abs(f(lo + 10 ** j) - tgt) for j in (3, 4, 5)]
            if not (probe[2] < probe[1] < probe[0]) and probe[2] != 0:
                raise SutraRefusal(0x3AD, 'DivergentNoMethod', 'the terms do not shrink; name a summation method')
            return m.nsum(f, [lo, m.inf]) if op == 'Σ' else m.nprod(f, [lo, m.inf])
        a, b = _int_arg(lo, 'a finite Σ/Π bound'), _int_arg(hi, 'a finite Σ/Π bound')
        vs = [f(m.mpf(i)) for i in range(a, b + 1)]
        return m.fsum(vs) if op == 'Σ' else m.fprod(vs)
    if k == 'lim':
        pt = _ev(t[1], vals, cd, stack)
        f = lambda x: _ev(t[3], vals, cd, stack + [x])
        return _limit(f, pt, t[2])
    if k == 'piece':
        for (c, v) in t[1]:
            a, b = _ev(c[2], vals, cd, stack), _ev(c[3], vals, cd, stack)
            ok = {'lt': a < b, 'le': a <= b, 'eq': a == b, 'ne': a != b}[c[1]]
            if ok: return _ev(v, vals, cd, stack)
        return _ev(t[2], vals, cd, stack)
    raise SutraRefusal(0x3A4, 'NonCanonical', f'node {k}')

def _agree(a, b, digits):
    """Digits on which two evaluations a ≠ b agree. Finite at one precision and ∞ at the other is no agreement: the
    relative error would be ∞/∞ = nan, `rel > 0` false, and a value would go out with full digits."""
    if not (mpmath.isfinite(a) and mpmath.isfinite(b)): return 0
    rel = abs(a - b) / max(abs(b), mpmath.mpf(10) ** (-(digits + 30)))
    return int(min(digits, mpmath.floor(-mpmath.log10(rel)))) if rel > 0 else digits

def value(t, vals=None, digits=30, complex_domain=False, exact=None):
    """exact: {stem: Fraction}, the same inputs exactly (the engine's value op); used only on the certified path."""
    if has_decision(t):
        r = certified(t, vals, digits, complex_domain, exact)
        return r['value'], r['digits']
    vals = dict(vals or {})
    res = []
    for extra in (15, 40):
        with mpmath.workdps(digits + extra):
            v = {k: mpmath.mpmathify(x) for k, x in vals.items()}
            res.append(_ev(t, v, complex_domain, []))
    a, b = res
    with mpmath.workdps(digits + 40):
        if a == b: got = digits
        else:
            got = _agree(a, b, digits)
    if got < digits: raise SutraRefusal(0x3AE, 'PrecisionNotReached', f'{got} of {digits} digits agree')
    return b, got


# ---- DESIGN-loops §1.4: certified decisions (round, iter, let; and piece) ----
# A DECISION is the integer a round picks, the truth of an iter's stop, or the branch a piece takes. It is made on an
# exact value (Fraction) or on an enclosure (mpmath.iv), never inferred from agreement:
#   - the exact path: rationals with +, ×, integer powers and perfect-power roots stay Fractions, through round, iter,
#     piece and let;
#   - the interval path: the first irrational value (a root that is not a perfect power, π, e, exp/log/sin/cos/tan)
#     becomes an enclosure [lo, hi]; a decision is accepted only when the enclosure excludes its jump, else the whole
#     term is re-evaluated at doubled precision, IV_RETRIES times (capped at IV_MAX_DIGITS), and then refused 0x3B3;
#   - a subterm with no interval rule (the other special functions, ∫, lim, infinite Σ/Π, derivatives, complex values)
#     is evaluated as before and carried as an UNCERTIFIED number: its value may be returned (two-precision agreement,
#     as for every term without decisions), but a decision that depends on it refuses 0x3B3 at once.
# Refusals: 0x3B1 the term's budget ran out; 0x3B2 the per-request step cap; 0x3B3 a decision not certified;
# 0x3B4 a rounding unit or divisor ≤ 0; 0x3B5 an indeterminate form (a nan never travels). Terms without round/iter/let/piece take the earlier path unchanged.
from .terms import children
from .canon import round_exact

STEP_CAP = 10 ** 7       # all iter steps of one evaluation, nested ones included
IV_RETRIES = 4           # precision doublings after the first attempt
IV_MAX_DIGITS = 10 ** 4  # the working precision never exceeds this many decimal digits
DECIDING = ('round', 'iter', 'let', 'piece')
IV_FN = ('EXP', 'LOG', 'SIN', 'COS', 'TAN', 'ABS')

class Straddle(Exception):
    def __init__(self, path, kind, boundary, lo, hi):
        super().__init__(kind); self.path, self.kind, self.boundary, self.lo, self.hi = path, kind, boundary, lo, hi

class Unc:
    """An uncertified number (no enclosure): usable as a value, never for a decision."""
    __slots__ = ('v',)
    def __init__(self, v): self.v = _defined(v, 'an uncertified value')

def has_decision(t):
    return t[0] in DECIDING or any(has_decision(c) for c in children(t))

def unrounded(t):
    """The unrounded twin (DESIGN-loops §2.1): every round node replaced by its x."""
    k = t[0]
    if k == 'round': return unrounded(t[1])
    if k in ('num', 'name', 'bvar'): return t
    if k in ('sum', 'prod'): return (k, tuple(unrounded(c) for c in t[1]))
    if k == 'pow': return ('pow', unrounded(t[1]), unrounded(t[2]))
    if k == 'app': return ('app', t[1], tuple(unrounded(c) for c in t[2]))
    if k == 'deriv': return ('deriv', unrounded(t[1]), t[2])
    if k == 'bind': return ('bind', t[1], unrounded(t[2]), unrounded(t[3]), unrounded(t[4]), t[5])
    if k == 'lim': return ('lim', unrounded(t[1]), t[2], unrounded(t[3]))
    if k == 'piece': return ('piece', tuple((_rel_map(c, unrounded), unrounded(v)) for c, v in t[1]), unrounded(t[2]))
    if k == 'iter': return ('iter', tuple(map(unrounded, t[1])), tuple(map(unrounded, t[2])), _rel_map(t[3], unrounded), unrounded(t[4]), t[5])
    if k == 'let': return ('let', unrounded(t[1]), unrounded(t[2]))
    raise ValueError(k)

def _rel_map(c, f): return ('rel', c[1], f(c[2]), f(c[3]))

def _iroot(n, q):
    """The exact integer q-th root of n ≥ 0, or None."""
    if n < 2: return n
    # 2 ≤ n < 2^q: the root lies in (1, 2), so none is an integer. Without this, Newton starts at r = 2 and r ** (q - 1)
    # is a q-bit number: q = 2.5·10¹² or 10⁶³ exhausted memory (R2 sweep #2524, #3673, #4250)
    if q >= n.bit_length(): return None
    r = 1 << -(-n.bit_length() // q)   # ≥ the root
    while True:   # Newton from above
        s = ((q - 1) * r + n // r ** (q - 1)) // q
        if s >= r: break
        r = s
    for c in (r - 1, r, r + 1):
        if c >= 0 and c ** q == n: return c
    return None

def _frac_of_raw(raw):
    from mpmath.libmp import to_rational, finf, fninf, fnan
    if raw in (finf, fninf, fnan): return None
    p, q = to_rational(raw); return Fraction(p, q)

def _mpf_frac(x):
    if isinstance(x, mpmath.mpf) and mpmath.isfinite(x): return _frac_of_raw(x._mpf_)
    return None

class MpIV:
    """The interval backend: mpmath.iv (vendored). A test-time Arb backend with the same methods cross-checks it (R2)."""
    name = 'mpmath.iv'
    def mk(self, q): return mpmath.iv.mpf(q.numerator) / mpmath.iv.mpf(q.denominator)
    def span(self, lo, hi):
        mk = mpmath.mp.make_mpf
        return mpmath.iv.mpf([mk(self.mk(lo)._mpi_[0]), mk(self.mk(hi)._mpi_[1])])
    def pi(self): return mpmath.iv.pi
    def e(self): return mpmath.iv.e
    def fn(self, name, x): return getattr(mpmath.iv, {'abs': 'fabs'}.get(name, name))(x)
    def ends(self, x):
        lo, hi = x._mpi_
        return _frac_of_raw(lo), _frac_of_raw(hi)
    def mid(self, x): return mpmath.mpf(x.mid)
    def set_dps(self, dps):
        old = mpmath.iv.prec; mpmath.iv.dps = dps
        return lambda: setattr(mpmath.iv, 'prec', old)

BACKEND = MpIV()
INEXACT_REL = Fraction(1, 2 ** 52)   # an inexact (binary) input x stands for [x(1 − 2⁻⁵²), x(1 + 2⁻⁵²)] (R1)

class _Cert:
    def __init__(self, vals, exact, cd, enclose=False, B=None):
        self.cd, self.steps, self.ties, self.counts = cd, 0, [], {'round': 0, 'stop': 0, 'piece': 0}
        self.by_interval = 0   # decisions taken on an enclosure (the rest were exact)
        self.B = B or BACKEND
        self.trace = []        # (kind, path, outcome) of every decision, for the Arb cross-check
        self.vals = {}
        for k, v in vals.items():
            if exact and k in exact: self.vals[k] = Fraction(exact[k])
            else:
                f = _mpf_frac(v)
                if f is None: self.vals[k] = Unc(v)
                elif enclose and f != 0:
                    r = abs(f) * INEXACT_REL; self.vals[k] = self.B.span(f - r, f + r)
                else: self.vals[k] = f

    # -- conversions --
    def iv(self, x):
        return self.B.mk(x) if isinstance(x, Fraction) else x
    def mp(self, x):
        if isinstance(x, Fraction): return mpmath.mpf(x.numerator) / x.denominator
        if isinstance(x, Unc): return x.v
        return self.B.mid(x)
    def ends(self, x):
        return (x, x) if isinstance(x, Fraction) else self.B.ends(x)

    # -- decisions --
    def rel(self, c, stack, path, kind):
        a, b = self.ev(c[2], stack, path + (0,)), self.ev(c[3], stack, path + (1,))
        if isinstance(a, Unc) or isinstance(b, Unc):
            raise SutraRefusal(0x3B3, 'DiscontinuityUndecided', f'{kind} at {_p(path)}: an operand has no interval enclosure')
        d = a - b if isinstance(a, Fraction) and isinstance(b, Fraction) else self.iv(a) - self.iv(b)
        lo, hi = self.ends(d)
        op = c[1]
        self.counts[kind] += 1; self.by_interval += not isinstance(d, Fraction)
        out = self._rel_outcome(op, lo, hi)
        if out is None: raise Straddle(_p(path), kind, 0, lo, hi)
        self.trace.append((kind, _p(path), out, not isinstance(d, Fraction)))
        return out

    @staticmethod
    def _rel_outcome(op, lo, hi):
        if lo is not None and hi is not None and lo == hi:   # a point enclosure is the value itself
            z = lo
            return {'lt': z < 0, 'le': z <= 0, 'eq': z == 0, 'ne': z != 0}[op]
        if op in ('lt', 'le'):
            if hi is not None and (hi < 0 or (op == 'le' and hi == 0)): return True
            if lo is not None and (lo > 0 or (op == 'lt' and lo == 0)): return False
        else:
            if (lo is not None and lo > 0) or (hi is not None and hi < 0): return op == 'ne'
        return None

    def round_(self, t, stack, path):
        x, u = self.ev(t[1], stack, path + (0,)), self.ev(t[2], stack, path + (1,))
        if isinstance(x, Unc) or isinstance(u, Unc):
            raise SutraRefusal(0x3B3, 'DiscontinuityUndecided', f'round at {_p(path)}: an operand has no interval enclosure')
        self.counts['round'] += 1
        ulo, uhi = self.ends(u)
        if uhi is not None and uhi <= 0: raise SutraRefusal(0x3B4, 'BadRoundingUnit', f'round at {_p(path)}: the unit {_num(uhi)} ≤ 0')
        if ulo is None or ulo <= 0:
            if ulo == uhi: raise SutraRefusal(0x3B4, 'BadRoundingUnit', f'round at {_p(path)}: the unit ≤ 0')
            raise Straddle(_p(path), 'round unit', 0, ulo, uhi)
        if isinstance(x, Fraction) and isinstance(u, Fraction):
            v, tie = round_exact(x, u, t[3])
            self.trace.append(('round', _p(path), v / u, False))
            if tie: self.ties.append({'path': _p(path), 'kind': 'round near', 'value': str(x)})
            return v
        q = self.iv(x) / self.iv(u); self.by_interval += 1
        lo, hi = self.ends(q)
        if lo is None or hi is None: raise Straddle(_p(path), f'round {t[3]}', None, lo, hi)
        if t[3] == 'down':
            k = lo.__floor__()
            if hi.__floor__() != k: raise Straddle(_p(path), 'round down', hi.__floor__(), lo, hi)
        else:   # near: the enclosure of x/u must hold no half-integer (an odd integer in 2·x/u)
            o = (2 * lo).__ceil__(); o += (o % 2 == 0)
            if o <= 2 * hi: raise Straddle(_p(path), 'round near', Fraction(o, 2), lo, hi)
            k = (lo + Fraction(1, 2)).__floor__()
        self.trace.append(('round', _p(path), Fraction(k), True))
        return k * u if isinstance(u, Fraction) else self.B.mk(Fraction(k)) * u

    # -- evaluation --
    def combine(self, op, xs):
        if any(isinstance(x, Unc) for x in xs):
            ms = [self.mp(x) for x in xs]
            return Unc(mpmath.fsum(ms) if op == 'sum' else mpmath.fprod(ms))
        if all(isinstance(x, Fraction) for x in xs):
            out = Fraction(0) if op == 'sum' else Fraction(1)
            for x in xs: out = out + x if op == 'sum' else out * x
            return out
        out = self.iv(xs[0])
        for x in xs[1:]: out = out + self.iv(x) if op == 'sum' else out * self.iv(x)
        return out

    def pow_(self, b, e, path):
        m = mpmath
        if isinstance(b, Unc) or isinstance(e, Unc):
            bm, em = self.mp(b), self.mp(e)
            if not self.cd and m.im(bm) == 0 and m.re(bm) < 0 and m.im(em) == 0 and m.re(em) != m.nint(m.re(em)):
                raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'a negative real base to a non-integer power')
            if bm == 0 and m.re(em) < 0: raise SutraRefusal(0x3AB, 'NumericalCheckFailed', '0 to a negative power (a pole)')
            return Unc(m.power(bm, em))
        if isinstance(b, Fraction) and isinstance(e, Fraction):
            if b == 0 and e < 0: raise SutraRefusal(0x3AB, 'NumericalCheckFailed', '0 to a negative power (a pole)')
            if b == 0: return Fraction(0) if e > 0 else Fraction(1)
            if e.denominator == 1:
                big = max(abs(b.numerator), b.denominator)
                if abs(int(e)) * big.bit_length() <= 4 * IV_MAX_DIGITS: return b ** int(e)
                return self.iv(b) ** int(e)
            if b < 0:
                if not self.cd: raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'a negative real base to a non-integer power')
                return Unc(m.power(self.mp(b), self.mp(e)))
            p, q = e.numerator, e.denominator
            rn, rd = _iroot(b.numerator, q), _iroot(b.denominator, q)
            if rn is not None and rd is not None and abs(p) * max(rn, rd).bit_length() <= 4 * IV_MAX_DIGITS:
                return Fraction(rn, rd) ** p
            if q == 2: return self.B.fn('sqrt', self.iv(b)) ** p
            return self.B.fn('exp', self.B.fn('log', self.iv(b)) * self.iv(e))
        if isinstance(e, Fraction) and e.denominator == 1:
            blo, bhi = self.ends(b)
            if e < 0 and (blo is None or bhi is None or blo <= 0 <= bhi):
                if blo == bhi == 0: raise SutraRefusal(0x3AB, 'NumericalCheckFailed', '0 to a negative power (a pole)')
                raise Straddle(_p(path), 'pole', 0, blo, bhi)
            return self.iv(b) ** int(e)
        blo, bhi = self.ends(b)
        if bhi is not None and bhi < 0:
            if not self.cd: raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'a negative real base to a non-integer power')
            return Unc(m.power(self.mp(b), self.mp(e)))
        if blo is None or blo <= 0:
            if blo == bhi == 0:
                elo, _ = self.ends(e)
                if elo is not None and elo > 0: return Fraction(0)
            raise Straddle(_p(path), 'branch', 0, blo, bhi)
        if isinstance(e, Fraction) and e == Fraction(1, 2): return self.B.fn('sqrt', self.iv(b))
        return self.B.fn('exp', self.B.fn('log', self.iv(b)) * self.iv(e))

    def app(self, fid, args, path):
        m = mpmath
        if fid in IV_FN and not any(isinstance(a, Unc) for a in args):
            a = args[0]
            if fid == 'ABS': return abs(a) if isinstance(a, Fraction) else self.B.fn('abs', a)
            if isinstance(a, Fraction) and a == 0 and fid != 'LOG': return Fraction(1) if fid in ('EXP', 'COS') else Fraction(0)
            if fid == 'LOG':
                lo, hi = self.ends(a)
                if a == 1: return Fraction(0)
                if hi is not None and hi <= 0:
                    if not self.cd: raise SutraRefusal(0x3AF, 'AmbiguousBranch', 'log of a negative real outside a declared complex domain')
                    return Unc(m.log(self.mp(a)))
                if lo is None or lo <= 0: raise Straddle(_p(path), 'branch', 0, lo, hi)
            return self.B.fn(fid.lower(), self.iv(a))
        return Unc(_apply(fid, [self.mp(a) for a in args], self.cd))

    def opaque(self, t, stack, path):
        if has_decision(t):
            raise SutraRefusal(0x3B3, 'DiscontinuityUndecided', f'{t[0]} at {_p(path)}: a decision inside it has no interval rule')
        vals = {k: self.mp(v) for k, v in self.vals.items()}
        return Unc(_ev(t, vals, self.cd, [self.mp(s) for s in stack]))

    def ev(self, t, stack, path=()):
        k = t[0]
        if k == 'num': return t[1]
        if k == 'name':
            if t[1] == INF_WORD: return Unc(mpmath.inf)
            fid = FN.get(t[1])
            if fid == 'PI': return self.B.pi()
            if fid == 'E_CONST': return self.B.e()
            if fid == 'IMAG_UNIT': return Unc(mpmath.mpc(0, 1))
            if t[1] not in self.vals: raise SutraRefusal(0x3A2, 'UndeclaredName', f'{t[1]} has no value')
            return self.vals[t[1]]
        if k == 'bvar': return stack[-1 - t[1]]
        if k in ('sum', 'prod'): return self.combine(k, [self.ev(c, stack, path + (i,)) for i, c in enumerate(t[1])])
        if k == 'pow': return self.pow_(self.ev(t[1], stack, path + (0,)), self.ev(t[2], stack, path + (1,)), path)
        if k == 'app':
            fid = FN.get(t[1])
            if fid is None: raise SutraRefusal(0x3A7, 'Unsupported', f'no evaluation rule for {t[1]}')
            return self.app(fid, [self.ev(c, stack, path + (i,)) for i, c in enumerate(t[2])], path)
        if k == 'bind' and t[1] != '∫':
            hi = self.ev(t[3], stack, path + (1,))
            if not (isinstance(hi, Unc) and hi.v == mpmath.inf):
                lo = self.ev(t[2], stack, path + (0,))
                a, b = (self._int(x, path) for x in (lo, hi))
                return self.combine('sum' if t[1] == 'Σ' else 'prod',
                                    [self.ev(t[4], stack + [Fraction(i)], path + (2,)) for i in range(a, b + 1)] or [Fraction(0 if t[1] == 'Σ' else 1)])
        if k in ('bind', 'lim', 'deriv'): return self.opaque(t, stack, path)
        if k == 'piece':
            for i, (c, v) in enumerate(t[1]):
                if self.rel(c, stack, path + (3 * i,), 'piece'): return self.ev(v, stack, path + (3 * i + 2,))
            return self.ev(t[2], stack, path + (3 * len(t[1]),))
        if k == 'round': return self.round_(t, stack, path)
        if k == 'let':
            v = self.ev(t[1], stack, path + (0,)); return self.ev(t[2], stack + [v], path + (1,))
        if k == 'iter':
            n_ = len(t[1])
            state = [self.ev(c, stack, path + (j,)) for j, c in enumerate(t[1])]
            n, budget = 0, t[5]
            while True:
                inner = stack + [Fraction(n)] + state
                if self.rel(t[3], inner, path + (2 * n_,), 'stop'): return self.ev(t[4], inner, path + (2 * n_ + 2,))
                if n == budget: raise SutraRefusal(0x3B1, 'IterationBudgetExceeded', f'iter at {_p(path)}: the stop did not hold within its budget of {budget} steps')
                self.steps += 1
                if self.steps > STEP_CAP: raise SutraRefusal(0x3B2, 'StepCapExceeded', f'more than {STEP_CAP} iter steps in one request')
                state = [self.ev(u, inner, path + (n_ + j,)) for j, u in enumerate(t[2])]
                n += 1
        raise SutraRefusal(0x3A4, 'NonCanonical', f'node {k}')

    def _int(self, x, path):
        if isinstance(x, Fraction) and x.denominator == 1: return int(x)
        if not isinstance(x, Unc):
            lo, hi = self.ends(x)
            if lo is not None and lo == hi and lo.denominator == 1: return int(lo)
        raise SutraRefusal(0x3A7, 'Unsupported', 'a finite Σ/Π bound needs an integer')

def _p(path): return '.'.join(map(str, path)) or 'root'

def _run(t, vals, exact, cd, dps, enclose=False, B=None):
    B = B or BACKEND
    restore = B.set_dps(dps)
    try:
        with mpmath.workdps(dps):
            c = _Cert(vals, exact, cd, enclose, B)
            r = c.ev(t, [])
            return r, c
    finally:
        restore()

def _inexact(vals, exact):
    """The inputs given only as binary numbers (no exact rational): finite real mpf/float values outside `exact`."""
    return [k for k, v in vals.items() if not (exact and k in exact) and _mpf_frac(mpmath.mpmathify(v)) not in (None, 0)]

def _num(x):
    """A number for a refusal's text: exact when short, else 20 significant digits. (R2 sweep #6316: str() of a
    floor boundary past 4300 digits raised ValueError inside the refusal itself.)"""
    if x is None: return 'unbounded'
    x = Fraction(x)
    if max(abs(x.numerator), x.denominator).bit_length() < 1000: return str(x)
    with mpmath.workdps(25): return mpmath.nstr(mpmath.mpf(x.numerator) / x.denominator, 20)

def _refuse_straddle(s):
    f = lambda x: 'unbounded' if x is None else mpmath.nstr(mpmath.mpf(x.numerator) / x.denominator, 20)
    raise SutraRefusal(0x3B3, 'DiscontinuityUndecided', f'{s.kind} at node {s.path}: boundary {_num(s.boundary)}, enclosure [{f(s.lo)}, {f(s.hi)}] after {IV_RETRIES} doublings')

def certified(t, vals=None, digits=30, complex_domain=False, exact=None, B=None):
    """-> {'value': mpf/mpc, 'digits': d, 'path': 'exact'|'interval'|'uncertified', 'ties': [...], 'decisions': {...},
    'decided_on_intervals': n, 'trace': [(kind, node, outcome, on_interval)], 'arb_check': ...}

    R1 (review design-a-engine): only inputs given as exact rationals (`exact`) take the exact path. An input given only
    as a binary number stands for its enclosure (relative radius 2⁻⁵², which holds every decimal that rounds to it at
    double precision or finer). Phase 1 takes every decision on those enclosures (certified, or 0x3B3); phase 2 then
    computes the value at the binary inputs themselves, and must take the same decisions."""
    vals = dict(vals or {})
    inexact = _inexact(vals, exact)
    if not inexact: return _certify(t, vals, digits, complex_domain, exact, False, B)
    first = _certify(t, vals, digits, complex_domain, exact, True, B, decisions_only=True)
    r = _certify(t, vals, digits, complex_domain, exact, False, B)
    if [x[:3] for x in r['trace']] != [x[:3] for x in first['trace']]:
        raise SutraRefusal(0x3B3, 'DiscontinuityUndecided', 'the decisions at the binary inputs differ from those on their enclosures')
    r.update(path='interval' if r['path'] == 'exact' else r['path'], decided_on_intervals=first['decided_on_intervals'],
             trace=first['trace'], inexact_inputs=inexact)
    r.pop('exact', None)
    r['arb_check'] = 'pending' if r['decided_on_intervals'] else 'not needed'
    return r

def _certify(t, vals, digits, complex_domain, exact, enclose, B, decisions_only=False):
    last = None
    for attempt in range(IV_RETRIES + 1):
        dps = min((digits + 15) * 2 ** attempt, IV_MAX_DIGITS)
        try:
            r, c = _run(t, vals, exact, complex_domain, dps, enclose, B)
            info = {'ties': c.ties, 'decisions': c.counts, 'decided_on_intervals': c.by_interval, 'steps': c.steps, 'trace': c.trace,
                    'arb_check': 'pending' if c.by_interval else 'not needed'}
            if decisions_only: return info
            if isinstance(r, Fraction):
                with mpmath.workdps(digits + 40): v = mpmath.mpf(r.numerator) / r.denominator
                return {'value': v, 'digits': digits, 'path': 'exact', 'exact': r, **info}
            if isinstance(r, Unc):
                r2, c2 = _run(t, vals, exact, complex_domain, dps + 25, enclose, B)
                a, b = r.v, (r2.v if isinstance(r2, Unc) else c2.mp(r2))
                with mpmath.workdps(dps + 40):
                    if a == b: got = digits
                    else:
                        got = _agree(a, b, digits)
                if got >= digits: return {'value': b, 'digits': digits, 'path': 'uncertified', **info}
                last = ('precision', got); continue
            lo, hi = c.ends(r)
            if lo is not None and hi is not None:
                w, mag = hi - lo, max(abs(lo), abs(hi))
                if w == 0 or (mag > 0 and w <= mag * Fraction(1, 10 ** digits)):
                    with mpmath.workdps(digits + 40): v = mpmath.mpf((lo + hi).numerator) / (lo + hi).denominator / 2
                    return {'value': v, 'digits': digits, 'path': 'interval', 'enclosure': (lo, hi), **info}
            last = ('precision', None)
        except Straddle as s:
            last = ('straddle', s)
        if dps >= IV_MAX_DIGITS: break
    if last[0] == 'straddle': _refuse_straddle(last[1])
    raise SutraRefusal(0x3AE, 'PrecisionNotReached', f'{last[1]} of {digits} digits' if last[1] is not None else f'the enclosure is wider than {digits} digits')

def nearly(t, printed, unit, vals=None, exact=None, complex_domain=False):
    """nearly(unit) (DESIGN-loops §2.1): |printed − v| < unit, decided by the certified evaluator (0x3B3 if it straddles)."""
    d = ('sum', (t, ('num', -Fraction(printed))))
    test = ('piece', ((('rel', 'lt', ('app', W['ABS'][0], (d,)), ('num', Fraction(unit))), ('num', Fraction(1))),), ('num', Fraction(0)))
    if Fraction(unit) <= 0: raise SutraRefusal(0x3B4, 'BadRoundingUnit', f'nearly({_num(unit)}): the unit ≤ 0')
    r = certified(test, vals, 10, complex_domain, exact)
    return r['exact'] == 1, ('interval' if r['decided_on_intervals'] else 'exact')

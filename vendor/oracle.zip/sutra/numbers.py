# SPDX-License-Identifier: AGPL-3.0-only
"""L4 numbers (DESIGN v2 A1), exactly as registered in docs/L4-registration.md (7ad103f, before the run).

kaṭapayādi: Fleet p. 791; the last consonant of each akṣara; a bare vowel = 0; a final consonant, anusvāra and visarga give
nothing; digits read right to left unless the convention says otherwise.
bhūtasaṅkhyā: each space-separated token is segmented over the registered stem lexicon by the L1 lattice decoder (soft
PED); the final member may carry a listed case ending; a token that does not segment fully is not a numeral; the values in
text order are read right to left, a multi-digit value keeping its own digit order; a conflict word yields every reading."""
import collections, itertools, math, pathlib, random
from .ped import sandhi as m, lattice as L
from .ped.dev2iast import dev2iast

KP = {'k': 1, 'kh': 2, 'g': 3, 'gh': 4, 'ṅ': 5, 'c': 6, 'ch': 7, 'j': 8, 'jh': 9, 'ñ': 0,
      'ṭ': 1, 'ṭh': 2, 'ḍ': 3, 'ḍh': 4, 'ṇ': 5, 't': 6, 'th': 7, 'd': 8, 'dh': 9, 'n': 0,
      'p': 1, 'ph': 2, 'b': 3, 'bh': 4, 'm': 5,
      'y': 1, 'r': 2, 'l': 3, 'v': 4, 'ś': 5, 'ṣ': 6, 's': 7, 'h': 8, 'ḷ': 9}
VOWELS = set(m.VOW)

def _iast(text):
    return text if all(ord(c) < 0x900 or ord(c) > 0x97F for c in text) else dev2iast(text)

def katapayadi_digits(text, kp=KP):
    """-> the digits in text order (one per akṣara that has a vowel)."""
    ph = m.tok(_iast(text))
    if ph is None: raise ValueError('a character outside the phoneme table')
    digits, cons = [], []
    for p in ph:
        if p in (m.SP, m.AV): continue
        if p in VOWELS: digits.append(kp[cons[-1]] if cons else 0); cons = []
        elif p in ('ṃ', 'ḥ'): continue
        else: cons.append(p)
    return digits                       # trailing consonants (no vowel) give nothing

def katapayadi(text, right_to_left=True, kp=KP):
    d = katapayadi_digits(text, kp)
    s = ''.join(map(str, reversed(d) if right_to_left else d))
    return int(s) if s else None

def random_kp(seed=0):
    """RANDOM arm: the 10 digit values permuted over the consonant classes."""
    perm = list(range(10)); random.Random(seed).shuffle(perm)
    return {k: perm[v] for k, v in KP.items()}

# ---- bhūtasaṅkhyā ----
ENDINGS = ['', 'ḥ', 'm', 'ṃ', 'au', 'ā', 'āḥ', 'ān', 'ena', 'aiḥ', 'e', 'asya', 'āt']

def load_lexicon(path=None):
    path = path or pathlib.Path(__file__).resolve().parents[2] / 'docs/L4-lexicon-registered.tsv'
    lex = {}
    for line in open(path, encoding='utf-8'):
        if line.startswith('#') or not line.strip(): continue
        w, vals = line.split('\t')[:2]
        lex[w] = [int(v) for v in vals.split(',')]
    return lex

class Bhuta:
    def __init__(self, lexicon=None):
        self.values = lexicon or load_lexicon()
        stems = [tuple(m.tok(w)) for w in self.values if m.tok(w)]
        self.lex = L.Lexicon([(None, [s], None) for s in stems])
        self.by_tok = {tuple(m.tok(w)): w for w in self.values if m.tok(w)}
        K = m.Classes(m.GRID, m.SIB); ped = m.ped_proposer(K)
        self.prop = lambda s, p, r: ped(s, p, r) | m.identity_props(r)

    def segment(self, token):
        """A token -> the list of stems, or None if it is not wholly numeral stems (+ a final case ending)."""
        t = _iast(token)
        for e in ENDINGS:
            if e and not t.endswith(e): continue
            core = t[:len(t) - len(e)] if e else t
            # an a-stem's final a merges into a vowel-initial ending (gaja + āḥ = gajāḥ), so try core + 'a' as well
            for c in ([core, core + 'a'] if e and e[0] in 'āaeoi' else [core]):
                s = m.tok(c)
                if not s: continue
                if tuple(s) in self.by_tok: return [self.by_tok[tuple(s)]]
                seq, _, _ = L.decode(s, self.lex, self.prop, None)
                if seq: return [self.by_tok.get(tuple(u)) for u in seq]
        return None

    def decode(self, phrase):
        """-> (set of numbers, the stems used per numeral token)."""
        segs = [self.segment(tok) for tok in phrase.replace('-', ' ').split()]
        stems = [w for sg in segs if sg and all(sg) for w in sg]
        if not stems: return set(), []
        out = set()
        for choice in itertools.product(*[self.values[w] for w in stems]):
            out.add(int(''.join(str(v) for v in reversed(choice))))
        return out, [sg for sg in segs if sg and all(sg)]

def numeral_runs(B, phrase):
    """L4 v3 (owner-approved, reviewer-agreed): numeral spans by GREEDY ADJACENT-TOKEN JOINING. From each position the
    LONGEST run of adjacent tokens whose joined string segments wholly into lexicon stems (soft-PED sandhi at the
    junctions, a listed case ending on the last member) is taken; a token in no such span ends the current run. Adjacent
    spans form one run. -> a list of runs, each a list of stems in text order."""
    toks = phrase.replace('-', ' ').split()
    runs, cur, i = [], [], 0
    while i < len(toks):
        best = None
        for j in range(len(toks), i, -1):
            sg = B.segment(''.join(toks[i:j]))
            if sg and all(sg): best = (j, sg); break
        if best: cur += best[1]; i = best[0]
        else:
            if cur: runs.append(cur); cur = []
            i += 1
    if cur: runs.append(cur)
    return runs

def random_bhuta(lexicon=None, seed=0):
    """RANDOM arm: each stem's value drawn from the lexicon's own value multiset."""
    lex = lexicon or load_lexicon(); pool = [v for vs in lex.values() for v in vs]; rng = random.Random(seed)
    return {w: [rng.choice(pool)] for w in sorted(lex)}


# ---- v2 (amendment 16): historical-romanisation normaliser, target Geneva 1894 (= IAST); nothing derived from items ----
import unicodedata, re as _re
CIRCUMFLEX = {'â': 'ā', 'ê': 'e', 'î': 'ī', 'ô': 'o', 'û': 'ū'}
ISO15919 = {'ṁ': 'ṃ'}   # v3 schema-check amendment (reviewer ACK, before the run): ISO 15919 anusvāra = IAST ṃ
def normalise(text):
    t = unicodedata.normalize('NFC', text).lower()
    t = t.replace('⟨', '').replace('⟩', '')                      # editorial brackets: contents kept
    t = t.translate(str.maketrans({'ē': 'e', 'ō': 'o', **CIRCUMFLEX, **ISO15919}))   # Sanskrit e/o are always long; circumflex = length
    t = _re.sub(r"[0-9०-९।॥|/=,;:.!?\"()\[\]{}]", ' ', t)          # digits, daṇḍas and punctuation dropped
    return _re.sub(r'\s+', ' ', t).strip()

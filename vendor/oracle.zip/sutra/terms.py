# SPDX-License-Identifier: AGPL-3.0-only
"""The term algebra of DESIGN §0 as immutable tuples (hashable, structurally comparable).

Canonical node kinds (what प्रकृतिः outputs):
  ('num', Fraction)                      exact rational
  ('name', stem, kind)                   kind in KINDS; stem is a Devanagari a-stem
  ('bvar', k)                            de Bruijn index of a binder's variable (0 = innermost)
  ('sum', (t, ...))   ('prod', (t, ...)) n >= 2, flattened, sorted
  ('pow', base, exp)
  ('app', fname, (arg, ...))             fname is a stem; the function's kind is 'fn'
  ('deriv', term, var)                   d term / d var; var is a ('name', _, 'var')
  ('bind', op, lo, hi, body, method)     op in BINDERS; body sees ('bvar', 0); method: None or a summation method
  ('lim', point, side, body)             body sees ('bvar', 0); side in ('both', 'left', 'right')
  ('piece', ((cond, term), ...), other)  cond = ('rel', op, a, b), op in RELS
  ('round', x, unit, mode)               mode in MODES; unit > 0; the result is a multiple of unit (DESIGN-loops §1.2)
                                         down: unit·⌊x/unit⌋; near: the nearest multiple, a tie away from zero
  ('iter', inits, steps, stop, out, budget)
                                         inits = (t1..tk), steps = (u1..uk), stop = ('rel', op, a, b), out a term,
                                         budget an int literal 1..ITER_MAX. steps, stop and out see k+1 bound variables:
                                         the counter n = ('bvar', k) and the state s_j = ('bvar', k-j), j = 1..k
  ('let', value, body)                   body sees ('bvar', 0) = value
Input-only kinds, removed by प्रकृतिः: ('sub', a, b), ('div', a, b), ('neg', a), ('sqrt', a),
  ('quot', a, b) -> round(a·b^-1, 1, down),  ('rem', a, b) -> a + (-1)·round(a, b, down).
"""
from fractions import Fraction

KINDS = ('const', 'var', 'fn', 'rate')
BINDERS = ('Σ', 'Π', '∫')
RELS = ('lt', 'le', 'eq', 'ne')
MODES = ('near', 'down')
ITER_MAX = 10 ** 6   # the largest budget literal (DESIGN-loops §1.4)
NBOUND = 10          # bound names BOUND0..9: a term nests at most this many bound variables
INF_STEM = 'अनन्त'   # must equal words.tsv INF (checked in tests)
INF = ('name', INF_STEM, 'const')

def num(v): return ('num', Fraction(v))
def name(stem, kind='var'): return ('name', stem, kind)
def S(*ts): return ('sum', tuple(ts))
def P(*ts): return ('prod', tuple(ts))
def pw(b, e): return ('pow', b, e)
def app(f, *args): return ('app', f, tuple(args))

def children(t):
    k = t[0]
    if k in ('num', 'name', 'bvar'): return ()
    if k in ('sum', 'prod'): return t[1]
    if k == 'pow': return (t[1], t[2])
    if k == 'app': return t[2]
    if k == 'deriv': return (t[1], t[2])
    if k == 'bind': return (t[2], t[3], t[4])
    if k == 'lim': return (t[1], t[3])
    if k == 'piece': return tuple(x for c, v in t[1] for x in (c[2], c[3], v)) + (t[2],)
    if k == 'round': return (t[1], t[2])
    if k == 'iter': return t[1] + t[2] + (t[3][2], t[3][3], t[4])
    if k == 'let': return (t[1], t[2])
    if k in ('sub', 'div', 'quot', 'rem'): return (t[1], t[2])
    if k in ('neg', 'sqrt'): return (t[1],)
    raise ValueError(f'unknown node {k}')

def binds(t):
    """How many bound variables each child of t sees beyond t's own scope, in children() order."""
    k = t[0]
    if k == 'bind': return (0, 0, 1)
    if k == 'lim': return (0, 1)
    if k == 'let': return (0, 1)
    if k == 'iter': n = len(t[1]); return (0,) * n + (n + 1,) * (n + 3)
    return (0,) * len(children(t))

def size(t): return 1 + sum(size(c) for c in children(t))

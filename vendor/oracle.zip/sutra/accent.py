# SPDX-License-Identifier: AGPL-3.0-only
"""L3 sound (DESIGN A1), exactly as registered in docs/L3-registration.md (before the run).
Aufrecht 1877 romanisation → IAST phonemes with the printed accent per vowel; svara per syllable by the
Prātiśākhya/Pāṇini rules (U udātta, S independent svarita, Sd dependent svarita, P pracaya, A anudātta);
a feature vector per phoneme from the PED feature table."""
import re, random, unicodedata, pathlib

ACUTE, GRAVE, DIAER = '́', '̀', '̈'
VOWELS = ('a', 'ā', 'i', 'ī', 'u', 'ū', 'ṛ', 'ṝ', 'e', 'o', 'ai', 'au')
ASP = {'k', 'g', 'c', 'j', 'ṭ', 'ḍ', 't', 'd', 'p', 'b', 'ḻ'}
CONS = set('kgṅcjñṭḍṇtdnpbmyrlvśṣsh') | {'ḻ'}
SIB_H = {'s', 'ṣ', 'ś', 'h'}
VOWEL_BASES = set('aāiīuūeo') | {'ṛ'}

class Unknown(ValueError): pass

def chars(text):
    """-> [(base letter NFC, accent 'U'|'S'|None, diaeresis)] with word boundaries as ' '."""
    out = []
    for ch in unicodedata.normalize('NFD', text.lower()):
        if ch in (ACUTE, GRAVE, DIAER):
            if not out or out[-1][0] == ' ': raise Unknown(f'a mark with no letter in {text!r}')
            b, a, d = out[-1]
            if ch != DIAER and a: raise Unknown(f'two accents on one letter in {text!r}')
            out[-1] = (b, 'U' if ch == ACUTE else 'S', d) if ch != DIAER else (b, a, True)
        elif unicodedata.combining(ch):
            b, a, d = out[-1]; out[-1] = (unicodedata.normalize('NFC', b + ch), a, d)
        elif ch in ' -\t.,': out.append((' ', None, False))
        elif ch in '’\'ʻ·⟨⟩?°': continue   # avagraha; amendment 28: · inside a word, editorial ⟨?⟩, the ° refrain stub (not expanded)
        else: out.append((ch, None, False))
    return out

def phonemes(text):
    """Aufrecht → [(IAST phoneme, accent)] per the registered table; ' ' marks a word boundary."""
    c = chars(text); out, i = [], 0
    def prev_vowel(): return bool(out) and out[-1][0] in VOWELS
    while i < len(c):
        b, a, d = c[i]; nb = c[i + 1] if i + 1 < len(c) else (None, None, False)
        nfd = unicodedata.normalize('NFD', b)
        if nfd[0] in 'aeiou' and '\u0323' in nfd: b = unicodedata.normalize('NFC', nfd.replace('\u0323', ''))   # Aufrecht's hiatus dot
        b = {'ē': 'e', 'ō': 'o', 'n\u0304': 'ṅ'}.get(b, b)
        if a and b not in VOWEL_BASES: raise Unknown(f'an accent printed on the consonant {b!r} in {text!r}')   # amendment 29
        if b == 'n\u0310': out.append(('n\u0310', None)); i += 1; continue   # anunāsika: like ṃ, no segment; feature UNCOVERED
        if b == ' ':
            if out and out[-1][0] != ' ': out.append((' ', None))
            i += 1; continue
        if b == 'ṛ' and nb[0] in ('i', 'ī'): out.append(('ṛ' if nb[0] == 'i' else 'ṝ', a or nb[1])); i += 2; continue
        if b == 's' and nb[0] == 'h': out.append(('ṣ', None)); i += 2; continue
        if b == 'ṣ': out.append(('ś', None)); i += 1; continue
        if b == 'c' and nb[0] == 'h':
            if prev_vowel(): out.append(('c', None))
            out.append(('ch', None)); i += 2; continue
        if b == 'ḷ': b = 'ḻ'
        if b in ASP and nb[0] == 'h': out.append((b + 'h', None)); i += 2; continue
        if b == 'a' and nb[0] in ('i', 'u') and not nb[2]:
            if a and nb[1]: raise Unknown(f'two accents on one diphthong in {text!r}')
            out.append(('a' + nb[0], a or nb[1])); i += 2; continue
        if b == 'ṅ':
            nxt = c[i + 1][0] if i + 1 < len(c) else None
            out.append(('ṃ' if nxt in SIB_H else 'ṅ', None)); i += 1; continue
        if b in VOWELS or b in ('ṃ', 'ḥ') or b in CONS: out.append((b, a if b in VOWELS else None)); i += 1; continue
        raise Unknown(f'character {b!r} (U+{ord(b[0]):04X}) outside the declared table in {text!r}')
    while out and out[-1][0] == ' ': out.pop()
    return out

def syllables(ph): return [a for p, a in ph if p in VOWELS]

def svara(marks):
    """marks: per syllable 'U'|'S'|None, over the whole verse -> labels U/S/Sd/P/A (registered rules)."""
    n = len(marks); lab = [m for m in marks]
    for i in range(n):
        if lab[i] is None and i > 0 and marks[i - 1] == 'U':
            lab[i] = 'A' if (i + 1 < n and marks[i + 1] in ('U', 'S')) else 'Sd'
    for j in range(n):
        if lab[j] in ('S', 'Sd'):
            k = j + 1
            while k < n and marks[k] is None and lab[k] is None: k += 1
            stop = k if (k < n and marks[k] in ('U', 'S')) else None
            for t in range(j + 1, k):
                lab[t] = 'A' if (stop is not None and t == stop - 1) else 'P'
    return [l if l is not None else 'A' for l in lab]

# ---- features (agent-handovers/ped-feature-table.md §1.2 TSV) ----
DEV = {'a': 'अ', 'ā': 'आ', 'i': 'इ', 'ī': 'ई', 'u': 'उ', 'ū': 'ऊ', 'ṛ': 'ऋ', 'ṝ': 'ॠ', 'e': 'ए', 'ai': 'ऐ', 'o': 'ओ', 'au': 'औ',
       'k': 'क', 'kh': 'ख', 'g': 'ग', 'gh': 'घ', 'ṅ': 'ङ', 'c': 'च', 'ch': 'छ', 'j': 'ज', 'jh': 'झ', 'ñ': 'ञ',
       'ṭ': 'ट', 'ṭh': 'ठ', 'ḍ': 'ड', 'ḍh': 'ढ', 'ṇ': 'ण', 't': 'त', 'th': 'थ', 'd': 'द', 'dh': 'ध', 'n': 'न',
       'p': 'प', 'ph': 'फ', 'b': 'ब', 'bh': 'भ', 'm': 'म', 'y': 'य', 'r': 'र', 'l': 'ल', 'v': 'व', 'ś': 'श', 'ṣ': 'ष',
       's': 'स', 'h': 'ह', 'ṃ': 'ं', 'ḥ': 'ः'}

def load_table(path):
    txt = open(path, encoding='utf-8').read()
    block = re.search(r'```tsv\n(.*?)```', txt, re.S).group(1).strip().splitlines()
    head = block[0].split('\t'); rows = [l.split('\t') for l in block[1:] if l.strip()]
    keep = [i for i, h in enumerate(head) if h not in ('letter', 'src')]
    return {r[0]: tuple(r[i] for i in keep) for r in rows}, [head[i] for i in keep]

def features(ph, table):
    """-> per phoneme the vector, or None where the table has no row (reported, not guessed)."""
    return [table.get(DEV.get(p)) if p != ' ' else None for p, _ in ph if p != ' ']

def permuted_table(table, seed=0):
    ks = sorted(table); vs = [table[k] for k in ks]; random.Random(seed).shuffle(vs)
    return dict(zip(ks, vs))

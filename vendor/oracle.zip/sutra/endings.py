# SPDX-License-Identifier: AGPL-3.0-only
"""Case endings of a-stems, computed (GRAMMAR §1; review step0 fixes A and B).

masculine: nom -ः  acc -म्  ins -एन  abl -आत्  gen -स्य  loc -े
neuter:    nom -म्  acc -म्  (other cases as masculine)
ṇatva (Aṣṭādhyāyī 8.4.1 रषाभ्यां नो णः समानपदे, 8.4.2 अट्कुप्वाङ्नुम्व्यवायेऽपि; agent-handovers/ped-feature-table.md §2.4):
the न of -एन becomes ण when an र, ष or ऋ/ॠ precedes it in the word and every sound between is a vowel, ह य व र,
a k-varga or p-varga consonant, or anusvāra. Any other sound (c-, ṭ-, t-varga incl. ण/न, श, स, ल) blocks it.
Numerals are indeclinable (fix C); this module never sees them."""

CASES = ('nom', 'acc', 'ins', 'abl', 'gen', 'loc')
TRIGGERS = set('रषऋॠृॄ')
PASS = set('अआइईउऊऋॠऌॡएऐओऔािीुूृॄॢॣेैोौंँ') | set('हयवर') | set('कखगघङ') | set('पफबभम') | {'्'}

def _natva(stem):
    """Would an n added right after this stem (through the vowel e) become ṇ?"""
    for c in reversed(stem):
        if c in TRIGGERS: return True
        if c not in PASS: return False
    return False

def form(stem, gender, case):
    if gender not in ('m', 'n'): raise ValueError(f'a-stem gender must be m or n, not {gender!r}')
    if case == 'nom': return stem + ('ः' if gender == 'm' else 'म्')
    if case == 'acc': return stem + 'म्'
    if case == 'ins': return stem + ('ेण' if _natva(stem) else 'ेन')
    if case == 'abl': return stem + 'ात्'
    if case == 'gen': return stem + 'स्य'
    if case == 'loc': return stem + 'े'
    raise ValueError(case)

def gen_plural(stem):
    """Genitive plural of an a-stem (m. and n. alike): -आनाम्, with ṇatva (रामाणाम्). Pada style: no sandhi to -आनां."""
    return stem + ('ाणाम्' if _natva(stem) else 'ानाम्')

def analyse(word, gender):
    """word -> (stem, case) for an a-stem of this gender, or None. nom and acc coincide for neuter: returns 'nom'."""
    for case, suf in (('ins', 'ेण'), ('ins', 'ेन'), ('abl', 'ात्'), ('gen', 'स्य'), ('loc', 'े'),
                      ('nom', 'ः' if gender == 'm' else 'म्'), ('acc', 'म्')):
        if word.endswith(suf) and len(word) > len(suf):
            stem = word[:-len(suf)]
            if form(stem, gender, case) == word: return stem, case
    return None

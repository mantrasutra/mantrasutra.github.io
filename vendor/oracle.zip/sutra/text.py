# SPDX-License-Identifier: AGPL-3.0-only
"""L1 text (DESIGN v2 A1): verse -> padas (padaccheda), samāsa members, vibhakti.

Segmentation: the L5 lattice decoder (ped/lattice.py) with SOFT PED (t5_soft/t9b_soft): proposals = the inverse
Pāṇinian sandhi (ped/sandhi.py) ∪ identity; an identity-only junction is penalised by ln((1−ε)/ε), ε = the share of
TRAIN junctions that only identity explains. HARD PED = the PED proposals alone. The lexicon is ATTESTED: the
unsandhied members of the permitted DCS training texts (CC BY 4.0), never a held-out text (BENCHMARK-FREEZE).
Morphology: every DCS reading of an attested form (lemma, case, number, gender), with counts; an ambiguous form keeps
all readings. Samāsa: a member whose readings are compound members (DCS Case=Cpd) joins the next word as a compound.
Relations: AGREEMENT links between adjacent nominals sharing case, number and gender. These are not dependency
arcs: v1 has no syntactic parser, and the output says so."""
import math, collections, glob, os
from .ped import sandhi as m, lattice as L

VIBHAKTI = {'Nom': 'प्रथमा', 'Acc': 'द्वितीया', 'Ins': 'तृतीया', 'Dat': 'चतुर्थी', 'Abl': 'पञ्चमी', 'Gen': 'षष्ठी',
            'Loc': 'सप्तमी', 'Voc': 'सम्बोधनम्', 'Cpd': 'समास-पूर्वपदम्'}   # the traditional names; Cpd = a compound member

def read_morph(files):
    """form (IAST, unsandhied) -> Counter of (lemma, upos, case, number, gender)."""
    out = collections.defaultdict(collections.Counter)
    for f in files:
        for line in open(f, encoding='utf-8'):
            if not line.strip() or line.startswith('#'): continue
            c = line.rstrip('\n').split('\t')
            if len(c) < 10 or not c[0].isdigit(): continue
            misc = dict(kv.split('=', 1) for kv in c[9].split('|') if '=' in kv)
            feats = dict(kv.split('=', 1) for kv in c[5].split('|') if '=' in kv)
            form = misc.get('Unsandhied', c[1])
            out[form][(c[2], c[3], feats.get('Case', ''), feats.get('Number', ''), feats.get('Gender', ''))] += 1
    return out

class TextAnalyser:
    def __init__(self, dcs, train_texts, mode='soft', lexicon_sources=None):
        """train_texts (in dcs): aligned sentences for ε. lexicon_sources: [(dir, [texts])] whose unsandhied members form the
        attested lexicon and the morphology (default: the train texts)."""
        train = L.load_full(dcs, train_texts)
        lexicon_sources = lexicon_sources or [(dcs, train_texts)]
        files = [f for d, ts in lexicon_sources for t in ts for f in sorted(glob.glob(os.path.join(d, t, '*.conllu')))]
        members = []
        for _, us, _ in m.read_sentences(files):
            toks = [m.tok(u) for u in us]
            if toks and all(t_ and m.SP not in t_ and m.AV not in t_ for t_ in toks): members.append((None, [tuple(t_) for t_ in toks], None))
        self.lex = L.Lexicon(members)
        self.morph = read_morph(files)
        self.train_texts, self.lexicon_sources = list(train_texts), [(d, list(ts)) for d, ts in lexicon_sources]
        K = m.Classes(m.GRID, m.SIB); ped = m.ped_proposer(K)
        inv_any = collections.defaultdict(set)
        for (_, r), a in m.build_inverse(K).items(): inv_any[r] |= a
        units = [(s, p, r, A, B) for s, _, us in train for p, r, A, B in us]
        eps = max(sum(1 for s, p, r, A, B in units if (A, B) not in ped(s, p, r) and (A, B) in m.identity_props(r)) / max(len(units), 1), 1e-6)
        self.eps, self.lam, self.mode = eps, math.log((1 - eps) / eps), mode
        if mode == 'soft':
            self.prop = lambda s, p, r: ped(s, p, r) | m.identity_props(r)
            self.wt = lambda r, ab: 0.0 if ab in inv_any.get(r, ()) else -self.lam
        else:
            self.prop, self.wt = ped, None

    def segment(self, text_iast):
        s = m.tok(text_iast)
        if s is None: return None
        seq, _, _ = L.decode(s, self.lex, self.prop, self.wt)
        return [''.join(u) for u in seq] if seq else None

    def analyse(self, text_iast):
        members = self.segment(text_iast)
        if members is None:
            return {'ok': False, 'why': 'no segmentation into attested words was found', 'members': None}
        words = []
        for w in members:
            rd = self.morph.get(w, collections.Counter())
            readings = [{'lemma': k[0], 'upos': k[1], 'case': k[2], 'vibhakti': VIBHAKTI.get(k[2], ''), 'number': k[3], 'gender': k[4], 'count': n}
                        for k, n in rd.most_common()]
            words.append({'form': w, 'readings': readings, 'compound_member': bool(readings) and readings[0]['case'] == 'Cpd'})
        links = []
        for i in range(len(words) - 1):
            a, b = words[i], words[i + 1]
            if a['compound_member']: links.append({'from': i, 'to': i + 1, 'kind': 'samāsa'}); continue
            keys = lambda w: {(r['case'], r['number'], r['gender']) for r in w['readings'] if r['case'] not in ('', 'Cpd')}
            common = keys(a) & keys(b)
            if common: links.append({'from': i, 'to': i + 1, 'kind': 'agreement', 'features': sorted(common)})
        return {'ok': True, 'members': members, 'words': words, 'links': links, 'mode': self.mode,
                'note': 'agreement and samāsa links only; these are not dependency arcs (no syntactic parser in v1)'}


def from_data(path, mode='soft', role='product'):
    """A TextAnalyser rebuilt from the shipped lexicon file (tools/build-lexicon.py): no corpus needed at run time."""
    import gzip
    A = TextAnalyser.__new__(TextAnalyser)
    cnt, morph, eps = collections.Counter(), collections.defaultdict(collections.Counter), None
    with gzip.open(path, 'rt', encoding='utf-8') as f:
        for line in f:
            if line.startswith('#'):
                head = line.rstrip('\n').split('\t')
                got = head[1] if len(head) > 2 else None
                if got != role: raise ValueError(f'{path} is a {got!r} lexicon; this use needs {role!r} (product and evaluation lexicons never mix)')
                eps = float(head[-1]); continue
            form, n, rd = line.rstrip('\n').split('\t')
            t = m.tok(form)
            if not t: continue
            cnt[tuple(t)] = int(n)
            for r in filter(None, rd.split(';')):
                k, c = r.rsplit('=', 1); morph[form][tuple(k.split('|'))] = int(c)
    lex = L.Lexicon.__new__(L.Lexicon)   # L.Lexicon.__init__, from counts instead of sentences
    lex.c = cnt; T, V = sum(cnt.values()), len(cnt)
    lex.lp = {u: math.log((k + 1) / (T + V + 1)) for u, k in cnt.items()}
    lex.first, lex.mid, lex.last = collections.defaultdict(list), collections.defaultdict(list), collections.defaultdict(list)
    lex.maxcore = 0
    for u in cnt:
        Au = m.a_unit(u); core0 = u[:len(u) - len(Au)]
        lex.first[core0].append((u, Au))
        if len(u) - len(Au) >= 1: lex.mid[(u[0], u[1:len(u) - len(Au)])].append((u, Au))
        if len(u) >= 2: lex.last[(u[0], u[1:-1])].append(u)
        lex.maxcore = max(lex.maxcore, len(u))
    A.lex, A.morph, A.eps, A.lam, A.mode = lex, morph, eps, math.log((1 - eps) / eps), mode
    A.train_texts, A.lexicon_sources = [], [('shipped', [path])]
    K = m.Classes(m.GRID, m.SIB); ped = m.ped_proposer(K)
    inv_any = collections.defaultdict(set)
    for (_, r), a in m.build_inverse(K).items(): inv_any[r] |= a
    if mode == 'soft':
        A.prop = lambda s, p, r: ped(s, p, r) | m.identity_props(r)
        A.wt = lambda r, ab: 0.0 if ab in inv_any.get(r, ()) else -A.lam
    else: A.prop, A.wt = ped, None
    return A

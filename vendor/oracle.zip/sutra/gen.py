# SPDX-License-Identifier: AGPL-3.0-only
"""Random terms for the round-trip property tests (DESIGN §2: ≥ 10⁶ random terms). Seeded, so a failure reproduces.

Names are synthetic a-stems (TEST DATA only, never proposed as vocabulary): 1–3 consonants with the inherent अ,
drawn so r/ṣ triggers and blocking consonants both occur (ṇatva coverage). Raw terms include the input-only kinds
(sub, div, neg, sqrt) so प्रकृतिः is exercised; canon() of the raw term is what gets round-tripped.
loops=True also draws round, iter, let and the quot/rem sugar (DESIGN-loops §1.3) and allows all ten bound names; with
loops=False the stream of terms for a seed is exactly what it was before those nodes existed."""
import random
from fractions import Fraction
from .terms import INF
from .surface import HEADS, BOUND, W, INF as INF_WORD

POOL = 'क ग च ज त द न प ब म य र ल व श ष स ह'.split()
TAKEN = {s for s, _, _ in HEADS.values()} | set(BOUND) | {INF_WORD} | {W[r][0] for r in ('ROUND_DOWN', 'UNTIL', 'BUDGET')}

def make_env(rng, n=8):
    env, names = {}, []
    while len(names) < n:
        stem = ''.join(rng.choice(POOL) for _ in range(rng.randint(1, 3)))
        if stem in TAKEN or stem in env: continue
        kind = 'var' if not names else rng.choice(('const', 'var', 'var', 'rate', 'fn'))   # at least one variable
        env[stem] = (kind, rng.randint(1, 2) if kind == 'fn' else 0, 'm' if kind == 'fn' else rng.choice('mn'))
        names.append(stem)
    return env

def rand_term(rng, env, depth=0, bound=0, budget=None, loops=False):
    budget = budget if budget is not None else [rng.randint(3, 40)]
    budget[0] -= 1
    leaf = budget[0] <= 0 or depth > 6
    vars_ = [s for s, (k, *_) in env.items() if k != 'fn']
    fns = [s for s, (k, *_) in env.items() if k == 'fn']
    if leaf:
        r = rng.random()
        if r < 0.3: return ('num', Fraction(rng.randint(-20, 20), rng.choice((1, 1, 1, 2, 3, 7))))
        if r < 0.4 and bound: return ('bvar', rng.randrange(bound))
        if r < 0.43: return INF
        s = rng.choice(vars_); return ('name', s, env[s][0])
    sub = lambda: rand_term(rng, env, depth + 1, bound, budget, loops)
    under = lambda k: rand_term(rng, env, depth + 1, bound + k, budget, loops)
    room = len(BOUND) if loops else 4
    if loops and rng.random() < 0.3:
        r = rng.random()
        if r < 0.35:
            unit = sub() if rng.random() < 0.3 else ('num', Fraction(rng.randint(1, 9), rng.choice((1, 2, 60))))
            return ('round', sub(), unit, rng.choice(('near', 'down')))
        if r < 0.5: return (rng.choice(('quot', 'rem')), sub(), sub())
        if r < 0.7 and bound < room: return ('let', sub(), under(1))
        k = rng.randint(1, 3)
        if bound + k + 1 <= room:
            return ('iter', tuple(sub() for _ in range(k)), tuple(under(k + 1) for _ in range(k)),
                    ('rel', rng.choice(('lt', 'le', 'eq', 'ne')), under(k + 1), under(k + 1)), under(k + 1),
                    rng.choice((1, 7, 1000, 10 ** 6)))
    r = rng.random()
    if r < 0.18: return ('sum', tuple(sub() for _ in range(rng.randint(2, 4))))
    if r < 0.36: return ('prod', tuple(sub() for _ in range(rng.randint(2, 4))))
    if r < 0.48: return ('pow', sub(), sub())
    if r < 0.56: return (rng.choice(('sub', 'div')), sub(), sub())
    if r < 0.60: return (rng.choice(('neg', 'sqrt')), sub())
    if r < 0.72 and fns:
        f = rng.choice(fns); return ('app', f, tuple(sub() for _ in range(env[f][1])))
    if r < 0.77:
        v = rng.choice([s for s, (k, *_) in env.items() if k == 'var'] or vars_)
        return ('deriv', sub(), ('name', v, env[v][0]))
    if r < 0.86 and bound < room:
        lo, hi = sub(), sub()
        return ('bind', rng.choice(('Σ', 'Π', '∫')), lo, hi, under(1), None)
    if r < 0.91 and bound < room:
        pt = sub(); return ('lim', pt, rng.choice(('both', 'left', 'right')), under(1))
    if r < 0.96:
        n = rng.randint(1, 2)
        br = tuple((('rel', rng.choice(('lt', 'le', 'eq', 'ne')), sub(), sub()), sub()) for _ in range(n))
        return ('piece', br, sub())
    return sub()

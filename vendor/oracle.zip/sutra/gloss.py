# SPDX-License-Identifier: AGPL-3.0-only
"""Glosses (DESIGN §9b): rule-based, reproducible, each phrase traceable to one node of the canonical term.
Registers: English, and Sanskrit (case roles spelled out; the Sanskrit templates are a DRAFT for d8 review, E1 item 5).
The role -> operation map is DESIGN's: genitive + instrumental -> "raised to the power"; locative -> "of"; dvandva ->
"the sum/product of"; ablative -> "with respect to" (derivative variable), "from" (lower bound)."""
from fractions import Fraction
from .surface import W
from .endings import form

FN_EN = {'EXP': 'the exponential', 'LOG': 'the natural logarithm', 'SIN': 'the sine', 'COS': 'the cosine', 'TAN': 'the tangent',
         'ASIN': 'the arcsine', 'ACOS': 'the arccosine', 'ATAN': 'the arctangent', 'SINH': 'the hyperbolic sine',
         'COSH': 'the hyperbolic cosine', 'TANH': 'the hyperbolic tangent', 'RE': 'the real part', 'IM': 'the imaginary part',
         'CONJ': 'the complex conjugate', 'ABS': 'the absolute value', 'ARG': 'the argument', 'GAMMA': 'the gamma function',
         'ZETA': 'the Riemann zeta function', 'HURWITZ_ZETA': 'the Hurwitz zeta function', 'DIRICHLET_ETA': 'the Dirichlet eta function',
         'POLYLOG': 'the polylogarithm', 'LAMBERT_W0': 'the principal branch W₀ of the Lambert W function',
         'LAMBERT_WM1': 'the branch W₋₁ of the Lambert W function', 'BESSEL_J': 'the Bessel function J', 'BESSEL_Y': 'the Bessel function Y',
         'BESSEL_I': 'the modified Bessel function I', 'BESSEL_K': 'the modified Bessel function K', 'VON_MANGOLDT': 'the von Mangoldt function Λ',
         'DIRICHLET_LAMBDA': 'the Dirichlet lambda function', 'CARMICHAEL_LAMBDA': 'the Carmichael function λ', 'HARDY_Z': 'the Hardy Z function'}
CONST_EN = {'PI': 'π', 'E_CONST': 'e', 'IMAG_UNIT': 'the imaginary unit i', 'INF': 'infinity'}
ROLE = {W[k][0]: k for k in W}
METHOD_EN = {'रामानुज': 'Ramanujan'}   # summation methods (DESIGN §0); more as they are ruled

def num_en(q):
    q = Fraction(q)
    s = str(abs(q.numerator)) if q.denominator == 1 else f'{abs(q.numerator)}/{q.denominator}'
    return ('minus ' if q < 0 else '') + s

def english(t, label=lambda stem: stem, bound=()):
    """label: stem -> how the name is read (glossary gloss or the editor's identifier)."""
    E = lambda x: english(x, label, bound); k = t[0]
    if k == 'num': return num_en(t[1])
    if k == 'name': return CONST_EN.get(ROLE.get(t[1]), label(t[1]))
    if k == 'bvar': return bound[len(bound) - 1 - t[1]]
    if k == 'label': return t[1]
    if k == 'sum': return 'the sum of ' + _list([E(c) for c in t[1]])
    if k == 'prod':
        if len(t[1]) == 2 and t[1][1][0] == 'pow' and t[1][1][2] == ('num', Fraction(-1)):
            return f'{E(t[1][0])} divided by {E(t[1][1][1])}'
        if t[1][0] == ('num', Fraction(-1)):
            rest = t[1][1:]; return 'minus ' + (E(rest[0]) if len(rest) == 1 else 'the product of ' + _list([E(c) for c in rest]))
        return 'the product of ' + _list([E(c) for c in t[1]])
    if k == 'pow':
        if t[2] == ('num', Fraction(-1)): return f'the reciprocal of {E(t[1])}'
        if t[2] == ('num', Fraction(1, 2)): return f'the square root of {E(t[1])}'
        if t[2] == ('num', Fraction(2)): return f'the square of {E(t[1])}'
        if t[2] == ('num', Fraction(3)): return f'the cube of {E(t[1])}'
        if t[2][0] == 'num' and t[2][1].denominator == 1 and t[2][1] > 3: return f'the {ordinal(int(t[2][1]))} power of {E(t[1])}'
        return f'the power, with exponent {E(t[2])}, of {E(t[1])}'   # d8: never "X raised to the power Y", which is ambiguous
    if k == 'app':
        r = ROLE.get(t[1]); name = FN_EN.get(r, label(t[1]))
        if r in ('BESSEL_J', 'BESSEL_Y', 'BESSEL_I', 'BESSEL_K'): return f'{name} of order {E(t[2][0])} at {E(t[2][1])}'
        if r == 'POLYLOG': return f'{name} of order {E(t[2][0])} at {E(t[2][1])}'
        if r == 'HURWITZ_ZETA': return f'{name} at s = {E(t[2][0])}, a = {E(t[2][1])}'
        return f'{name} of ' + _list([E(a) for a in t[2]])
    if k == 'deriv': return f'the derivative of {E(t[1])} with respect to {E(t[2])}'
    if k == 'bind':
        v = ('xtu' if t[1] == '∫' else 'kjmnpq')[len(bound) % 3]; body = english(t[4], label, bound + (v,))
        what = {'Σ': 'the sum', 'Π': 'the product', '∫': 'the integral'}[t[1]]
        how = f' (by {METHOD_EN.get(t[5], t[5])} summation, not by convergence)' if t[5] else ''
        return f'{what} over {v} from {E(t[2])} to {E(t[3])} of {body}{how}'
    if k == 'lim':
        v = 'xyz'[len(bound) % 3]; side = {'both': '', 'left': ' from below', 'right': ' from above'}[t[2]]
        return f'the limit as {v} tends to {E(t[1])}{side} of {english(t[3], label, bound + (v,))}'
    if k == 'piece':
        rel = {'lt': 'is less than', 'le': 'is at most', 'eq': 'equals', 'ne': 'differs from'}
        parts = [f'{E(v)} where {E(c[2])} {rel[c[1]]} {E(c[3])}' for c, v in t[1]]
        return '; '.join(parts) + f'; otherwise {E(t[2])}'
    if k == 'round':
        x, u = E(t[1]), E(t[2])
        if t[3] == 'down': return f'the floor of {x}' if t[2] == ('num', Fraction(1)) else f'{x} rounded down to a multiple of {u}'
        return f'{x} rounded to the nearest multiple of {u} (a tie away from zero)'
    if k == 'let':
        v = _let_name(len(bound)); return f'{english(t[2], label, bound + (v,))}, where {v} is {E(t[1])}'
    if k == 'iter':
        n = len(t[1]); names = _iter_names(bound, n); inner = bound + names
        I = lambda x: english(x, label, inner)
        rel = {'lt': 'is less than', 'le': 'is at most', 'eq': 'equals', 'ne': 'differs from'}
        start = _list([f'{names[j + 1]} = {E(t[1][j])}' for j in range(n)])
        step = _list([f'{names[j + 1]} becomes {I(t[2][j])}' for j in range(n)])
        return (f'starting from {start}, with the counter {names[0]} = 0, repeat: {step} (all at once), and {names[0]} '
                f'increases by 1, until {I(t[3][2])} {rel[t[3][1]]} {I(t[3][3])}; then the result is {I(t[4])} '
                f'(at most {t[5]} steps, else refuse)')
    raise ValueError(k)

def _let_name(i): return 'vwh'[i % 3]

def _iter_names(bound, n):
    """The counter i and the state a, b, c, …; each enclosing iter adds a prime."""
    p = '′' * sum(1 for b in bound if b and b[0] == 'i')
    return ('i' + p,) + tuple('abcdefgh'[j] + p for j in range(n))

def ordinal(n):
    words = {4: 'fourth', 5: 'fifth', 6: 'sixth', 7: 'seventh', 8: 'eighth', 9: 'ninth', 10: 'tenth', 11: 'eleventh', 12: 'twelfth'}
    if n in words: return words[n]
    return f'{n}' + ('th' if 10 <= n % 100 <= 20 else {1: 'st', 2: 'nd', 3: 'rd'}.get(n % 10, 'th'))

def _list(xs): return xs[0] if len(xs) == 1 else ', '.join(xs[:-1]) + ' and ' + xs[-1]

# ---- Sanskrit: vṛtti-style templates from agent-handovers/sutra-reviews/sanskrit-gloss.md (d8, 2026-10-09) ----
ITI = {'gen': 'इत्यस्य', 'ins': 'इत्यनेन', 'abl': 'इत्यस्मात्', 'loc': 'इत्यत्र'}
REL_SA = {'lt': 'न्यूनम्', 'le': 'नाधिकम्', 'eq': 'समम्', 'ne': 'भिन्नम्'}

def sanskrit(t, env, bound=()):
    from .surface import gender, deva
    S = lambda x: sanskrit(x, env, bound); k = t[0]
    def case(x, c):   # a bare name takes its own inflected form; anything else (numerals included) the iti-phrase
        if x[0] == 'name': return form(x[1], gender(x[1], env), c)
        if x[0] == 'bvar': return form(W[f'BOUND{len(bound) - 1 - x[1]}'][0], 'm', c)
        if x[0] == 'label': return form(x[1], 'm', c)
        return f'({S(x)}) {ITI[c]}'
    item = lambda x: S(x) if x[0] in ('num', 'name', 'bvar', 'label') else f'({S(x)})'
    def apeksha(x):   # "with respect to x": a bare a-stem name compounds (savarṇa-dīrgha: काल + अपेक्षया = कालापेक्षया)
        if x[0] == 'name': return x[1] + 'ापेक्षया'
        if x[0] == 'bvar': return W[f'BOUND{len(bound) - 1 - x[1]}'][0] + 'ापेक्षया'
        return f'({S(x)}) इत्यपेक्षया'
    if k == 'num':
        q = t[1]; v = deva(abs(q.numerator)) + ('' if q.denominator == 1 else '⁄' + deva(q.denominator))
        return (W['NEG'][0] + ' ' + v) if q < 0 else v
    if k == 'name': return form(t[1], gender(t[1], env), 'nom')
    if k == 'bvar': return form(W[f'BOUND{len(bound) - 1 - t[1]}'][0], 'm', 'nom')
    if k == 'label': return form(t[1], 'm', 'nom')
    if k in ('sum', 'prod'):
        ops = t[1]
        if k == 'prod' and ops[0] == ('num', Fraction(-1)):
            rest = ops[1:]; inner = rest[0] if len(rest) == 1 else ('prod', rest)
            return f'{case(inner, "gen")} {W["NEG"][0]}'
        head = form(W['SUM'][0], 'n', 'nom') if k == 'sum' else form(W['PROD'][0], 'm', 'nom')
        return ', '.join(item(c) for c in ops) + f' च — एषां {head}'
    if k == 'pow':
        if t[2] == ('num', Fraction(-1)): return f'{case(t[1], "gen")} व्युत्क्रमः'
        if t[2] == ('num', Fraction(1, 2)): return f'{case(t[1], "gen")} वर्गमूलम्'
        return f'{case(t[1], "gen")} {case(t[2], "ins")} {form(W["POW"][0], "m", "ins")} {form(W["PROD"][0], "m", "nom")}'
    if k == 'app':
        if len(t[2]) == 1 and t[2][0][0] in ('name', 'bvar', 'label'): return f'{case(t[2][0], "loc")} {t[1]}मानम्'
        return f'({", ".join(S(a) for a in t[2])}) इत्यत्र {t[1]}मानम्'
    if k == 'deriv': return f'{case(t[1], "gen")} {apeksha(t[2])} {form(W["DERIV"][0], "n", "nom")}'
    if k == 'bind':
        v = form(W[f'BOUND{len(bound)}'][0], 'm', 'nom'); body = sanskrit(t[4], env, bound + (None,))
        upto = 'अनन्तपर्यन्तम्' if t[3] == ('name', W['INF'][0], 'const') else (f'{S(t[3])} इति पर्यन्तम्' if t[3][0] in ('num', 'name', 'bvar', 'label') else f'({S(t[3])}) इति पर्यन्तम्')
        method = f' {t[5]}विधिना' if t[5] else ''
        tail = ', न तु अभिसरणेन' if t[5] else ''
        if t[1] == '∫': return f'{W[f"BOUND{len(bound)}"][0]}ापेक्षया {_iti_from(t[2], S)} {upto} ({body}) इत्यस्य{method} {form(W["INT"][0], "n", "nom")}{tail}'
        head = form(W['SUM'][0], 'n', 'nom') if t[1] == 'Σ' else form(W['PROD'][0], 'm', 'nom')
        if t[4][0] in ('name', 'bvar', 'label'):   # a bare body: its own genitive plural (d8): ढढकानाम् सङ्कलनम्
            from .endings import gen_plural
            stem = t[4][1] if t[4][0] in ('name', 'label') else W[f'BOUND{len(bound) - t[4][1]}'][0]
            return f'{v} इति {_iti_from(t[2], S)} {upto} {gen_plural(stem)}{method} {head}{tail}'
        return f'{v} इति {_iti_from(t[2], S)} {upto} ({body}) इत्येषां{method} {head}{tail}'
    if k == 'lim':
        v = form(W[f'BOUND{len(bound)}'][0], 'm', 'gen'); body = sanskrit(t[3], env, bound + (None,))
        side = {'both': '', 'left': ' अधस्तात्', 'right': ' उपरिष्टात्'}[t[2]]
        return f'{v} ({S(t[1])}) इत्येतत् प्रति{side} गमने ({body}) इत्यस्य {form(W["LIM"][0], "m", "nom")}'
    if k == 'piece':
        parts = [f'यदि ({S(c[2])}) इति ({S(c[3])}) इत्यनेन {REL_SA[c[1]]} तर्हि {item(v)}' for c, v in t[1]]
        return '; '.join(parts) + f'; अन्यथा {item(t[2])}'
    if k == 'round':   # DRAFT for d8: x gen, unit ins, the mode word, the head; near adds the gloss word स्थूल
        mode = form(W['ROUND_DOWN'][0], 'n', 'nom') if t[3] == 'down' else form(W['ROUND_GLOSS'][0], 'n', 'nom')
        return f'{case(t[1], "gen")} {case(t[2], "ins")} {mode} {form(W["ROUND"][0], "n", "nom")}'
    if k == 'let':
        v = form(W[f'BOUND{len(bound)}'][0], 'm', 'nom')
        return f'{v} इति ({S(t[1])}) {form(W["LET"][0], "n", "nom")}; ({sanskrit(t[2], env, bound + (None,))})'
    if k == 'iter':
        n = len(t[1]); inner = bound + (None,) * (n + 1)
        I = lambda x: sanskrit(x, env, inner)
        bw = lambda j: form(W[f'BOUND{len(bound) + j}'][0], 'm', 'nom')
        start = ', '.join(f'{bw(j + 1)} ({S(t[1][j])}) इत्यारभ्य' for j in range(n))
        step = ', '.join(f'{bw(j + 1)} ({I(t[2][j])}) इति' for j in range(n))
        return (f'{bw(0)} शून्यात्, {start}; {W["ITER_GLOSS"][0]} {step}; ({I(t[3][2])}) इति ({I(t[3][3])}) इत्यनेन '
                f'{REL_SA[t[3][1]]} {form(W["UNTIL"][0], "n", "loc")} ({I(t[4])}) — {form(W["ITER"][0], "n", "nom")} {W["BUDGET"][0]} {deva(t[5])}')
    raise ValueError(k)

def _iti_from(x, S):   # "beginning from x": ārabhya with the iti device; a bare word needs no parentheses
    return f'{S(x)} इत्यारभ्य' if x[0] in ('num', 'name', 'bvar', 'label') else f'({S(x)}) इत्यारभ्य'

def sanskrit_stmt(st, env, time_stem=None):
    """law: (lhs) इति (rhs) इत्यनेन समम्; rate dx/dt = f: (x) इत्यस्य (t) इत्यपेक्षया परिणामः (f) इत्यनेन समः."""
    from .surface import gender
    used = _names(st)
    labels = iter(l for l in YATRA_SA if l not in used)
    defs = []
    parts = [cut(x, labels, defs) if isinstance(x, tuple) else x for x in st[1:]]
    G = lambda x, path=(): sanskrit(x, env, (None,) * len(path))
    iti = lambda x: f'{G(x)} इति' if x[0] in ('num', 'name', 'bvar', 'label') else f'({G(x)}) इति'
    ins = lambda x: f'{G(x)} इत्यनेन' if x[0] in ('num', 'label') else (form(x[1], gender(x[1], env), 'ins') if x[0] == 'name' else f'({G(x)}) इत्यनेन')
    if st[0] == 'law': out = f'{iti(parts[0])} {ins(parts[1])} समम्'
    elif st[0] == 'def': out = f'{form(st[1], gender(st[1], env), "nom")} {ins(parts[1])} समः'
    elif st[0] == 'rate':
        t = time_stem or 'काल'
        out = f'{form(st[1], gender(st[1], env), "gen")} {t}ापेक्षया परिणामः {ins(parts[1])} समः'
    else: raise ValueError(st[0])
    return out + _yatra(defs, G, 'यत्र')

# ---- depth (re-review 3): clauses nest at most YATRA_DEPTH composite levels; deeper subterms become labels ----
YATRA_DEPTH = 3
YATRA_SA = list('कखगघचछजझटठडढतथदधपफबभमयरलवशसह')
YATRA_EN = list('ABCDEFGHJKLMNPQRSTUVWXYZ')
ATOMIC = ('num', 'name', 'bvar', 'label')

def cut(t, labels, defs, d=0, path=()):
    """path: the binder kinds enclosing t ('Σ','Π','∫','lim'); an extracted definition keeps it, so its bound
    variables are glossed with the names they have in place."""
    if t[0] in ATOMIC: return t
    if d >= YATRA_DEPTH:
        lab = next(labels); body = cut(t, labels, defs, 1, path); defs.append((lab, body, path)); return ('label', lab)
    C = lambda x, p=path: cut(x, labels, defs, d + 1, p)
    k = t[0]
    if k in ('sum', 'prod'): return (k, tuple(C(c) for c in t[1]))
    if k == 'pow': return ('pow', C(t[1]), C(t[2]))
    if k == 'app': return ('app', t[1], tuple(C(c) for c in t[2]))
    if k == 'deriv': return ('deriv', C(t[1]), t[2])
    if k == 'bind': return ('bind', t[1], C(t[2]), C(t[3]), C(t[4], path + (t[1],)), t[5])
    if k == 'lim': return ('lim', C(t[1]), t[2], C(t[3], path + ('lim',)))
    if k == 'piece': return ('piece', tuple((('rel', c[1], C(c[2]), C(c[3])), C(v)) for c, v in t[1]), C(t[2]))
    if k == 'round': return ('round', C(t[1]), C(t[2]), t[3])
    if k == 'let': return ('let', C(t[1]), C(t[2], path + ('let',)))
    if k == 'iter':
        ip = path + ('iter',) + ('state',) * len(t[1])
        return ('iter', tuple(C(c) for c in t[1]), tuple(C(c, ip) for c in t[2]), ('rel', t[3][1], C(t[3][2], ip), C(t[3][3], ip)), C(t[4], ip), t[5])
    raise ValueError(k)

def en_bound(path):   # the English bound names, chosen exactly as english() chooses them by depth and binder kind
    out = []
    for i, op in enumerate(path):
        if op == 'let': out.append(_let_name(i))
        elif op == 'iter': out.append(_iter_names(tuple(out), 0)[0])
        elif op == 'state':   # the j-th state component of the nearest iter before it
            q = max(q for q in range(i) if path[q] == 'iter'); j = i - q
            out.append(_iter_names(tuple(out[:q]), j)[j])
        else: out.append(('xtu' if op == '∫' else 'xyz' if op == 'lim' else 'kjmnpq')[i % 3])
    return tuple(out)

def _yatra(defs, G, word):
    if not defs: return ''
    return f', {word} ' + ', '.join(f'{lab} = ({G(body, path)})' for lab, body, path in sorted(defs, key=lambda d: d[0]))

def _names(st):
    from .terms import children
    out = set()
    def walk(t):
        if t[0] == 'name': out.add(t[1])
        for c in children(t): walk(c)
    for x in st[1:]:
        if isinstance(x, tuple): walk(x)
        elif isinstance(x, str): out.add(x)
    return out

def english_stmt(st, label=lambda s: s):
    used = {label(n) for n in _names(st)}
    labels = iter(l for l in YATRA_EN if l not in used)
    defs = []
    parts = [cut(x, labels, defs) if isinstance(x, tuple) else x for x in st[1:]]
    E = lambda x, path=(): english(x, label, en_bound(path))
    if st[0] == 'law': out = f'{E(parts[0])} equals {E(parts[1])}'
    elif st[0] == 'def': out = f'{label(st[1])} is defined as {E(parts[1])}'
    elif st[0] == 'rate': out = f'the rate of change of {label(st[1])} with respect to time equals {E(parts[1])}'
    else: raise ValueError(st[0])
    return out + _yatra(defs, E, 'where').replace(' = (', ' is ').replace('), ', '; ').rstrip(')')

# SPDX-License-Identifier: AGPL-3.0-only
# Ported unchanged in behaviour from agent-handovers/ped-l3/l5_segment.py (the L5 lattice decoder; registered results
# were produced by that file). Only the import of the sandhi module and the CLI entry point differ, and (2026-10-10,
# review A.1) the line-final word: its last unit must match the line's last unit in a pausa form (sandhi.pausa).
import json, sys, math, random, collections, glob, os, time
from . import sandhi as m

MAXL = 6


def load_full(dcs, texts):
    files = []
    for t in texts:
        files += sorted(glob.glob(os.path.join(dcs, t, "*.conllu")))
    out = []
    for text, members, groups in m.read_sentences(files):
        s = m.tok(text); us = [m.tok(x) for x in members]
        if s is None or any(u is None or not u or m.SP in u or m.AV in u for u in us) or len(us) < 2:
            continue
        units = m.align(s, us, groups)
        if units is None:
            continue
        out.append((s, [tuple(u) for u in us], units))
    return out


class Lexicon:
    def __init__(self, sents):
        self.c = collections.Counter(u for _, us, _ in sents for u in us)
        T, V = sum(self.c.values()), len(self.c)
        self.lp = {u: math.log((n + 1) / (T + V + 1)) for u, n in self.c.items()}
        self.first, self.mid, self.last = collections.defaultdict(list), collections.defaultdict(list), collections.defaultdict(list)
        self.maxcore = 0
        for u in self.c:
            A = m.a_unit(u)
            core0 = u[:len(u) - len(A)]
            self.first[core0].append((u, A))
            if len(u) - len(A) >= 1:
                self.mid[(u[0], u[1:len(u) - len(A)])].append((u, A))
            if len(u) >= 2:
                self.last[(u[0], u[1:-1])].append(u)
            self.maxcore = max(self.maxcore, len(u))


def decode(s, lex, prop, wt=None):
    """-> (best member sequence or None, junction_edges, word_edges)."""
    n = len(s)
    best = {}                                   # (q, A) -> (score, back, word)
    jedges = wedges = 0
    for l in range(0, min(lex.maxcore, n) + 1):
        if m.SP in s[:l]:
            break
        for u, A in lex.first.get(tuple(s[:l]), ()):
            sc = lex.lp[u]; key = (l, A); wedges += 1
            if key not in best or sc > best[key][0]:
                best[key] = (sc, None, u)
    final = None
    for q in range(n):
        states = [(k, v) for k, v in best.items() if k[0] == q]
        for (q_, Aprev), (sc, _, _) in states:
            for L in range(1, MAXL + 1):
                if q + L > n:
                    break
                r = tuple(s[q:q + L])
                if r[0] in (m.SP, m.AV) or r[-1] == m.SP:
                    continue
                for (A2, B) in prop(s, q, r):
                    if A2 != Aprev:
                        continue
                    jedges += 1
                    jw = wt(r, (A2, B)) if wt else 0.0
                    st = q + L
                    for l in range(0, min(lex.maxcore, n - st) + 1):
                        core = tuple(s[st:st + l])
                        if m.SP in core:
                            break
                        for u, A in lex.mid.get((B, core), ()):
                            wedges += 1
                            key = (st + l, A); nsc = sc + jw + lex.lp[u]
                            if key not in best or nsc > best[key][0]:
                                best[key] = (nsc, (q, Aprev), u)
                    end = n - 1   # avasāna: the line's last unit is the pausa form of the word's last unit (review A.1;
                    if end >= st and s[end] != m.SP:   # was: any 0-2 trailing units, so 'sma' could decode as 'sa')
                        for u in lex.last.get((B, tuple(s[st:end])), ()):
                            if s[end] not in m.pausa(u[-1]):
                                continue
                            wedges += 1
                            nsc = sc + jw + lex.lp[u]
                            if final is None or nsc > final[0]:
                                final = (nsc, (q, Aprev), u)
    if final is None:
        return None, jedges, wedges
    seq, back = [final[2]], final[1]
    while back is not None:
        sc, nb, u = best[back]
        seq.append(u); back = nb
    return list(reversed(seq)), jedges, wedges



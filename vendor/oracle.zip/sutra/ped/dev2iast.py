# SPDX-License-Identifier: AGPL-3.0-only
# Copied unchanged from agent-handovers/ped-l3/dev2iast.py (used by the registered T9 UD run).
"""Devanagari -> IAST (for Sanskrit text; used for UD-UFAL, Wikisource and Itihāsa inputs)."""
import unicodedata

V = {"अ": "a", "आ": "ā", "इ": "i", "ई": "ī", "उ": "u", "ऊ": "ū", "ऋ": "ṛ", "ॠ": "ṝ", "ऌ": "ḷ", "ए": "e",
     "ऐ": "ai", "ओ": "o", "औ": "au"}
M = {"ा": "ā", "ि": "i", "ी": "ī", "ु": "u", "ू": "ū", "ृ": "ṛ", "ॄ": "ṝ", "ॢ": "ḷ", "े": "e", "ै": "ai",
     "ो": "o", "ौ": "au"}
C = {"क": "k", "ख": "kh", "ग": "g", "घ": "gh", "ङ": "ṅ", "च": "c", "छ": "ch", "ज": "j", "झ": "jh", "ञ": "ñ",
     "ट": "ṭ", "ठ": "ṭh", "ड": "ḍ", "ढ": "ḍh", "ण": "ṇ", "त": "t", "थ": "th", "द": "d", "ध": "dh", "न": "n",
     "प": "p", "फ": "ph", "ब": "b", "भ": "bh", "म": "m", "य": "y", "र": "r", "ल": "l", "ळ": "ḷ", "व": "v",
     "श": "ś", "ष": "ṣ", "स": "s", "ह": "h"}
X = {"ं": "ṃ", "ः": "ḥ", "ँ": "ṃ", "ऽ": "'", "।": "", "॥": "", "॰": ""}
VIRAMA, NUKTA = "्", "़"
DIG = {chr(0x966 + i): "" for i in range(10)}


def dev2iast(s):
    s = unicodedata.normalize("NFC", s).replace(NUKTA, "")
    out, i = [], 0
    while i < len(s):
        ch = s[i]
        if ch in C:
            out.append(C[ch])
            nxt = s[i + 1] if i + 1 < len(s) else ""
            if nxt == VIRAMA:
                i += 2; continue
            if nxt in M:
                out.append(M[nxt]); i += 2; continue
            out.append("a"); i += 1; continue
        if ch in V: out.append(V[ch])
        elif ch in X: out.append(X[ch])
        elif ch in DIG: pass
        elif ch.isspace(): out.append(" ")
        elif ch in M or ch == VIRAMA: pass
        else: out.append(ch if ch.isascii() and ch.isalpha() is False and ch not in "|" else "")
        i += 1
    return " ".join("".join(out).split())


if __name__ == "__main__":
    for t in ["पञ्चतन्त्रम् कथामुखम्", "ओं नमः श्रीशारदागणपतिगुरुभ्यः।", "रामोऽपि", "धर्मक्षेत्रे कुरुक्षेत्रे"]:
        print(t, "->", dev2iast(t))

# SPDX-License-Identifier: AGPL-3.0-only
# Ported unchanged in behaviour from agent-handovers/ped-l3/l3_padaccheda.py (the ±PED research harness, this project);
# the registered L3/L5 results were produced by that file. Only the module header and the CLI entry point differ.
import json, os, random, sys, unicodedata, glob, collections

# ---------- phonemes (IAST) ----------
VOW = ["a", "ā", "i", "ī", "u", "ū", "ṛ", "ṝ", "ḷ", "e", "ai", "o", "au"]
SHORT = {"a", "i", "u", "ṛ", "ḷ"}
LONG = {"a": "ā", "ā": "ā", "i": "ī", "ī": "ī", "u": "ū", "ū": "ū", "ṛ": "ṝ", "ṝ": "ṝ"}
SAVARNA = {"a": "a", "ā": "a", "i": "i", "ī": "i", "u": "u", "ū": "u", "ṛ": "ṛ", "ṝ": "ṛ"}
GRID = [["k", "kh", "g", "gh", "ṅ"], ["c", "ch", "j", "jh", "ñ"], ["ṭ", "ṭh", "ḍ", "ḍh", "ṇ"],
        ["t", "th", "d", "dh", "n"], ["p", "ph", "b", "bh", "m"]]
SIB = ["ś", "ṣ", "s"]            # palatal, retroflex, dental
SEMI = ["y", "r", "l", "v"]
ALLC = [p for r in GRID for p in r] + SIB + SEMI + ["h"]
PHON = sorted(set(VOW) | set(ALLC) | {"ṃ", "ḥ"}, key=len, reverse=True)
SP, AV = "_", "'"


def tok(s):
    """IAST string -> phoneme list ('_' space, "'" avagraha) or None if an unknown char occurs."""
    s = unicodedata.normalize("NFC", s).lower().replace("ṁ", "ṃ").replace("r̥", "ṛ").replace("l̥", "ḷ")
    out, i = [], 0
    while i < len(s):
        ch = s[i]
        if ch.isspace():
            if out and out[-1] != SP:
                out.append(SP)
            i += 1; continue
        if ch in "'’":
            out.append(AV); i += 1; continue
        if ch in "-":
            i += 1; continue
        for p in PHON:
            if s.startswith(p, i):
                out.append(p); i += len(p); break
        else:
            return None
    while out and out[-1] == SP:
        out.pop()
    return out


# ---------- the Pāṇinian external-sandhi function (forward) ----------
class Classes:
    def __init__(self, grid, sib):
        self.g, self.sib = grid, sib
        self.pos = {x: (r, c) for r, row in enumerate(grid) for c, x in enumerate(row)}

    def at(self, r, c):
        return self.g[r][c]


def out(L, R):
    return {tuple(L) + tuple(R), tuple(L) + (SP,) + tuple(R)}


def fwd(A, B, ctx, K):
    """A: tuple (1 phoneme, or vowel+ḥ / vowel+r); B: initial phoneme; ctx: class of the phoneme before A
    ('short', 'sib', 'other'). Returns the set of surface realizations (tuples) the rules allow."""
    res = set()
    a = A[-1]
    Bpos = K.pos.get(B)
    Bvow = B in VOW
    Bvoiced_cons = (Bpos is not None and Bpos[1] in (2, 3, 4)) or B in ("y", "r", "l", "v", "h")
    PAL, RET, DEN = 1, 2, 3
    if len(A) == 2:                                  # visarga or r final, with its vowel
        V, fin = A
        if fin == "s":
            fin = "ḥ"                                 # 8.2.66 sasajuṣo ruḥ (then 8.3.15)
        if Bvow or Bvoiced_cons:
            if fin == "r" or V not in ("a", "ā"):
                if B == "r" and V in ("a", "i", "u"):
                    res |= out([LONG[V]], ["r"])      # 8.3.14 + 6.3.111 (dhralope pūrvasya dīrgho 'ṇaḥ)
                else:
                    res |= out([V, "r"], [B])         # 8.3.15/17: r before voiced
            elif V == "a":
                if B == "a":
                    res |= out(["o"], [AV])           # 6.1.113 + 6.1.109
                elif Bvow:
                    res |= out(["a"], [B])            # 8.3.17 + 8.3.19 hiatus
                else:
                    res |= out(["o"], [B])            # 6.1.114
            else:                                     # āḥ
                res |= out(["ā"], [B])
        else:                                         # voiceless consonant
            if Bpos is not None and Bpos[0] == PAL and Bpos[1] in (0, 1):
                res |= out([V, K.sib[0]], [B])        # 8.3.34 + 8.4.40
            elif Bpos is not None and Bpos[0] == RET and Bpos[1] in (0, 1):
                res |= out([V, K.sib[1]], [B])        # 8.3.34 + 8.4.41
            elif Bpos is not None and Bpos[0] == DEN and Bpos[1] in (0, 1):
                res |= out([V, K.sib[2]], [B])        # 8.3.34
            elif B in K.sib:
                res |= out([V, "ḥ"], [B]) | out([V, B], [B])   # 8.3.36 option
            else:
                res |= out([V, "ḥ"], [B])             # 8.3.15/37
        if V == "a" and ctx == "sib" and not Bvow and fin == "ḥ":
            res |= out(["a"], [B])                    # 6.1.132 sa / eṣa
        return res
    if a in VOW:
        if Bvow:
            if SAVARNA.get(a) is not None and SAVARNA.get(a) == SAVARNA.get(B):
                res |= out([LONG[a]], [])             # 6.1.101
            elif a in ("a", "ā"):
                if B in ("i", "ī"): res |= out(["e"], [])          # 6.1.87
                elif B in ("u", "ū"): res |= out(["o"], [])
                elif B in ("ṛ", "ṝ"): res |= out(["a", "r"], [])
                elif B == "ḷ": res |= out(["a", "l"], [])
                elif B in ("e", "ai"): res |= out(["ai"], [])      # 6.1.88
                elif B in ("o", "au"): res |= out(["au"], [])
            elif a in ("i", "ī"): res |= out(["y"], [B])           # 6.1.77
            elif a in ("u", "ū"): res |= out(["v"], [B])
            elif a in ("ṛ", "ṝ"): res |= out(["r"], [B])
            elif a == "e":
                res |= out(["e"], [AV]) if B == "a" else (out(["a"], [B]) | out(["a", "y"], [B]))  # 6.1.109, 6.1.78, 8.3.19
            elif a == "o":
                res |= out(["o"], [AV]) if B == "a" else (out(["a"], [B]) | out(["a", "v"], [B]))
            elif a == "ai":
                res |= out(["ā"], [B]) | out(["ā", "y"], [B])
            elif a == "au":
                res |= out(["ā", "v"], [B]) | out(["ā"], [B])
            if a in ("ī", "ū", "e"):
                res |= out([a], [B])                  # 1.1.11 pragṛhya
        else:
            res |= out([a], [B])
            if Bpos == K.pos.get(K.at(1, 1)):         # B is the palatal voiceless aspirate (ch)
                res |= out([a], [K.at(1, 0), B])      # 6.1.73 / 6.1.75-76
        return res
    Apos = K.pos.get(a)
    rows = None
    if Apos is not None and Apos[1] in (0, 2):        # final non-nasal, unaspirated stop
        rows = {Apos[0]}
    if Apos is not None and Apos[0] == PAL and Apos[1] in (0, 1, 2, 3):
        rows = {0, RET}                               # 8.2.30 coḥ kuḥ; 8.2.36 vraśca... (yaj, rāj, sṛj)
    elif a == K.sib[0]:
        rows = {0, RET}                               # 8.2.36 (ś -> ṣ -> ḍ) or 8.2.62-type k (diś -> dik)
    elif a == K.sib[1]:
        rows = {RET}                                  # 8.2.39 jaś on ṣ (ṣaṣ -> ṣaḍ)
    elif a == "h":
        rows = {0, RET}                               # 8.2.31 ho ḍhaḥ, 8.2.32-33 gh/dh
    for r in sorted(rows or ()):
        res |= stop_final(r, B, Bvow, Bpos, K)
    if rows:
        return res
    if Apos is not None and Apos[1] == 4:             # final nasal
        r = Apos[0]
        if r == 3:                                    # n
            if Bpos is not None and Bpos[1] in (0, 1) and Bpos[0] in (PAL, RET, DEN):
                res |= out(["ṃ", K.sib[Bpos[0] - 1]], [B])     # 8.3.7
            elif Bpos is not None and Bpos[1] in (2, 3) and Bpos[0] in (PAL, RET):
                res |= out([K.at(Bpos[0], 4)], [B])   # 8.4.40/41
            elif B == "l":
                res |= out(["ṃ"], ["l"]) | out(["l"], ["l"]) | out(["ṃ", "l"], ["l"])  # 8.4.60
            elif B == K.sib[0]:
                res |= out([K.at(PAL, 4)], [B]) | out([K.at(PAL, 4)], [K.at(PAL, 1)])  # 8.4.40, 8.4.63
            elif Bvow and ctx == "short":
                res |= out(["n", "n"], [B])           # 8.3.32
            else:
                res |= out(["n"], [B])
        elif r == 4:                                  # m
            if Bvow:
                res |= out(["m"], [B])
            else:
                res |= out(["ṃ"], [B])                # 8.3.23
                if Bpos is not None:
                    res |= out([K.at(Bpos[0], 4)], [B])   # 8.4.59 option
        elif r == 0 and Bvow and ctx == "short":
            res |= out(["ṅ", "ṅ"], [B])               # 8.3.32
        else:
            res |= out([a], [B])
        return res
    res |= out([a], [B])                              # no rule applies
    return res


def stop_final(r, B, Bvow, Bpos, K):
    """Final stop of row r (after 8.2.30-39), before initial B."""
    res = set()
    PAL, RET, DEN = 1, 2, 3
    if Bvow or B in ("y", "v", "r") or (Bpos is not None and Bpos[1] in (2, 3)):
        if r == DEN and Bpos is not None and Bpos[0] in (PAL, RET) and Bpos[1] in (2, 3):
            res |= out([K.at(Bpos[0], 2)], [B])   # 8.4.40/41 on the jaś output
        else:
            res |= out([K.at(r, 2)], [B])         # 8.2.39
    elif Bpos is not None and Bpos[1] in (0, 1):
        if r == DEN and Bpos[0] in (PAL, RET):
            res |= out([K.at(Bpos[0], 0)], [B])   # 8.4.40/41 + 8.4.55
        else:
            res |= out([K.at(r, 0)], [B])         # 8.4.55
    elif B in K.sib:
        if r == DEN and B == K.sib[0]:
            res |= out([K.at(PAL, 0)], [K.at(PAL, 1)]) | out([K.at(PAL, 0)], [B])  # 8.4.40 + 8.4.63
        else:
            res |= out([K.at(r, 0)], [B])
            if B == K.sib[0]:
                res |= out([K.at(r, 0)], [K.at(PAL, 1)])   # 8.4.63
    elif B == "h":
        res |= out([K.at(r, 2)], [K.at(r, 3)]) | out([K.at(r, 2)], ["h"])  # 8.4.62
    elif Bpos is not None and Bpos[1] == 4:
        res |= out([K.at(r, 4)], [B]) | out([K.at(r, 2)], [B])  # 8.4.45 option
    elif B == "l":
        res |= out(["l"], ["l"]) if r == DEN else out([K.at(r, 2)], ["l"])  # 8.4.60
    return res


def finals():
    F = [(x,) for x in VOW + ALLC + ["ṃ"] if x != "r"]
    F += [(v, "ḥ") for v in VOW] + [(v, "r") for v in VOW] + [(v, "s") for v in VOW]
    return F


INITIALS = VOW + ALLC
CTX = ("short", "sib", "other")


def ctx_class(p, K):
    if p in SHORT: return "short"
    if p in (K.sib[0], K.sib[1], K.sib[2]): return "sib"
    return "other"


def build_inverse(K):
    inv = collections.defaultdict(set)
    for c in CTX:
        for A in finals():
            for B in INITIALS:
                for r in fwd(A, B, c, K):
                    inv[(c, r)].add((A, B))
    return inv


# ---------- data ----------
# avasāna (pausa): the forms a word-final unit may take at the end of a line. The form itself; s/r -> ḥ (8.2.66,
# 8.3.15); m -> ṃ (as the texts print it); a final stop -> the plain voiceless stop of its row (8.4.56); palatals and
# ś/ṣ/h -> k or ṭ (8.2.30, 8.2.36, 8.2.31-32). Used by the decoder for the LAST word of a line (review A.1).
_VL = {"g": "k", "gh": "k", "kh": "k", "d": "t", "dh": "t", "th": "t", "ḍ": "ṭ", "ḍh": "ṭ", "ṭh": "ṭ", "b": "p", "bh": "p", "ph": "p"}
PAUSA = {"s": {"ḥ"}, "r": {"ḥ"}, "m": {"ṃ"}, **{k: {v} for k, v in _VL.items()},
         "c": {"k"}, "ch": {"k", "ṭ"}, "j": {"k", "ṭ"}, "jh": {"k", "ṭ"}, "ś": {"k", "ṭ"}, "ṣ": {"ṭ"}, "h": {"k", "ṭ"}}


def pausa(x):
    return {x} | PAUSA.get(x, set())


def a_unit(u):
    if len(u) >= 2 and u[-1] in ("ḥ", "r", "s") and u[-2] in VOW:
        return tuple(u[-2:])
    return tuple(u[-1:])


def read_sentences(files):
    for f in files:
        text, members, groups, rng = None, [], [], None
        for line in open(f, encoding="utf-8"):
            line = line.rstrip("\n")
            if line.startswith("# text = "):
                text, members, groups, rng = line[9:], [], [], None
            elif line and not line.startswith("#"):
                cols = line.split("\t")
                if len(cols) >= 10 and "-" in cols[0]:
                    lo, hi = cols[0].split("-"); rng = (int(lo), int(hi))
                elif len(cols) >= 10 and cols[0].isdigit():
                    i = int(cols[0])
                    m = dict(kv.split("=", 1) for kv in cols[9].split("|") if "=" in kv)
                    members.append(m.get("Unsandhied", cols[1]))
                    groups.append(rng[0] if rng and rng[0] <= i <= rng[1] else i)
            elif not line and text is not None:
                yield text, members, groups
                text, members, groups, rng = None, [], [], None
        if text is not None:
            yield text, members, groups


def align(s, us, groups=None):
    """-> list of units (pos, r, A, B) or None. A junction between two surface tokens must contain the
    space; a junction inside one surface token (compound, fused sandhi) must not. r never starts with a
    space or avagraha and never ends with a space (A's and B's realizations are non-empty)."""
    n = len(us) - 1
    tb = [None] + [groups[j] != groups[j - 1] for j in range(1, n + 1)] if groups else None
    As = [a_unit(u) for u in us]
    cores = []
    for j, u in enumerate(us):
        lo = 1 if j > 0 else 0
        hi = len(u) - (len(As[j]) if j < n else 1)    # last member: its final may differ at avasāna
        if hi < lo:
            return None
        cores.append(tuple(u[lo:hi]))

    memo = {}

    def rec(j, pos):
        """Best alignment of junctions j..n from surface position pos, as (cost, units). The choice is
        rule-free: it minimises (longest r, sum of squared r lengths), i.e. keeps the realizations balanced."""
        if j > n:
            tail = s[pos:]
            return ((0, 0), []) if len(tail) <= 2 and SP not in tail else None
        if (j, pos) in memo:
            return memo[(j, pos)]
        cj, best = cores[j], None
        for L in range(1, 7):
            st = pos + L
            r = s[pos:st]
            if len(r) < L or r[0] in (SP, AV) or r[-1] == SP:
                continue
            if tb is not None and (SP in r) != tb[j]:
                continue
            if tuple(s[st:st + len(cj)]) == cj:
                got = rec(j + 1, st + len(cj))
                if got is not None:
                    cost = (max(L, got[0][0]), L * L + got[0][1])
                    if best is None or cost < best[0]:
                        best = (cost, [(pos, tuple(r), As[j - 1], us[j][0])] + got[1])
        memo[(j, pos)] = best
        return best

    if tuple(s[:len(cores[0])]) != cores[0]:
        return None
    got = rec(1, len(cores[0]))
    return got[1] if got else None


def load(dcs, texts):
    files = []
    for t in texts:
        files += sorted(glob.glob(os.path.join(dcs, t, "*.conllu")))
    sents, stats = [], collections.Counter()
    for text, members, groups in read_sentences(files):
        stats["sent"] += 1
        s = tok(text)
        us = [tok(m) for m in members]
        if s is None or any(u is None or not u or SP in u or AV in u for u in us):
            stats["drop_tok"] += 1; continue
        if len(us) < 2:
            stats["single"] += 1; continue
        units = align(s, us, groups)
        if units is None:
            stats["drop_align"] += 1; continue
        stats["kept"] += 1
        sents.append((s, units))
    return sents, stats


# ---------- generators and scoring ----------
def identity_props(r):
    """GENERIC's default: split with no change. r = A + [_] + B for a valid A unit."""
    props = set()
    rr = [x for x in r]
    for cut in range(1, len(rr)):
        L, R = rr[:cut], rr[cut:]
        if R and R[0] == SP:
            R = R[1:]
        if len(R) != 1 or R[0] not in INITIALS:
            continue
        if SP in L or AV in L:
            continue
        if len(L) == 1 or (len(L) == 2 and L[-1] in ("ḥ", "r") and L[0] in VOW):
            props.add((tuple(L), R[0]))
    return props


def score(sents, propose):
    gold = hit = positions = proposals = 0
    for s, units in sents:
        positions += len(s)
        gl = {(p, r): (A, B) for p, r, A, B in units}
        for p in range(len(s)):
            for L in range(1, 7):
                if p + L > len(s):
                    break
                r = tuple(s[p:p + L])
                P = propose(s, p, r)
                proposals += len(P)
                g = gl.get((p, r))
                if g is not None and g in P:
                    hit += 1
        gold += len(units)
    return {"gold": gold, "recall": hit / gold if gold else 0, "miss": 1 - hit / gold if gold else 0,
            "search": proposals / positions if positions else 0}


def ped_proposer(K):
    inv = build_inverse(K)

    def prop(s, p, r):
        c = ctx_class(s[p - 1], K) if p > 0 else "other"
        return inv.get((c, r), set())
    return prop


def generic_proposer(table):
    cache = {}

    def prop(s, p, r):
        if r not in cache:
            cache[r] = table.get(r, set()) | identity_props(r)
        return cache[r]
    return prop


def permuted(seed):
    rng = random.Random(seed)
    flat = [x for row in GRID for x in row]
    rng.shuffle(flat)
    g = [flat[i * 5:(i + 1) * 5] for i in range(5)]
    sib = SIB[:]
    rng.shuffle(sib)
    return Classes(g, sib)



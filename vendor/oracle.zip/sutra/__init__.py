# SPDX-License-Identifier: AGPL-3.0-only
# Determinism across venues (check T-V): the oracle uses the VENDORED mpmath 1.3.0 (oracle/vendor/mpmath, BSD) with
# its pure-Python backend on every host and in the browser, never a host's own mpmath or gmpy.
import os, sys, pathlib
os.environ['MPMATH_NOGMPY'] = '1'
_v = str(pathlib.Path(__file__).resolve().parent.parent / 'vendor')
if _v not in sys.path: sys.path.insert(0, _v)
if 'mpmath' in sys.modules and not sys.modules['mpmath'].__file__.startswith(_v):
    raise ImportError('a non-vendored mpmath was imported before sutra; import sutra first')
import mpmath
assert mpmath.__version__ == '1.3.0' and mpmath.libmp.BACKEND == 'python', (mpmath.__version__, mpmath.libmp.BACKEND)
